import Footer from "../../components/Footer/Footer";
import NavBar from "../../components/NavBar/NavBar";
import MainSection from "../../components/MainSection/MainSection";
import Hero from "../LandingPage/SubModules/HeroLanding";
const Home = () => {
 return (
  <>
   <NavBar />
   <Footer />
  </>
 );
};

export default Home;
