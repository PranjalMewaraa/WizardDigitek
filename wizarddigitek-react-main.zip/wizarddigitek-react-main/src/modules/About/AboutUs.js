import React from "react";
import NavBar from "../../components/NavBar/NavBar";
import Footer from "../../components/Footer/Footer";
import "./about.css";
import wz from "../../assets/Images/wzLogo.svg";
import FinancialAd from "../LandingPage/SubModules/FinancialAd";

const AboutUs = () => {
  return (
    <div>
      <NavBar />
      <div className="About">
        <div className="heroab">
          <div className="contab">
            <div className="r3ab">
              <span>
                <img src={wz} alt="" />
              </span>
            </div>
            <div className="r2ab">
              Your One-Stop Shop for Premium <br /> Gadgets at Unbeatable
              Prices!
            </div>
            <div className="r1ab">
              <button id="buyab">Buy</button>
              <button id="sellab">Sell</button>
              <button id="refb">Refurbished</button>
            </div>
          </div>
        </div>
        <div className="lilab">
          <div className="leftabs">
            lil' <br />
            about <br />
            us <br />
          </div>
          <div className="rightabs">
            Our shop, Mobile Factory, situated at Bhoiwada-Parel, Mumbai,
            Maharashtra is a home to a variety of mobiles, tablets and its
            accessories that are all of best quality with product guarantee and
            warranty. We are up-to-date with the current innovations in
            electronics, with the latest models of mobile & tablets. We also
            have trendy accessories to match your devices. Our staff is well
            trained and are knowledgeable about every product available in our
            store.
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AboutUs;
