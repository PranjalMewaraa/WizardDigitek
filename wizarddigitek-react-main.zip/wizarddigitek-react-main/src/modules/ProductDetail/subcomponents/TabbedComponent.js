
import React from 'react';
const TabbedComponent = ({ data }) => {

    return (
        <div className='TabView'>
            <div className="tabs-container">
                {/* Tab buttons */}
                <div className="tab-buttons">
                    <button
                        className='active'
                    >
                        Description
                    </button>
                </div>

                {/* Tab content */}
                <div className="tab-content">
                    <div>
                        {/* Content for the Description tab */}
                        <p>{data.productDesc}</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default TabbedComponent
