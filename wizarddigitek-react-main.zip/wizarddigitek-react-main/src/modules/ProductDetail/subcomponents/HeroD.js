import React from 'react'
import ImgGallery from './ImgGallery';
import Counter from './Counter';
import wp from '../../../assets/Images/wph.png'
const HeroD = ({ data }) => {
    return (
        <></>   
    )
}

export default HeroD
