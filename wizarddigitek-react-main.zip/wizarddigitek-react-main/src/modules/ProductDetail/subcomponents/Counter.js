// Import React and useState hook
import React, { useState } from 'react';


// Counter component
const Counter = () => {
  // State to hold the count value
 

  return (
   <></>
  );
};

export default Counter;
