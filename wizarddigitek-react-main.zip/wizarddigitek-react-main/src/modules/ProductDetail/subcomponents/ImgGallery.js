import React, { useState } from 'react'
// import {ProcessImage} from '../../../Services/Services';

function ProcessImage(imageObject) {

  const folder = imageObject.path.split("\\")[0];
  const fileName = imageObject.name;

  const path = `${process.env.REACT_APP_HOST}/api/${folder}`
 
  return path;
}

const ImgGallery = (props) => {

  const { images } = props;

  // Empty Array for Processed Images
  const ProcessedImages = []
  // Processing & Pushing Images to Array
  images?.forEach(image => ProcessedImages.push(ProcessImage(image)));
  // Reversing the array
  // ProcessedImages.reverse();


  const [selectedImage, setSelectedImage] = useState(ProcessedImages[0]);


  const handleImageClick = (image) => {
    setSelectedImage(image);
  };

  return (
    <div id='igg' className="flex w-1/2 h-[70] gap-4 justify-center">
      <div className="left-column">
        {ProcessedImages?.map((image, index) => (
          <button
            key={image.id}
            className={`image-thumbnail ${image === selectedImage ? 'selected' : ''}`}
            onClick={() => handleImageClick(image)}>
            <img src={image} alt={`Thumbnail ${index + 1}`} style={{ width: 'auto', height: 'auto' }} />
          </button>
        ))}
      </div>
      <div className="right-column">
        <img src={selectedImage} alt="Selected" className="selected-image" />
      </div>
    </div>
  )
}

export default ImgGallery
