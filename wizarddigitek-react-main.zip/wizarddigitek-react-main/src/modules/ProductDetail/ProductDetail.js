import React, { useState, useEffect } from "react";
import "./productDetail.css";
import NavBar from "../../components/NavBar/NavBar";
import Footer from "../../components/Footer/Footer";
import TabbedComponent from "./subcomponents/TabbedComponent";
import ProductCard from "../../components/ProductCard/ProductCard";
import pimg from "../../assets/Images/productimage.png";
import ImgGallery from "./subcomponents/ImgGallery";
import wp from "../../assets/Images/wph.png";
import { useParams } from "react-router-dom";
import axios from "axios";
import MergedProductCard from "../../components/ProductCard/MergedProductCard";

const API_ROUTE = "api/wizard";

const ProductDetail = (props) => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [otherP, setOP] = useState();
  const [selectedVariant, setSelectedVariant] = useState({});
  const [selectedColor, setSelectedColor] = useState({});
  const [checkedColor, setCheckedColor] = useState("");
  const [related, setRelated] = useState([]);
  const [count, setCount] = useState(1);
  const [rCount, setRCount] = useState(0);

  const getData = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/product?id=${id}`
      );
      setProduct(response.data?.data);
      setSelectedVariant(response.data?.data?.variant[0] || {});
      setSelectedColor(response.data?.data?.variant[0]?.color[0] || {});
      setLoading(false);
      const ids = response.data.data?.productTypeId;
      console.log("ids", ids);
      getRelatedData(ids);
      const response2 = await axios.get(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?productTypeId=${ids}`
      );
      setOP(response2.data?.data);
    } catch (error) {
      console.error("Error fetching product:", error);
      setLoading(false);
    }
  };

  const getRelatedData = async (productTypeID) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?productTypeId=${productTypeID}`
      );
      console.log("relatedData", response.data.data);
      setRelated(response.data?.data.rows);
    } catch (error) {
      console.log("error fetching related item");
    }
  };

  useEffect(() => {
    getData();
  }, [id]);
  useEffect(() => {}, []);
  console.log("Detail", otherP);
  const handleDecrement = () => {
    setCount((prevCount) => (prevCount > 1 ? prevCount - 1 : prevCount));
  };
  const handleIncrement = () => {
    setCount((prevCount) =>
      prevCount < product.quantity ? prevCount + 1 : prevCount
    );
  };

  const sendMessage = () => {
    const message = `
            Hey I want to purchase ${product.productName}
            Brand: ${product.productBrand.name}
            Product Code: ${product.productCode}
            Qty: ${count}
            Variant: ${selectedVariant.variant}
            Color: ${selectedColor.colorName}
            Price: ${selectedColor.discountPrice} `;
    console.log(message);
    const phoneNumber = "7827999788";
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `whatsapp://send?phone=${phoneNumber}&text=${encodedMessage}`;

    const newTab = window.open(whatsappUrl, "_blank");

    // If the browser blocks the new tab, provide a fallback link
    if (!newTab) {
      window.location.href = whatsappUrl;
    }
  };

  const handleVariantChange = (value) => {
    setSelectedVariant(value);
    setSelectedColor(value.color?.[0] || {});
    setCheckedColor(value.color?.[0]?.colorName || "");
  };

  const handleColorChange = (value) => {
    setSelectedColor(value);
    setCheckedColor(value.colorName);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  // Change this to the desired number of divs

  return (
    <>
      <NavBar />
      <div className="prodDetailPage flex flex-col">
        <div className="heroDetail">
          <ImgGallery
            current={product?.thumbnail}
            images={product?.productImages || []}
          />
          <div className="rightpd">
            <p id="toptextpd">
              <span style={{ fontWeight: "500" }}>Brand: </span>
              {product?.productBrand.name}
            </p>
            <p id="toptextpd">
              <span style={{ fontWeight: "500" }}>Code: </span>
              {product?.productCode}
            </p>
            <p id="toptextpd">
              <span style={{ fontWeight: "500" }}>Availability: </span>
              {` Only ${product?.quantity} left in stock`}
            </p>
            <p id="hheadingPDtext">{`${product?.productName.name}`}</p>
            <ul id="speclist">
              {product?.productSpecs?.map((desc) => {
                return <li id="specs" key={desc}>{`${desc}`}</li>;
              })}
            </ul>
            {/* Variant */}
            <div className="mt-1 mb-2">
              <h1 className="text-md font-medium">Select Variant</h1>
              <fieldset className="radioPD flex flex-wrap my-3">
                {product?.variant?.map((item) => {
                  console.log(item);
                  return (
                    <label key={item.id} className="cursor-pointer">
                      <input
                        type="radio"
                        name="radioVariant"
                        checked={
                          selectedVariant.variantTags === item.variantTags
                        }
                        onChange={() => handleVariantChange(item)}
                      />
                      <div className="box">
                        <span>{item.variantTags}</span>
                      </div>
                    </label>
                  );
                })}
              </fieldset>
            </div>

            {/* Color */}
            <div className="mt-1 mb-2">
              <h1 className="text-md font-medium">Select Color</h1>
              <fieldset className="radioPD flex flex-wrap my-3">
                {selectedVariant.color?.map((item) => {
                  //console.log(item);
                  return (
                    <label key={item.id} className="cursor-pointer">
                      <input
                        type="radio"
                        name="radioColor"
                        checked={checkedColor === item.colorOptions}
                        onChange={() => handleColorChange(item)}
                      />
                      <div className="box">
                        <span>{item.colorOptions}</span>
                      </div>
                    </label>
                  );
                })}
              </fieldset>
            </div>
            <p id="ptagtext">INR (Inclusive of all taxes):</p>
            <div className="pricerow">
              <p id="pricecol">INR {selectedColor.discountPrice}</p>
              <p id="pricecol2">INR {selectedColor.price}</p>
            </div>
            <div className="quantrow">
              <div className="counter-container">
                {/* Left button for decrement */}
                <button className="counter-button" onClick={handleDecrement}>
                  -
                </button>

                {/* Middle area to display the count */}
                <div className="counter-count">{count}</div>

                {/* Right button for increment */}
                <button className="counter-button" onClick={handleIncrement}>
                  +
                </button>
              </div>
              <button type="button" id="buttoni" onClick={sendMessage}>
                <span>
                  {" "}
                  <img src={wp} alt="" />
                </span>{" "}
                Whatsapp
              </button>
            </div>
          </div>
        </div>

        <TabbedComponent data={product} />
        <div className="rltdpro">
          <h2>Related products</h2>
          <div className="rltdrow">
            {related.length > 4
              ? related
                  .slice(0, 4)
                  .map((item) => (
                    <MergedProductCard
                      key={item.id}
                      productCondition={item.productCondition}
                      productId={item.id}
                      productImage={item.thumbnail}
                      productName={item.productName}
                      productPrice={item.variant[0].color[0].price}
                      productDiscountPrice={
                        item.variant[0].color[0].discountPrice
                      }
                      colors={item.variant[0].color.length}
                      pid={item.productTypeId}
                    />
                  ))
              : related.map((item) => (
                  <MergedProductCard
                    key={item.id}
                    productCondition={item.productCondition}
                    productId={item.id}
                    productImage={item.thumbnail}
                    productName={item.productName}
                    productPrice={item.variant[0].color[0].price}
                    productDiscountPrice={
                      item.variant[0].color[0].discountPrice
                    }
                    colors={item.variant[0].color.length}
                    pid={item.productTypeId}
                  />
                ))}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ProductDetail;
