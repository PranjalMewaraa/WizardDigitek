import React, { useEffect, useRef, useState } from "react";
import Nav from "../../components/NavBar/NavBar";
import Hero from "./SubModules/HeroLanding";
import "./LandingPage.css";
import CategoryGrid from "./SubModules/CategoryGrid";
import FinancialAd from "./SubModules/FinancialAd";
import ProdCardLanding from "./SubModules/ProdCardLanding";
import prodlc from "../../assets/Images/prodlc.png";
import CardCarousel from "./SubModules/CardCarousel";
import Brands from "./SubModules/Brands";
import EmiCalcDiv from "./SubModules/EmiCalcDiv";
import EmiCalcDiv2 from "./SubModules/EmiCalcDiv2";
import Footer from "../../components/Footer/Footer";
import TestimonialSection from "./SubModules/TestimonialSection";
import ContactSect from "./SubModules/ContactSect";
import DisplayGrid from "./SubModules/DisplayGrid/DisplayGrid";
import DisplayNews from "./SubModules/DisplayNews";
import CateGrid from "./SubModules/CateGrid";
import of1 from "../../assets/Images/of1.png";
import of2 from "../../assets/Images/of22.png";
import of3 from "../../assets/Images/of33.png";
import logistic from "../../assets/Images/logf.png";
import dollar from "../../assets/Images/dolf.png";
import money from "../../assets/Images/moneyf.png";
import transp from "../../assets/Images/tranf.png";
import fb from "../../assets/Images/fb.png";
import fbh from "../../assets/Images/fbh.png";
import wp from "../../assets/Images/wp.png";
import wph from "../../assets/Images/wph.png";
import tl from "../../assets/Images/tl.png";
import tlh from "../../assets/Images/tlh.png";
import insta from "../../assets/Images/insta.png";
import instah from "../../assets/Images/instah.png";
import axios from "axios";
import GBrandHero from "../Brands/GenericBrandHero/GBrandHero";
import "../Brands/GenericBrandHero/GB.css";
const LandingPage = () => {
  const [heroData, setHeroData] = useState([]);
  const [slide, setSlide] = useState([]);

  const getHeroData = () => {
    axios
      .get(`${process.env.REACT_APP_HOST}/api/wizard/landingHeros`)
      .then(function (response) {
        setHeroData(response.data.data);
        console.log("Data:", response.data.data);
      })
      .catch(function (error) {
        // Handle errors
        console.error("Error:", error);
      });
  };
  const getSlides = () => {
    axios
      .get(`${process.env.REACT_APP_HOST}/api/wizard/adBanners`)
      .then(function (response) {
        setSlide(response.data.data);
        console.log("Sata:", response.data.data);
      })
      .catch(function (error) {
        // Handle errors
        console.error("Error:", error);
      });
  };
  useEffect(() => {
    getHeroData();
    getSlides();
  }, []);
  const cardData = [
    <ProdCardLanding
      key={1}
      img={prodlc}
      title="IPhone 14 Pro Max"
      desc="Midnight, 128GB"
      price="59,999"
    />,
    <ProdCardLanding
      key={2}
      img={prodlc}
      title="IPhone 14 Pro Max"
      desc="Midnight, 128GB"
      price="59,999"
    />,
    <ProdCardLanding
      key={3}
      img={prodlc}
      title="IPhone 14 Pro Max"
      desc="Midnight, 128GB"
      price="59,999"
    />,
    <ProdCardLanding
      key={4}
      img={prodlc}
      title="IPhone 14 Pro Max"
      desc="Midnight, 128GB"
      price="59,999"
    />,
    <ProdCardLanding
      key={5}
      img={prodlc}
      title="IPhone 14 Pro Max"
      desc="Midnight, 128GB"
      price="59,999"
    />,
    <ProdCardLanding
      key={6}
      img={prodlc}
      title="IPhone 14 Pro Max"
      desc="Midnight, 128GB"
      price="59,999"
    />,
    <ProdCardLanding
      key={7}
      img={prodlc}
      title="IPhone 14 Pro Max"
      desc="Midnight, 128GB"
      price="59,999"
    />,
  ];
  const slides = [
    { image: of1 },
    { image: of2 },
    { image: of3 },
    // Add more slides as needed
  ];

  const cardsData = [
    {
      img: dollar,
      title: "Sell old Device for Cash",
      para: "We provides you a platform to sell your old devices in exchange of cash or get an exciting discount on purchase of a new device from our store",
      linkt: "Sell now",
    },
    {
      img: logistic,
      title: "Warentee/Gaurentee",
      para: "When you invest in our products, you're not just purchasing an item; you're securing peace of mind. Our warranty/guarantee reflects our commitment to delivering quality and satisfaction.",
      linkt: "Sell now",
    },
    {
      img: money,
      title: "Cheap prices and offers",
      para: "At our marketplace, we prioritize providing cost-effective solutions without compromising quality. Take advantage of our special offers to maximize your savings while enjoying top-notch products and services",
      linkt: "Sell now",
    },
    {
      img: transp,
      title: "On time Delivery",
      para: " Sell now and enjoy the peace of mind that comes with our on-time delivery guarantee. Trust us to bring your purchases to your doorstep in a timely manner, making your experience with us seamless and efficient.",
      linkt: "Sell now",
    },
  ];

  function redirectToWhatsApp() {
    // Replace '1234567890' with the actual phone number
    var phoneNumber = "7827999788";

    // Use the WhatsApp API link with the phone number
    var whatsappLink = "https://wa.me/" + phoneNumber;

    // Open the link in a new tab/window
    window.open(whatsappLink, "_blank");
  }

  function redirectToTelegram() {
    // Replace '1234567890' with the actual phone number
    var phoneNumber = "7827999788";

    // Use the Telegram link to open the app and let the user search for the contact
    var telegramLink = "https://t.me/" + phoneNumber;

    // Open the link in a new tab/window
    window.open(telegramLink, "_blank");
  }
  function redirectToInstagram() {
    // Replace 'username' with the actual Instagram username
    var instagramUsername = "wizard.digitek";

    // Use the Instagram link to open the app and let the user search for the profile
    var instagramLink = "https://www.instagram.com/" + instagramUsername;

    // Open the link in a new tab/window
    window.open(instagramLink, "_blank");
  }

  function redirectToFacebook() {
    // Replace 'username' with the actual Facebook profile username or user ID
    var facebookUsername = "wizard.digitek";

    // Use the Facebook link to open the app or website and let the user search for the profile
    var facebookLink = "https://www.facebook.com/" + facebookUsername;

    // Open the link in a new tab/window
    window.open(facebookLink, "_blank");
  }

  return (
    <div className="LandingPage">
      <div className="social">
        <div className="sc1" onClick={redirectToFacebook}>
          <div className="sci">
            <div className="ic">
              <img src={fb} alt="" id="nh" />
              <img src={fbh} alt="" id="hvr" />
            </div>
          </div>
        </div>
        <div className="sc2" onClick={redirectToWhatsApp}>
          <div className="sci">
            <div className="ic">
              <img src={wp} alt="" id="nh" />
              <img src={wph} alt="" id="hvr" />
            </div>
          </div>
        </div>
        <div className="sc3" onClick={redirectToInstagram}>
          <div className="sci">
            <div className="ic">
              <img src={insta} alt="" id="nh" />
              <img src={instah} alt="" id="hvr" />
            </div>
          </div>
        </div>
        <div className="sc4" onClick={redirectToTelegram}>
          <div className="sci">
            <div className="ic">
              <img src={tl} alt="" id="nh" />
              <img src={tlh} alt="" id="hvr" />
            </div>
          </div>
        </div>
      </div>

      <Nav />
      <Hero heroData={heroData} />
      <GBrandHero />
      <DisplayGrid />
      <DisplayNews slides={slide} page="user" />
      <CateGrid />
      <FinancialAd cardsData={cardsData} />
      <Brands />
      <EmiCalcDiv />
      <EmiCalcDiv2 />
      <ContactSect />
      <TestimonialSection />
      <Footer />
    </div>
  );
};

export default LandingPage;
