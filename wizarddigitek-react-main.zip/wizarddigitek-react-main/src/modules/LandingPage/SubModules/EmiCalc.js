import React, { useState } from "react";
import "../LandingPage.css";
import flg from "../../../assets/Images/flg.png";
import clk from "../../../assets/Images/clk.png";

const EmiCalc = () => {
  const [cost, setCost] = useState();
  const [months, setMonths] = useState(12);
  const [annualInterestRate, setAnnualInterestRate] = useState(5); // Default is 5%
  const [emi, setEmi] = useState(0);
  const [total, setTotal] = useState(0);

  const calculateEMIn = () => {
    const P = parseFloat(cost);
    const R = parseFloat(annualInterestRate) / 1200; // Monthly interest rate
    const N = parseFloat(months);

    if (P && R && N) {
      const numerator = P * R * Math.pow(1 + R, N);
      const denominator = Math.pow(1 + R, N) - 1;
      const calculatedEMI = numerator / denominator;
      setEmi(calculatedEMI);
      setTotal(calculatedEMI * months);
    } else {
      setEmi(null);
    }
  };
  return (
    <div className="CalcEmi">
      <div className="costem">
        <label htmlFor="costEmi">Product Cost</label>
        <div className="inp">
          <img src={flg} alt="" />
          <span style={{ color: "#ffff" }}>INR</span>
          <input
            type="number"
            name="cost"
            id="costEmi"
            placeholder="Enter Cost"
            value={cost}
            onChange={(e) => setCost(Number(e.target.value))}
          />
        </div>
      </div>
      <div className="monthsem">
        <label htmlFor="month">Enter no of months</label>
        <div className="inp">
          <img src={clk} alt="" />
          <span style={{ color: "#ffff", fontSize: "1vmax" }}>Months</span>
          <input
            type="number"
            name="month"
            id="month"
            placeholder="12"
            value={months}
            onChange={(e) => setMonths(Number(e.target.value))}
          />
        </div>
      </div>
      <div className="interestem">
        <label htmlFor="interestRate">Annual Interest Rate (%)</label>
        <div className="inp">
          <span style={{ color: "#ffff" }}>%</span>
          <input
            type="number"
            name="interestRate"
            id="interestRate"
            placeholder="5"
            value={annualInterestRate}
            onChange={(e) => setAnnualInterestRate(Number(e.target.value))}
          />
        </div>
      </div>
      <div className="infoem">
        <p>
          Interest Rate:{" "}
          <span style={{ color: "#0A84FF" }}>{annualInterestRate}%</span> per
          annum
        </p>
        <p>
          Total Amount in Rs.{" "}
          <span style={{ color: "#0A84FF" }}>{total.toFixed(2)}</span>
        </p>
        <p>
          EMI: Rs. <span style={{ color: "#0A84FF" }}>{emi.toFixed(2)}</span>{" "}
          per month
        </p>
        <p>
          Bank Transfer Fee: Rs.{" "}
          <span style={{ color: "#0A84FF" }}>{(cost * 2) / 1000}</span>
        </p>
      </div>
      <button id="btnemi" onClick={calculateEMIn}>
        Calculate
      </button>
    </div>
  );
};

export default EmiCalc;
