import React from 'react'
import '../LandingPage.css'
const CardTesti = (props) => {
  return (
    <div className='CardT'>
      <div className="row1t">
        <div className="rect1"></div>
      </div>
      <div className="row2t">
        <div className="rect2">
            <div id="imgt">
                <img src={props.img} alt="" />
            </div>
            <div id="textt">
                <div id="ratett" style={{color:"white", marginLeft:".5vmax",margin:".25vmax", fontSize:".9vmax"}}>✬✬✬✬✬ <span style={{fontSize:".5vmax", color:"#B9C8F3"}}> 15 ratings</span></div>
                <div id="ratett" style={{color:"white", margin:".5vmax", fontSize:"1vmax",lineHeight:"100%"}}>{props.review}</div>
                <div>
                    <div id="namett" style={{color:"white",marginLeft:".5vmax", fontSize:".9vmax",color:"#B9C8F3"}}>{props.name}</div>
                    <div id="destt" style={{color:"white", marginLeft:".5vmax",fontSize:".9vmax",color:"#B9C8F3"}}>{props.desg}</div>
                </div>
            </div>
        </div>
      </div>
      <div className="row3t">
        <div className="rect3"></div>
      </div>

    </div>
  )
}

export default CardTesti
