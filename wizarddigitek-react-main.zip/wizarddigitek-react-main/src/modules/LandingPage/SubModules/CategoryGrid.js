import React from 'react'

import catApple from '../../../assets/Images/catIcon.png'
import catHead from '../../../assets/Images/catHead.png'
import speaker from '../../../assets/Images/speaker.png'
import catMob from'../../../assets/Images/catMob.png'
import catLap from '../../../assets/Images/CatLap.png'
import catW from '../../../assets/Images/CatW.png'
import catE from '../../..//assets/Images/CatEar.png'
import './cat.css'
import speakerTable from '../../../assets/Images/speakerTable.png'
import { Link } from 'react-router-dom'
const CategoryGrid = () => {
  return (
    <div className='GridSection'>
      <div className="parent-grid">
        <Link to={'/apple'} className="divApple">
            <div className="cat1Text">
                <div id="applehead">iPhone @ Cheapest</div>
                <div id="appleSubhead">Get imported iphones at cheaper rate</div>
            </div>
            <img src={catApple} alt="" />
        </Link>
        <Link to={'/speakers'} className="divSpeaker">
            <div className="cat2Text">
                <div id="Hhead">Noise Cancellation</div>
                <div id="HSubhead">Get Premium <br></br>Wireless headsets </div>
            </div>
            <img src={speaker} alt="" id='mainSpeaker'/>
            <img src={speakerTable} alt="" style={{zIndex:"1",transform:"translateY(5%)"}} />
        </Link>
        <div className="divHeadphone">
            <img src={catHead} alt="" id='cathead'/>
            <div className="cat3Text">
                <div id="Hhead">Noise Cancellation</div>
                <div id="HSubhead">Get Premium <br></br>Wireless headsets </div>
            </div>
        </div>
        <Link to={"/smartphones"} className="divMobile">
            <div className="cat4Text">
                <div id="applehead">Get The Best Smartphones</div>
                <div id="appleSubhead">New and Refurbished</div>
            </div>
            <img src={catMob} alt="" id='catMob'/>
        </Link>
        <div className="divEarphone">
          <div className="textE">
            <div id="head">Earbuds and Earphone</div>
            <div id="subhead">Premium Quality</div>
          </div>
          <div className="ImageE">
            <img src={catE} alt="" id='imgE' />
          </div>
        </div>
        <Link to={'/laptop-tv'} className="divLaptop">
          <div className="textLap">
            <div id="subhead">Get the Best Prices on</div>
            <div id="head">Tv & Laptops</div>
          </div>
          <div className="imgLap">
            <img src={catLap} alt="" />
          </div>
        </Link>
        <Link to={'/smartwatches'} className="divWatch">
          <div className="imgW">
            <img src={catW} alt="" />
          </div>
          <div className="textW">
          <div id="subhead">Exclusive Range of</div>
            <div id="head">Laptops / TVs</div>
            <div id="subhead2">Explore Best Deals Now</div>
          </div>
        </Link>
      </div>
    </div>
  )
}

export default CategoryGrid
