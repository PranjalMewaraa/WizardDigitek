import React from "react";
import "../LandingPage.css";

export const Frame = (props) => {
    return (
        <div className="frame">
            <div className="div">
                <img src={props.img} alt="" /> 
            </div>
            <p className="PHONE">
                <span className="text-wrapper">
                    {props.title}
                    <br />
                </span>
                <span className="span">{props.info}</span>
            </p>
        </div>
    );
};
export default Frame