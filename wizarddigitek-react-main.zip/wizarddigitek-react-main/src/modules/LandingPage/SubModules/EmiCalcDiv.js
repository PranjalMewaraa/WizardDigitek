import React from 'react'
import hand from '../../../assets/Images/hand.png'
import cc from '../../../assets/Images/cc.png'
import '../LandingPage.css'
const EmiCalcDiv = () => {
  return (
    <div className='EmiCont'>
      <div className="emidiv">
        <div className="eleft">
            <div className="texte">
                <div id="titleem">Dont Worry about your Finance</div>
                <div id="subTem">Don't worry about your finances. Taking control of your financial well-being is a crucial step towards a secure future. Whether you're planning for short-term goals or long-term investments, it's essential to make informed decisions.</div>
                <div id="linktem">Contact us to know more</div>
            </div>
        </div>
        <div className="eright">
            <img src={cc} style={{width:"65%"} } id='cc' alt="" />
            <img src={hand} style={{width:"65%"} } id='hand' alt="" />
        </div>
      </div>
    </div>
  )
}

export default EmiCalcDiv
