// FinancialAd.js

import React from 'react';
import bimg from '../../../assets/Images/btnimgplay.png';
import FCard from './FCard';
import '../LandingPage.css';

const FinancialAd = ({ cardsData }) => {
  return (
    <div className='FContainer'>
      <div className="mainFDiv">
        <div className="FLeft">
          <div className="FtextContainer">
            <div id="headingF">We Keep Your Money Safe</div>
            <div id="SubheadingF">We are home to a variety of mobiles, tablets, and their accessories, all of the best quality with product guarantees and warranties.</div>
            <div id="btnGrpF">
              <button type="button" id='btn1F'>About</button>
              <button type="button" id='btn2F'>
                <img src={bimg} alt="" />
              </button>
            </div>
          </div>
        </div>
        <div className="FRight">
          <div className="gridF">
            {cardsData.map((card, index) => (
              <div className="gf" key={index}>
                <FCard
                  img={card.img}
                  title={card.title}
                  para={card.para}
                  linkt={card.linkt}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialAd;
