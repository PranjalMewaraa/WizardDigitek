import React from "react";
import apple from "../../../assets/Images/apple.png";
import asus from "../../../assets/Images/asus.png";
import sams from "../../../assets/Images/samsung.png";
import oppo from "../../../assets/Images/oppo.png";
import sony from "../../../assets/Images/sony.png";
import mi from "../../../assets/Images/mi.png";
import "../LandingPage.css";
import { Link } from "react-router-dom";
const Brands = () => {
  return (
    <div className="BrandsSection">
      <div className="upperb">
        <div className="uleftB">Bra</div>
        <div className="uRightB">nds</div>
      </div>
      <div className="lowerb">
        <div id="bTitle">Brands</div>
        <div id="bList">
          <Link to={"/apple"} className="logob">
            <img src={apple} alt="" />
          </Link>
          <Link to={"/comingsoon"} className="logob">
            <img src={oppo} alt="" />
          </Link>
          <Link to={"/sony"} className="logob">
            <img src={sony} alt="" />
          </Link>
          <Link to={"/samsung"} className="logob">
            <img src={sams} alt="" />
          </Link>
          <Link to={"/comingsoon"} className="logob">
            <img src={mi} alt="" />
          </Link>
          <Link to={"/comingsoon"} className="logob">
            <img src={asus} alt="" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Brands;
