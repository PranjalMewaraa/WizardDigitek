import React, { useState } from "react";
import axios from "axios";
import {
  CCarousel,
  CImage,
  CCarouselCaption,
  CCarouselInner,
  CCarouselItem,
} from "@coreui/react";
import of1 from "../../../assets/Images/of1.png";
import of2 from "../../../assets/Images/of22.png";
import of3 from "../../../assets/Images/of33.png";
import del from "../../../assets/Images/adminAssets/delete-outline.svg";
const DisplayNews = ({ slides, page = "admin" }) => {
  console.log("slides", slides);
  const handleDelImage = (slideId) => {
    if (window.confirm("Are you sure you want to delete this image?")) {
      const url = `${process.env.REACT_APP_HOST}/api/wizard/adBanner?id=${slideId}`;

      axios
        .delete(url)
        .then((response) => {
          console.log("Slide deleted successfully:", response.data);
        })
        .catch((error) => {
          console.error("Error deleting slide:", error);
          // Handle the error appropriately
        });
    }
  };
  const onCLickf = (slideId) => {
    handleDelImage(slideId);
  };
  const [show, setShow] = useState(page === "admin" ? true : false);
  return (
    <>
      <div className="OfferDis">
        <CCarousel controls id="cccc">
          {slides.map((slide, index) => (
            <CCarouselItem key={index} id={show ? "adm" : "use"}>
              <button onClick={() => onCLickf(slide.id)} className="btndel">
                <img src={del} alt="" />
              </button>
              <CImage
                className="d-block w-100"
                src={`${process.env.REACT_APP_HOST}/api/upload/${slide.adBannerAttachment[0].name}`}
                alt={`slide ${index + 1}`}
              />
            </CCarouselItem>
          ))}
        </CCarousel>
      </div>
    </>
  );
};

export default DisplayNews;
