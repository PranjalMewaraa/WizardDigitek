import React from "react";
import testimg from "../../../assets/Images/testimg.png";
import testimg1 from "../../../assets/Images/testimg1.png";
import CardTesti from "./CardTesti";
import tl from "../../../assets/Images/testlogo.png";
import "../LandingPage.css";
const TestimonialSection = () => {
  return (
    <div className="TestimonialSection" id="Testimonial">
      <div className="topTes">
        <div id="titleST">
          <img src={tl} alt="" />
          <div id="stt">Our Testimonials</div>
        </div>
      </div>
      <div className="btmTes">
        <CardTesti
          img={testimg1}
          name="Rishab Raj"
          review="I recently purchased a new smartphone from this online gadget store, The gadget itself was in pristine condition, and I got it at a fantastic price."
          desg="Satisfied Customer"
        />
        <CardTesti
          img={testimg}
          name="Najib SIddiqui"
          desg="Satisfied Customer"
          review="I recently bought a smartwatch from this store, and I am extremely satisfied with my purchase. The product was as described."
        />
      </div>
    </div>
  );
};

export default TestimonialSection;
