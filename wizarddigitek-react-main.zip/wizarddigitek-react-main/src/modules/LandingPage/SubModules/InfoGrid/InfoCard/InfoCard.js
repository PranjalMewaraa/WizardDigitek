import React from "react";

const InfoCard = () => {
 return (
  <div className="one">
   <div className="bg-one">No Fees Not Even Hidden Ones</div>
  </div>
 );
};

export default InfoCard;
