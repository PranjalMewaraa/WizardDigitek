import InfoCard from "./InfoCard/InfoCard";

const InfoGrid = () => {
 return (
  <div className="info-section">
   <div className="info-contaner">
    <div className="info-card">
     <InfoCard />
    </div>
   </div>
  </div>
 );
};

export default InfoGrid;
