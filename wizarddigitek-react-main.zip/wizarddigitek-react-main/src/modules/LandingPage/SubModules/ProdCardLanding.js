import React from 'react'
import favf from '../../../assets/Images/favoritefilled.png'
import favO from '../../../assets/Images/favoutline.png'
import '../LandingPage.css'
const ProdCardLanding = ({img,title,desc,price}) => {
  return (
    <div className='prodcardLanding'>
      <img src={img} id='prodImg' alt="" />
      <div className="row1pc">
        <div className="titlediv">
            <p id='title'>{title}</p>
        </div>
        <img src={favO} alt="" />
      </div>
      <div className="row2pc">
        <div id="desc">{desc}</div>
      </div>
      <div className="row3pc">
        <div id="price">₹{price} <span style={{fontSize:".7vmax", fontWeight:"400"}}> Inc of all taxes</span></div>
      </div>
      
    </div>
  )
}

export default ProdCardLanding
