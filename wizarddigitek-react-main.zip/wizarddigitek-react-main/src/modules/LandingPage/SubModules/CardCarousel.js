import React, { useState } from 'react';
import '../LandingPage.css'
const CardCarousel = ({ cards }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  const handleNext = () => {
    setActiveIndex((activeIndex + 1) % cards.length);
  };
  
  const handlePrev = () => {
    setActiveIndex((activeIndex - 1 + cards.length) % cards.length);
  };

  return (
    <div className="card-slider">
      <button className="slider-button prev" onClick={handlePrev}>
        &lt;
      </button>
      <div className="cardx-container">
        {cards.map((card, index) => (
          <div
            key={index}
            className={`cardx ${index === activeIndex ? 'active' : ''}`}
            style={{ transform: `translateX(${(index - activeIndex) * 100}%)` }}
          >
            {card}
          </div>
        ))}
      </div>
      <button className="slider-button next" onClick={handleNext}>
        &gt;
      </button>
    </div>
  );
};

export default CardCarousel;
