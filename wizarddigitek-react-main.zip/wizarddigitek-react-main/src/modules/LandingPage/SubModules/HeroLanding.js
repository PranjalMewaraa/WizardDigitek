import React, { useState } from "react";
import "../LandingPage.css";
import img from "../../../assets/Images/image81.png";
import img2 from "../../../assets/Images/image79.png";
import img3 from "../../../assets/Images/image766.png";
import img4 from "../../../assets/Images/image77.png";
const Hero = ({ heroData }) => {
  const bgArray = heroData.map((item) => item.bg);
  const textArray = heroData.map((item) => item.text);
  const attachmentNameArray = heroData.map((item) => item.attachment[0].name);

  // Now you can use these arrays as needed in your application
  console.log("Backgrounds:", bgArray);
  console.log("Texts:", textArray);
  console.log("Attachment Names:", attachmentNameArray);

  return (
    <div className="LandingHero">
      <div className="bg">
        <div className="bgcolr1" style={{ backgroundColor: bgArray[0] }}></div>
        <div className="bgcolr2" style={{ backgroundColor: bgArray[1] }}></div>
        <div className="bgcolr3" style={{ backgroundColor: bgArray[2] }}></div>
        <div className="bgcolr4" style={{ backgroundColor: bgArray[3] }}></div>
        <div className="bgcolr5" style={{ backgroundColor: bgArray[0] }}></div>
      </div>
      <div className="text">
        <div className="headtext"></div>
        <div className="headtext">{textArray[0]}</div>
        <div className="headtext">{textArray[1]}</div>
        <div className="headtext">{textArray[2]}</div>
        <div className="headtext">{textArray[3]}</div>
      </div>
      <div className="img">
        <div className="cenimg"></div>
        <div className="cenimg">
          <img
            src={`${process.env.REACT_APP_HOST}/api/upload/${attachmentNameArray[0]}`}
            alt=""
          />
        </div>
        <div className="cenimg">
          <img
            src={`${process.env.REACT_APP_HOST}/api/upload/${attachmentNameArray[1]}`}
            alt=""
          />
        </div>
        <div className="cenimg">
          <img
            src={`${process.env.REACT_APP_HOST}/api/upload/${attachmentNameArray[2]}`}
            alt=""
          />
        </div>
        <div className="cenimg">
          <img
            src={`${process.env.REACT_APP_HOST}/api/upload/${attachmentNameArray[3]}`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
};

export default Hero;
