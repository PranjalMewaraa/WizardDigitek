import React from "react";
import "../LandingPage.css";
const FCard = (props) => {
  return (
    <div className="contf">
      <img src={props.img} alt="" id="fcimg" />
      <div id="titlefc">{props.title}</div>
      <div id="para">{props.para}</div>
      <div id="linkt" style={{ display: "none" }}>
        {props.linkt}
      </div>
    </div>
  );
};

export default FCard;
