import logodg from '../../../../assets/Images/logodg.png'
const Card2 = () => {
  return (
    <div className='CardDG2'>
      <div id="bgdg2">
        <p className="shop-with-select">
          Shop with select brands and get&nbsp;&nbsp;more
          <br />
          exciting&nbsp;&nbsp;Offers.
        </p>
      </div>
      <img src={logodg} alt="" id='card2dg'/>
    </div>
  )
}

export default Card2
