import React from 'react'
import img from '../../../../assets/Images/imgc.png'
const Card5 = () => {
  return (
    <div className='CardBG5'>
      <div className="LEFTCGC">
        <img src={img} alt="" />
      </div>
      <div className="RIGHTCGC">
        <div className="textcgc">
            Pay for your new Apple products over time, interest-free
        </div>
        <div className="textcgcd">when you choose to check out with Apple Card Monthly Installments.</div>
      </div>
    </div>
  )
}

export default Card5;
