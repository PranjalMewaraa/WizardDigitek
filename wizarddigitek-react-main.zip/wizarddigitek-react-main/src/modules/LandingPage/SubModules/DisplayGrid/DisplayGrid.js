import React from 'react'
import Card1 from './Card1'
import Card2 from './Card2'
import Card3 from './Card3'
import Card4 from './Card4'
import Card5 from './Card5'
import Card6 from './Card6'

const DisplayGrid = () => {
  return (
    <div className='DisplayGridCont'>
        <div className="display-contaner"
        style={{cursor: 'default'}}>
            <div className="divc1">
                <Card1/>
            </div>
            <div className="divc2">
                <Card2/>
            </div>
            <div className="divc3">
                <Card3/>
            </div>
            <div className="divc4">
                <Card4/>
            </div>
            <div className="divc5">
                <Card5/>
            </div>
            <div className="divc6">
                <Card6/>
            </div>
        </div>
    </div>
  )
}

export default DisplayGrid
