import React from "react";

const Card1 = () => {
 return (
  <div className="CardDG">
   <div id="bgdg1">No Fees Not Even Hidden Ones</div>
  </div>
 );
};

export default Card1;
