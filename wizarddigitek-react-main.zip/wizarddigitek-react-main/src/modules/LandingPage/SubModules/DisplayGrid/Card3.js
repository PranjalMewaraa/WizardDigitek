import downcg from '../../../../assets/Images/downcg.png'
const Card3 = () => {
    return (
      <div className='CardDG3'>
            <div id="bgdg3">
                Get 20% Off on Refurbish Device Sell/Purchase <br />
                <span style={{fontSize:".8vmax"}}>Check out now</span>
            </div>
            <img src={downcg} alt="" />
      </div>
    )
  }
  
  export default Card3
  