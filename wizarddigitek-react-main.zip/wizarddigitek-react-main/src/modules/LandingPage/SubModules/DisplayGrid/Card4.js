import React from 'react'
import barbtm from '../../../../assets/Images/barbtm.png'
const Card4 = () => {
  return (
    <div className='CardDG4'>
      <div id="bgdg4">
      Our E.M.I Tools to help you make financially healthy choices.
      </div>
      <img src={barbtm} alt="" />
    </div>
  )
}

export default Card4
