import React from 'react'
import lck from '../../../../assets/Images/lck.png'
const Card6 = () => {
  return (
    <div className='CardBG6'>
        <div className="upp6">
            <img src={lck} alt="" />
            <div id="subtct">Apple privacy <br /> and security</div>
        </div>
        <div className="btm6">
            Your card. <br />
            Your data. <br /> 
            Your business. <br />
        </div>
    </div>
  )
}

export default Card6
