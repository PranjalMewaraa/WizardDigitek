import React from 'react'
import EmiCalc from './EmiCalc'
import '../LandingPage.css'
const EmiCalcDiv2 = () => {
  return (
    <div className='EmiCont'>
      <div className="emidiv2">
        <div className="e2left">
            <div className="texte">
                <div id="titleee2">Tool</div>
                <div id="title22" >Check this Special E.M.I Calculator.</div>
                <div id="linkte2">Check our Self-customized EMI Calculator and choose the best option suitable for you. </div>
            </div>
        </div>
        <div className="eright2">
            <div className="emiCalci">
              <EmiCalc/>
            </div>
        </div>
      </div>
    </div>
  )
}

export default EmiCalcDiv2
