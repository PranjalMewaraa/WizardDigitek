import React from 'react'
import './CatGrid.css'
import catApple from '../../../assets/Images/catIcon.png'
import catHead from '../../../assets/Images/catHead.png'
import speaker from '../../../assets/Images/speaker.png'
import catMob from '../../../assets/Images/catMob.png'
import catLap from '../../../assets/Images/CatLap.png'
import catW from '../../../assets/Images/CatW.png'
import catE from '../../..//assets/Images/CatEar.png'
import speakerTable from '../../../assets/Images/speakerTable.png'
import { Link } from 'react-router-dom'
const CateGrid = () => {
    return (
        <div className='GridSectionX'>
            <div className="parentgrd">
                <Link to={'/apple'} className="divApplex noTextDecor">
                    <div className="cat1Text">
                        <div id="applehead">iPhone @ Cheapest</div>
                        <div id="appleSubhead">Get imported iphones at cheaper rate</div>
                    </div>
                    <img src={catApple} alt="" />
                </Link>
                <Link to={'/headphone'} className="divHeadphonex noTextDecor">
                    <img src={catHead} alt="" id='cathead' />
                    <div className="cat3Text">
                        <div id="Hhead">Noise Cancellation</div>
                        <div id="HSubhead">Get Premium <br></br>Wireless headsets </div>
                    </div>
                </Link>
                <Link to={'/smartphones'} className="divMobilex noTextDecor">
                    <div className="cat4Text">
                        <div id="applehead">Get The Best Smartphones</div>
                        <div id="appleSubhead">New and Refurbished</div>
                    </div>
                    <img src={catMob} alt="" id='catMobx' />
                </Link>
                <Link to={'/speakers'} className="divSpeakerx noTextDecor">
                    <div className="cat2Text">
                        <div id="Hhead">Noise Cancellation</div>
                        <div id="HSubhead">Get Premium <br></br>Wireless headsets </div>
                    </div>
                    <img src={speaker} alt="" id='mainSpeakerx' />
                    <img id="spt" src={speakerTable} alt="" style={{ zIndex: "1", transform: "translateY(0%)" }} />
                </Link>
                <div className="divLapAndWatch">
                    <Link to={'/laptop-TV'} className="divLaptopx noTextDecor">
                        <div className="textLapx">
                            <div id="subhead">Get the Best Prices on</div>
                            <div id="head">Tv & Laptops</div>
                        </div>
                        <div className="imgLapx">
                            <img src={catLap} alt="" style={{ width: "80%", transform: "translate(15%,15%)" }} />
                        </div>
                    </Link>
                    <Link to={'/smartwatches'} className="divWatchx noTextDecor">
                        <div className="imgW">
                            <img src={catW} alt="" id='ww' />
                        </div>
                        <div className="textW">
                            <div id="subhead">Exclusive Range of</div>
                            <div id="head">SmartWatches</div>
                            <div id="subhead2">Explore Best Deals Now</div>
                        </div>
                    </Link>
                </div>
                <Link to={'/earphone'} className="divEarphone noTextDecor">
                    <div className="textE">
                        <div id="head">Earbuds and Earphone</div>
                        <div id="subhead">Premium Quality</div>
                    </div>
                    <div className="ImageE">
                        <img src={catE} alt="" id='imgE' />
                    </div>
                </Link>
            </div>
        </div>
    )
}
export default CateGrid
