import React, { useState } from "react";
import robo from "../../../assets/Images/robot.png";
import FrameCT from "./FrameCT";
import ph from "../../../assets/Images/phoneico.png";
import mail from "../../../assets/Images/mailico.png";
import fax from "../../../assets/Images/faxico.png";
import "../LandingPage.css";
const ContactSect = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [msg, setMsg] = useState("");

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePhoneChange = (e) => {
    setPhone(e.target.value);
  };

  const handleMessageChange = (e) => {
    setMsg(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const message = `Hey I am ${name}, I have query which is ${msg}  and my contact details are Phone:${phone} Email:${email}`;
    const phoneNumber = "7827999788";
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `whatsapp://send?phone=${phoneNumber}&text=${encodedMessage}`;

    const newTab = window.open(whatsappUrl, "_blank");

    // If the browser blocks the new tab, provide a fallback link
    if (!newTab) {
      window.location.href = whatsappUrl;
    }
  };

  return (
    <div className="ContSectContainer">
      <div className="boxCf">
        <div className="leftcf">
          <img src={robo} alt="" id="lcfimg" />
        </div>
        <div className="rightcf">
          <div className="contform">
            <div id="cftt">
              Get in <span style={{ color: "#CF75FF" }}>Touch</span>
            </div>
            <form id="formct" action="">
              <input
                type="text"
                placeholder="Name"
                onChange={handleNameChange}
              />
              <br />
              <input
                type="Email"
                placeholder="Phone"
                onChange={handlePhoneChange}
              />
              <br />
              <input
                type="phone"
                placeholder="Email"
                onChange={handleEmailChange}
              />
              <br />
              <input
                type="textarea"
                placeholder="Your Message Here"
                maxLength={500}
                onChange={handleMessageChange}
              />
              <button id="subbtn" onClick={handleSubmit}>
                Submit
              </button>
            </form>
            <div id="iiconct">
              <FrameCT img={ph} title="Phone" info="7827999788" />
              <FrameCT img={mail} title="Mail @" info="wizard1.digitek" />
              <FrameCT img={fax} title="Fax" info="03 5432 1234" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSect;
