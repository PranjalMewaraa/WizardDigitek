import React from 'react'
import NavBar from '../../components/NavBar/NavBar'
import Footer from '../../components/Footer/Footer'
import Brandsaa from '../LandingPage/SubModules/Brands'

const Brands = () => {
  return (
    <div>
        <NavBar/>
        <Brandsaa/>
        <Footer/>
      
    </div>
  )
}

export default Brands
