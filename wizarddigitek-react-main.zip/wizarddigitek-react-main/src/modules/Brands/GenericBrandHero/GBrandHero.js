
import ligb from '../../../assets/Images/ligb.png'
import rigb from '../../../assets/Images/rigb.png'
const GBrandHero = () => {
    return (
        <div className='HeroGBrand' >
            <img id='ligb' src={ligb} alt="" />
            <div className="textgbb">
                <h1 id='h4gb'><i>Get your favorite <span id='brID'> Brands</span></i></h1>
                <p id='wizs'>@ your own store <span id='wizss'>WizardDigitek</span></p>
            </div>
            <div id='rgb'>
                <img id='rigb' src={rigb} alt="" />
            </div>
        </div>
    )
}
export default GBrandHero
