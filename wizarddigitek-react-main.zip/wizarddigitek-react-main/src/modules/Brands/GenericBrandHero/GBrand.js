import React from "react";
import NavBar from "../../../components/NavBar/NavBar";
import GBrandHero from "./GBrandHero";
import "./GB.css";
import MainSection from "../../../components/MainSection/MainSection";
import Footer from "../../../components/Footer/Footer";
import { useParams } from "react-router-dom";

const GBrand = () => {
  const { id } = useParams();
  console.log(id);
  return (
    <>
      <NavBar />
      <GBrandHero />
      <MainSection searchTerm={id ? id : "products"} />
      <Footer />
    </>
  );
};
export default GBrand;
