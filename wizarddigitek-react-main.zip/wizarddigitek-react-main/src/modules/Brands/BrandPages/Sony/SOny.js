import React from "react";
import "./Sony.css";
import sbg from "../../../../assets/Images/sonybg.png";
import NavBar from "../../../../components/NavBar/NavBar";
import Footer from "../../../../components/Footer/Footer";
import MainSection from "../../../../components/MainSection/MainSection";
import HCarousel from "./HCarousel";
const SOny = () => {
  return (
    <>
      <NavBar />
      <div className="SonyPage">
        <div className="carsony">
          <HCarousel />
        </div>
      </div>
      <MainSection
        pageType={"Brand"}
        categoryName={"Sony"}
        Aid="95765d93-308b-404c-960c-00b0b68d0c74"
      />
      <Footer />
    </>
  );
};
export default SOny;
