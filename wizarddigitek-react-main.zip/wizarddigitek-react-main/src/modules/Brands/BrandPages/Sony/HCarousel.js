import React, { useState } from 'react';
import './Sony.css'; // Import your CSS file for styling
import h1 from '../../../../assets/Images/h1.png'
import h2 from '../../../../assets/Images/h3.png'
import h3 from '../../../../assets/Images/h2.png'
import h4 from '../../../../assets/Images/h4.png'
import leftimg from '../../../../assets/Images/imagel.png'
import rightimg from '../../../../assets/Images/imager.png'
const HCarousel = () => {
    const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
    const images = [
      h1,
      h2,
      h3,
      h4
      // Add more image URLs as needed
    ];
  
    const prevImage = () => {
      setCurrentImageIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
    };
  
    const nextImage = () => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    };
  
    return (
      <div className="carousel-container">
        <div className="crsl">
            <img src={images[currentImageIndex]} alt="" />
        </div>
        <div className='btngpsony'>
            <img src={leftimg} alt="" onClick={prevImage}/>
            <img src={rightimg} alt="" onClick={nextImage}/>
        </div>
      </div>
    );
  };
export default HCarousel;
