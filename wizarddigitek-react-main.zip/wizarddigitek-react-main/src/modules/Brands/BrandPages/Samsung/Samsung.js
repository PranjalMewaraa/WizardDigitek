import React from "react";
import "./Samsung.css";
import sbg from "../../../../assets/Images/samsungbg.png";
import NavBar from "../../../../components/NavBar/NavBar";
import Footer from "../../../../components/Footer/Footer";
import glxy from "../../../../assets/Images/glxyimg.png";
import MainSection from "../../../../components/MainSection/MainSection";
const Samsung = () => {
  return (
    <>
      <NavBar />
      <div className="Samsung">
        <div className="heroSamsung">
          <img src={sbg} alt="" />
          <div className="textsaams">
            <p id="ftr">featuring</p>
            <p id="btmtxtsams">
              The all new <br />
              <span color="Red">Galaxy</span> <br />
              Series now
            </p>
          </div>
          <div className="btmSam">
            Scroll below and checkout awesome range of products from Samsung
          </div>
        </div>
      </div>
      <div className="hero2Sams">
        <div
          style={{
            width: "80%",
            height: "80%",
            position: "relative",
            maxWidth: "1441px",
            margin: "0 auto",
          }}
        >
          <div
            style={{
              width: "100%",
              height: "20%",
              position: "absolute",
              fontSize: "13vmax", // Responsive font size
              fontFamily: "Clash Display Variable",
              fontWeight: 600,
              wordWrap: "break-word",
              textAlign: "center",
              top: "5%",
            }}
          >
            Galaxy S+
          </div>
          <div
            style={{
              width: "100%",
              height: "40%",
              position: "absolute",
              left: "0",
              top: "25%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
              alignItems: "center",
              gap: "5%",
              transform: "translateY(-15%)",
            }}
          >
            <img src={glxy} alt="Galaxy S+ Placeholder" />
          </div>
        </div>
      </div>
      <MainSection
        pageType={"Brand"}
        categoryName={"Samsung"}
        Aid="75f02c95-9448-4226-80c7-c413a974d265"
      />
      <Footer />
    </>
  );
};

export default Samsung;
