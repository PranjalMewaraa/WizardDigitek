 import React from 'react'
import NavBar from '../../components/NavBar/NavBar'
import HeroCat from './Submodules/HeroCat/HeroCat'
import CategoryGrid from '../LandingPage/SubModules/CategoryGrid'
import './Category.css'
import Footer from '../../components/Footer/Footer'
import CateGrid from '../LandingPage/SubModules/CateGrid'
const CategoryPage = () => {
  return (
    <div className='CategoryPage'> 
      <NavBar/>
      <HeroCat/>
      <CateGrid/>
      <Footer/>
    </div>
  )
}

export default CategoryPage
