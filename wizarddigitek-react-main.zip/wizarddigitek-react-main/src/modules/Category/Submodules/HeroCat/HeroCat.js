import React from "react";
import "./HeroCat.css";
import mid from "../../../../assets/Images/vectorplay.png";
const HeroCat = () => {
  return (
    <div className="HeroCategory">
      <div className="imgbg"></div>
      <div className="upplayr">
        <div className="topherocat">
          Tech Treasures Await: Dive into our Electronic Oasis!
        </div>
        <div className="botherocat">
          <div className="framex"></div>
        </div>
      </div>
    </div>
  );
};

export default HeroCat;
