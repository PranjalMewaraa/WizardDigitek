import React from 'react'
import NavBar from '../../components/NavBar/NavBar'
import Footer from '../../components/Footer/Footer'
import CateGrid from '../LandingPage/SubModules/CateGrid'


const Category = () => {
  return (
    <div>
        <NavBar/>
        <CateGrid/>
        <Footer/>
    </div>
  )
}

export default Category
