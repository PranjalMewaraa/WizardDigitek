import React from 'react';
import './CatLaptopTvGrid.css'


const CatLaptopTvGrid = () => {
    return (
        <div className='cat-laptop-tv-grid-cont'>
            <div className='cat-laptop-tv-grid'>
                <div className="cat-laptop-tv-grid-left">
                    <img className="cat-laptoptv-grid-card laptop-tv-grid-left-img" src={require("../../../../assets/Images/LaptopTV/grid1.png")} alt="see beyond the game" />
                </div>
                <div className="cat-laptop-tv-grid-right">
                    <span className="cat-laptop-tv-grid-right-top">
                        <img className="cat-laptoptv-grid-card laptop-tv-grid-right-img1" src={require("../../../../assets/Images/LaptopTV/grid2-top.png")} alt="rog strix scar" />
                    </span>
                    <span className="cat-laptop-tv-grid-right-bottom">
                        <img className="cat-laptoptv-grid-card laptop-tv-grid-right-img2" src={require("../../../../assets/Images/LaptopTV/grid2-bl.png")} alt="Mi Notebook Pro" />
                        <img className="cat-laptoptv-grid-card laptop-tv-grid-right-img3" src={require("../../../../assets/Images/LaptopTV/grid2-br.png")} alt="Flat is Back" />
                    </span>
                </div>
            </div>

        </div>
    );
};

export default CatLaptopTvGrid;