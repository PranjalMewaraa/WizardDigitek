import React from 'react';

const HeroMonitor = () => {
    return (
        <div className='cat-monitor-hero'>
            <div className="cat-monitor-hero-left">
                <h2 className="cat-monitor-hero-top-head">GET THE BEST DEALS *</h2>
                <h1 className="cat-monitor-hero-title">Best Monitor and TV Collection of 2023</h1>
                <h3 className="cat-monitor-hero-subtitle">All sizes @ Cheapest prices</h3>

                <button className="cat-monitor-hero-btn">Check Out</button>
            </div>

            <div className="cat-monitor-hero-right">
                <img className="cat-monitor-hero-img" src={require('../../../../assets/Images/LaptopTV/monitorHero.webp')} alt="laptops" />
            </div>
        </div>
    );
};

export default HeroMonitor;