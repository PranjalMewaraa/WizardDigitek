import React from 'react';

const HeroLaptop = () => {
    return (
        <div className='cat-laptop-hero'>
            <div className="cat-laptop-hero-left">
                <h2 className="cat-laptop-hero-top-head">NEW ARRIVALS</h2>
                <h1 className="cat-laptop-hero-title">Best Laptop Collection of 2023</h1>
                <h3 className="cat-laptop-hero-subtitle">at cheapest prices</h3>

                <button className="cat-laptop-hero-btn">Check Out</button>
            </div>

            <div className="cat-laptop-hero-right">
                <img className="cat-laptop-hero-img" src={require('../../../../assets/Images/LaptopTV/laptop.png')} alt="laptops" />
            </div>
        </div>
    );
};

export default HeroLaptop;