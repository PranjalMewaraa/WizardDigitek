import React, { useState } from "react";
import "./LaptopTV.css";
import NavBar from "../../../components/NavBar/NavBar";
import MainSection from "../../../components/MainSection/MainSection";
import Footer from "../../../components/Footer/Footer";
import HeroLaptop from "./SubModules/HeroLaptop";
import CatLaptopTvGrid from "./SubModules/CatLaptopTvGrid";
import HeroMonitor from "./SubModules/HeroMonitor";

const Laptop_TV = () => {
  const [activePage, setActivePage] = useState("Laptops");

  const handleTabClick = (tab) => {
    setActivePage(tab);
  };

  return (
    <div>
      <NavBar />
      <div className="laptop-monitor-toggle">
        <div className="laptop-monitor-toogle-text">
          <p
            className={activePage === "Laptops" ? `bold-text` : null}
            onClick={() => handleTabClick("Laptops")}
          >
            Laptops
          </p>
          <p
            className={activePage === "TV" ? `bold-text` : null}
            onClick={() => handleTabClick("TV")}
          >
            Monitors
          </p>
        </div>

        {activePage === "Laptops" ? <HeroLaptop /> : <HeroMonitor />}
      </div>
      <CatLaptopTvGrid />
      {activePage === "Laptops" ? (
        <MainSection categoryName={activePage} pageType={"Type"} />
      ) : (
        <MainSection categoryName={activePage} pageType={"Type"} />
      )}

      <Footer />
    </div>
  );
};

export default Laptop_TV;
