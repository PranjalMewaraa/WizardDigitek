import React from "react";
import NavBar from "../../../components/NavBar/NavBar";
import MainSection from "../../../components/MainSection/MainSection";
import Footer from "../../../components/Footer/Footer";

import "./Speakers.css";
import HeroSpeakers from "./SubModules/HeroSpeakers";

const Speakers = () => {
  return (
    <div>
      <NavBar />
      <HeroSpeakers />
      <MainSection categoryName={"Speakers"} pageType={"Type"} />
      <Footer />
    </div>
  );
};

export default Speakers;
