import React from 'react';
import SpeakerTop from './../../../../assets/Images/Speakers/speaker-top.png'

const HeroSpeakers = () => {
    return (
        <div className='cat-speakers-hero'>
            <span className='cat-speakers-hero-img-cont'>
                <img className='cat-speakers-hero-img' src={SpeakerTop} alt="hero-speakers" />
            </span>
            <div className="center-text-speakers">
                <h1 className='cat-speakers-hero-title'>SPEAKERS</h1>
                <div className="cat-speakers-hero-buttons">
                    <button className="SpeakersCompactButton">Compact</button>
                    <button className="SpeakersFullSizeButton">Full Size</button>
                </div>
                <p className="cat-speakers-hero-subtitle">How to get the best Sound?</p>
            </div>
        </div>
    );
};

export default HeroSpeakers;