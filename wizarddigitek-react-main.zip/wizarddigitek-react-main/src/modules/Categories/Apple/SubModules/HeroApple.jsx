import React, { useState } from 'react';
import './CircularApple.css'

const HeroApple = () => {

    const AppleItems = [
        {
            id: 0,
            name: 'iPhone 15 ',
            text: 'Starting    @   ₹ 79,999',
            img: require('../../../../assets/Images/Apple/iphone15.png'),
        },
        {
            id: 1,
            name: 'iPhone 15 Pro ',
            text: 'Starting    @   ₹ 85,999',
            img: require('../../../../assets/Images/Apple/iphone15pro.png'),
        },
        {
            id: 2,
            name: 'iPhone 14',
            text: 'Starting    @   ₹ 69,999',
            img: require('../../../../assets/Images/Apple/iphone14.png'),
        },
        {
            id: 3,
            name: 'iPhone 14 Pro Max',
            text: 'Starting    @   ₹ 1,48,999',
            img: require('../../../../assets/Images/Apple/iphone14promax.png'),
        },
        {
            id: 4,
            name: 'iPhone 14 pro ',
            text: 'Starting    @   ₹ 1,08,999',
            img: require('../../../../assets/Images/Apple/iphone14pro.png'),
        },
        {
            id: 5,
            name: 'iPhone 14  Refurbished',
            text: 'Starting    @   ₹ 38,999',
            img: require('../../../../assets/Images/Apple/iphone14refurb.png'),
        },
    ]

    const [activeIndex, setActiveIndex] = useState(0);

    const updateIndex = (newIndex) => {
        if (newIndex < 0) {
            newIndex = AppleItems.length - 1;
        } else if (newIndex > AppleItems.length - 1) {
            newIndex = 0;
        }

        setActiveIndex(newIndex);

    };


    return (
        <div className='Hero-Apple-Cat'>
            <div className="cat-apple-upper">

                <span className='catAppleLogoContainer'>
                    <img className='catAppleLogo' src={require('./../../../../assets/Images/appleLogo.png')} alt="appleLogo" />
                </span>

                {/* Iphone Model */}
                <span className='catAppleTitle'>
                    {AppleItems.map((item, index) => {
                        return <h1
                            style={{
                                transform: `translateY(-${activeIndex * (14.5)}vmin)`,
                            }}>
                            {item.name}
                        </h1>
                    })}
                </span>

                {/* Iphone Price */}
                <span className='catAppleTitlePrice'>
                    {AppleItems.map((item, index) => {
                        return <h2
                            style={{
                                transform: `translateY(-${activeIndex * (12)}vmin)`,
                            }}>
                            {item.text}
                        </h2>
                    })}
                </span>
            </div>

            <div className="cat-apple-lower">

                <span className='catAppleCarousel'>
                    {AppleItems.map((item, index) => {
                        const dynamicHeight = document.querySelector('.appleCarouselImgCont')?.clientHeight || 0;
                            return (
                                <div className="appleCarouselImgCont" 
                                style={{
                                    transform: `translateY(-${activeIndex * dynamicHeight}px)`,
                                }}
                                >
                                    <img src={item.img} alt={item.name} className='appleCarouselImg'/>
                                </div>

                            )
                        })}
                </span>
            </div>



            {/* CUSTOM Circular Positioning */}
            {/* <div className="cat-apple-lower">
                <div className="apple-carousel-cont">
                    <p>h1</p>
                    <img className="apple-img-3 car-apple-img" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car3.png')} />
                    <img className="apple-img-2 car-apple-img" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car2.png')} />
                    <img className="apple-img-1 car-apple-img" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car1.png')} />
                    <img className="apple-img-5 car-apple-img" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car5.png')} />
                    <img className="apple-img-4 car-apple-img" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car4.png')} />
                </div>
            </div> */}



            {/* ANIMA Apple Carousel Circular */}
            {/* <div className="apple-circular-cont">
                <div className="apple-linked-path-group">
                    <div className="apple-overlap">
                        <div className="apple-overlap-group">
                        
                            <img className="apple-img-1" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car1.png')} />
                            <img className="apple-img-2" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car2.png')} />
                            <img className="apple-img-3" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car3.png')} />
                            <img className="apple-img-4" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car4.png')} />
                            <img className="apple-img-5" alt="carouselImg" src={require('./../../../../assets/Images/Apple/car5.png')} />
                        </div>
                    </div>
                </div>
            </div>
 */}



            {console.log(activeIndex)}

            {/* Arrow Buttons */}
            <button onClick={() => {
                updateIndex(activeIndex - 1)
            }} className='Apple-Carousel-Arrow AppleArrowLeft'>
                <img className='Apple-Arrow-img' src={require('./../../../../assets/Images/catApplePrev.png')} alt='carouselLeft' />
            </button>


            <button onClick={() => {
                updateIndex(activeIndex + 1)
            }} className='Apple-Carousel-Arrow AppleArrowRight'>
                <img className='Apple-Arrow-img' src={require('./../../../../assets/Images/catAppleNext.png')} alt='carouselRight' />
            </button>
        </div>
    );
};

export default HeroApple;