import React from "react";

const ProductsApple = () => {
  const AppleProductsList = [
    {
      img: require("./../../../../assets/Images/Apple/macbook.png"),
      name: "MacBook",
    },
    {
      img: require("./../../../../assets/Images/Apple/ipad.png"),
      name: "iPad",
    },
    {
      img: require("./../../../../assets/Images/Apple/iphone.png"),
      name: "iPhone",
    },
    {
      img: require("./../../../../assets/Images/Apple/iwatch.png"),
      name: "iWatch",
    },
    {
      img: require("./../../../../assets/Images/Apple/airpods.png"),
      name: "Airpods",
    },
  ];

  return (
    <div className="products-apple-cat">
      <h2 className="product-apple-title">Apple Products</h2>
      <div className="product-apple-items">
        {AppleProductsList.map((item) => {
          return (
            <div>
              <img src={item.img} alt="img" className="product-apple-img" />
              <h3 className="product-apple-name">{item.name}</h3>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProductsApple;
