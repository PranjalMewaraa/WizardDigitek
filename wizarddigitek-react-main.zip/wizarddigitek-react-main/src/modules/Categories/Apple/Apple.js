import React, { useEffect, useState } from "react";
import "./Apple.css";
import NavBar from "../../../components/NavBar/NavBar";
import Footer from "../../../components/Footer/Footer";
import HeroApple from "./SubModules/HeroApple";
import ProductsApple from "./SubModules/ProductsApple";
import MainSection from "../../../components/MainSection/MainSection";
import axios from "axios";
import AppleMainSection from "../../../components/MainSection/AppleMainSection";

const API_ROUTE = "api/wizard";
const Apple = () => {
  const AppleProductsList = [
    {
      img: require("../../../assets/Images/Apple/macbook.png"),
      name: "MacBook",
    },
    {
      img: require("../../../assets/Images/Apple/ipad.png"),
      name: "iPad",
    },
    {
      img: require("../../../assets/Images/Apple/iphone.png"),
      name: "iPhone",
    },
    {
      img: require("../../../assets/Images/Apple/iwatch.png"),
      name: "iWatch",
    },
    {
      img: require("../../../assets/Images/Apple/airpods.png"),
      name: "Airpods",
    },
  ];

  const getIDApple = () => {
    //implement this fnc to get brand id by name using api call matching name and then matching
  };

  const getProd = (productTypeId) => {
    try {
      axios
        .get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?productBrandId`
        )
        .then((response) => {
          setProducts(response.data.data?.rows);
        });
    } catch (error) {
      console.log(error);
    }
  };

  const [products, setProducts] = useState([]);
  useEffect(() => {
    try {
      axios
        .get(`${process.env.REACT_APP_HOST}/${API_ROUTE}/products`)
        .then((response) => {
          setProducts(response.data.data?.rows);
        });
    } catch (error) {
      console.log(error);
    }
  }, []);

  const handleClick = () => {};

  return (
    <div>
      <NavBar />
      <HeroApple />
      <AppleMainSection pageType={"Brand"} categoryName="Apple" />
      <Footer />
    </div>
  );
};

export default Apple;
