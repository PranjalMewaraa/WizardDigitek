import React from "react";
import SmartphoneCarousel from "./SmartphoneCarousel";

const HeroSmartphone = () => {
  return (
    <div className="HeroSmartphone">
      <div className="MainSmartphone">
        <span className="MainSmartphoneHeading my-10">
          <p>Experience Excellence</p>
          <p> in every Handheld device</p>
        </span>

        {/* Carousel */}
        <div className="SmartphoneCarouselCont">
          <SmartphoneCarousel />

          <img
            className="SmartphoneAnimationImg"
            src={require("./../../../../assets/Images/SmartphoneCarousel/m04.png")}
            alt="Phone Animation"
          />
        </div>
      </div>
    </div>
  );
};

export default HeroSmartphone;
