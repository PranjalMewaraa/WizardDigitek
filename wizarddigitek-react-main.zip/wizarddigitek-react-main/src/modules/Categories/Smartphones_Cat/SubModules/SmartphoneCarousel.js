import React, { useEffect, useState } from 'react';
import SmartphoneCarouselItem from './SmartphoneCarouselItem';
import './SPcarousel.css'


const SmartphoneCarousel = () => {


    const items = [

        {
            id: 0,
            model: "",
            price: "",
            img: require('../../../../assets/Images/transparent.png'),
        },
        {
            id: 1,
            model: "Xiomi POCO Smartphone",
            price: "Rs 23,500 /-",
            img: require('../../../../assets/Images/SmartphoneCarousel/poco.png'),
        },
        {
            id: 2,
            model: "IPhone 14 Pro Max 128GB",
            price: "Rs 89,999 /-",
            img: require('../../../../assets/Images/SmartphoneCarousel/iphone14promax.png'),
        },
        {
            id: 3,
            model: "Samsung M04 Smartphone",
            price: "Rs 32,999 /-",
            img: require('../../../../assets/Images/SmartphoneCarousel/m04.png'),
        },
        {
            id: 4,
            model: "Samsung Galaxy S23 Ultra",
            price: "Rs 89,999 /-",
            img: require('../../../../assets/Images/SmartphoneCarousel/s23ultra.png'),
        },
        {
            id: 5,
            model: "Vivo Smartphone XSR 5G",
            price: "Rs 35,999 /-",
            img: require('../../../../assets/Images/SmartphoneCarousel/vivo_xsr.png'),
        },
    ]
    const [activeIndex, setActiveIndex] = useState(2);

    const updateIndex = (newIndex) => {
        if (newIndex < 0) {
            newIndex = 0;
        } else if (newIndex >= items.length-1) {
            newIndex = items.length - 2;
        }

        setActiveIndex(newIndex);
    };

    useEffect(() => {
        // Set the initial position to center the middle phone
        updateIndex(activeIndex);
    }, []);

    return (
        <div className='SmartphoneCarousel'>
            <div className='SP-Carousel-inner'
                style={{
                    transform: `translateX(-${activeIndex  * (18+9.8)}vmax)`,
                }}
            >
                {items.map((item,index) => {
                    return <SmartphoneCarouselItem key={item.id} item={item} index={index} activeIndex={activeIndex}/>
                })}
            </div>

                {/* <img src={items[5].img}/> */}

            {/* Arrow Buttons */}
            <button onClick={() => {
                updateIndex(activeIndex - 1)
            }} className='SP-Carousel-Arrow ArrowLeft'>
                <img className='SP-Arrow-img' src={require('./../../../../assets/Images/Carousel_left.png')} alt='carouselLeft' />
            </button>


            <button onClick={() => {
                updateIndex(activeIndex + 1)
            }} className='SP-Carousel-Arrow ArrowRight'>
                <img className='SP-Arrow-img' src={require('./../../../../assets/Images/Carousel_right.png')} alt='carouselRight' />
            </button>


            {/* Active Index Number */}
            <div className='SP-Carousel-indicators'> 
                <p className={items[activeIndex].id === activeIndex ? `SP-Model-Name SP-ModelPrice-active` : `SP-Model-Name`}>
                    {items[activeIndex+1].model}
                </p>
               

                {/* {console.log(items[activeIndex].id, activeIndex)} */}
                
                
                <p className={items[activeIndex].id === activeIndex ? `SP-Model-Price SP-ModelPrice-active` : `SP-Model-Price`}>
                    {items[activeIndex+1].price}
                </p>
                
            </div>
        </div>
    );
};

export default SmartphoneCarousel;