import React from 'react';

const SmartphoneCarouselItem = ({item,index,activeIndex}) => {
    return (
        <div className='SP-Carousel-item'>
            <img className={index-1 === activeIndex ? `SP-Carousel-img-active` : `SP-Carousel-img` } src={item.img} alt="Smartphone Carousel Item"/>
        </div>
    );
};

export default SmartphoneCarouselItem;