import React from "react";
import NavBar from "./../../../components/NavBar/NavBar";
import Footer from "../../../components/Footer/Footer";
import HeroSmartphone from "./SubModules/HeroSmartphone";

import "./Smartphone.css";
import MainSection from "./../../../components/MainSection/MainSection";

const Smartphone = () => {
  return (
    <div>
      <NavBar />
      <HeroSmartphone />
      <MainSection categoryName={"Mobile"} pageType={"Type"} />
      <Footer />
    </div>
  );
};

export default Smartphone;
