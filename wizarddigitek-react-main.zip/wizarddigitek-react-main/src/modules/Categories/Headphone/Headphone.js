import React, { useState, useEffect } from "react";
import hp1 from "../../../assets/Images/hp1.png";
import hp2 from "../../../assets/Images/hp2.png";
import hp3 from "../../../assets/Images/hp3.png";
import hp4 from "../../../assets/Images/hp4.png";
import "../../LandingPage/LandingPage.css";
import NavBar from "../../../components/NavBar/NavBar";
import MainSection from "../../../components/MainSection/MainSection";
import Footer from "../../../components/Footer/Footer";

const heroData = [
  {
    id: 1,
    title: "Wireless",
    img: hp1,
    bg: "#FFF",
  },
  {
    id: 2,
    title: "Wireless",
    img: hp2,
    bg: "#1F7B6C",
  },
  {
    id: 3,
    title: "Wireless",
    img: hp3,
    bg: "#B83636",
  },
  {
    id: 4,
    title: "Wireless",
    img: hp4,
    bg: "#A86FD8",
  },
];

const Headphone = () => {
  const [currentHeroIndex, setCurrentHeroIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentHeroIndex((prevIndex) => (prevIndex + 1) % heroData.length);
    }, 2500);

    return () => clearInterval(intervalId);
  }, []);

  const currentHero = heroData[currentHeroIndex];

  return (
    <div className="HeadphonePage">
      <NavBar />
      <div className="HeadHero">
        <div
          className="hero-container"
          style={{ backgroundColor: currentHero.bg, color: currentHero.bg }}
        >
          <div className="teh">
            Find Your Beats now
            <br />{" "}
            <button
              style={{
                backgroundColor: "#feed",
                fontSize: "1vmax",
                padding: "1vmax",
                borderRadius: "20px",
                border: "1px solid #707070",
              }}
            >
              Check out
            </button>
          </div>
          <div className="tehs">Shop Range of Headphones</div>
          <div className="imgh">
            {heroData.map((hero, index) => (
              <img key={index} src={hero.img} alt="" />
            ))}
          </div>
          <div className="textH">
            <div className="headtexth">{currentHero.title}</div>
          </div>
        </div>
      </div>
      <MainSection categoryName={"Headphones"} pageType={"Type"} />
      <Footer />
    </div>
  );
};

export default Headphone;
