import React from 'react';

const HeroSmartwatches = () => {

    const Features = [
        {
            id: 0,
            title: 'Distance',
            img: require('../../../../assets/Images/smartwatches/distance.png')
        },
        {
            id: 1,
            title: 'Calories',
            img: require('../../../../assets/Images/smartwatches/calories.png')
        },
        {
            id: 2,
            title: 'Heart Rate',
            img: require('../../../../assets/Images/smartwatches/heartRate.png')
        },
        {
            id: 3,
            title: 'Record',
            img: require('../../../../assets/Images/smartwatches/record.png')
        },
        {
            id: 4,
            title: 'Step Count',
            img: require('../../../../assets/Images/smartwatches/stepCount.png')
        },
        {
            id: 5,
            title: 'Exercise',
            img: require('../../../../assets/Images/smartwatches/exercise.png')
        }
    ]


    return (
        <div className='cat-smartwatches-hero'>
            <span className='smartwatch-hero-bg-animation'>
                <img className='smartwatches-hero-bg' src={require('./../../../../assets/Images/smartwatches/HeroBigWatch.png')} alt="hero smartwatch background"/>
                <img className='smartwatches-hero-logo' src={require('./../../../../assets/Images/smartwatches/digitekLogo.png')} alt="" />
            </span>

            <div className='smartwatches-main-content'>
                <div className='smartwatches-hero-text'>
                    <h1 className='smartwatches-hero-title'>Elevate Your Lifestyle with Every Tick.</h1>
                    <p className='smartwatches-hero-subtitle'>The Future on Your Wrist.</p>

                    <button className='smartwatches-hero-btn'>
                        explore smartwatches
                    </button>
                </div>


                <div className='smartwatches-hero-img'>
                    <img className='smartwatches-hero-threewatches' src={require('./../../../../assets/Images/smartwatches/threeWatches.png')} alt="three watches
                    " />
                </div>
            </div>

            <div className="smartwatches-features-container">
                {Features.map((item,index)=>{
                    return <div className='smartwatches-features-card' key={index}>
                        <img className='smartwatches-features-img' src={item.img} alt={item.title} />
                        <p className='smartwatches-features-title'>{item.title}</p>
                    </div>
                })}
            </div>
        </div>
    );
};

export default HeroSmartwatches;