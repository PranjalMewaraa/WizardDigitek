import React from "react";

import MainSection from "./../../../components/MainSection/MainSection";
import Footer from "./../../../components/Footer/Footer";

import "./Smartwatches.css";
import NavBar from "../../../components/NavBar/NavBar";
import HeroSmartwatches from "./SubModules/HeroSmartwatches";

const Smartwatches = () => {
  return (
    <div>
      <NavBar />
      <HeroSmartwatches />
      <MainSection categoryName={"Smartwatches"} pageType={"Type"} />
      <Footer />
    </div>
  );
};

export default Smartwatches;
