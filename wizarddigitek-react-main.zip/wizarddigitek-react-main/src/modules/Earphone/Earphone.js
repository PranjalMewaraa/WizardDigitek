import React from "react";
import "./eph.css";
import NavBar from "../../components/NavBar/NavBar";
import Footer from "../../components/Footer/Footer";
import MainSec from "../../components/MainSection/MainSection";
import HeroEar from "./Submodules/HeroEar";
import MainSection from "../../components/MainSection/MainSection";
const Earphone = () => {
  return (
    <div className="EarPage">
      <NavBar />
      <HeroEar />
      <MainSection
        categoryName={"Earphones"}
        pageType={"Type"}
        Aid="531bb7a6-da73-408b-b394-9d4eb3ca376f"
      />
      <Footer />
    </div>
  );
};

export default Earphone;
