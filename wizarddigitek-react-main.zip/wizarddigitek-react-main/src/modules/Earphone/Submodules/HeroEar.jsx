import React, { useState, useEffect } from 'react'
import ep1 from '../../../assets/Images/ep1.png'
import ep2 from '../../../assets/Images/ep2.png'
import ep3 from '../../../assets/Images/ep3.png'
import ep4 from '../../../assets/Images/ep4.png'
import ep5 from '../../../assets/Images/ep5.png'
import { CCarousel,CImage, CCarouselCaption, CCarouselInner, CCarouselItem } from '@coreui/react';

const HeroEar = () => {
    const words = ['pTrons', 'Airpod 2', 'iGear Tuna', 'Airpod 3', 'Boat'];
    const bg = [
        'radial-gradient(50% 50% at 50% 50%, #003163 0%, #021629 100%)',
        'radial-gradient(50% 50% at 50% 50%, #E0F0FF 0%, #FFF 100%)',
        'radial-gradient(50% 50% at 50% 50%, #E0F0FF 0%, #FFF 100%)',
        'radial-gradient(50% 50% at 50% 50%, #E0F0FF 0%, #FFF 100%)',
        'radial-gradient(50% 50% at 50% 50%, #68676D 0%, #30303A 100%)',
    ];
    const slides = [
        { image: ep1 },
        { image: ep2 },
        { image: ep4 },
        { image: ep3 },
        { image: ep5 },
        // Add more slides as needed
      ];

    const img = [ep1, ep2, ep4, ep3, ep5]
    const left = ["Hear the world", "Tune In", "Music", "Dive into", "Sound"]
    const right = ["Feel the beat", "Tune Out", "Reimagined", "Pure Sound", "Style"]
    const [index, setIndex] = useState(0);

    return (
        <div className='HeroEar' style={{ background: bg[index] }}>
            <div className="row1e">
                
                <h4 id='stst1'>Feel the Beats</h4>
                <img src={img[0]} alt="" />
                <h4 id='stst2'>Hear the World</h4>

            </div>

            <h6 id='ststst'>Explore the trendy sets of earphone here</h6>
        </div>
    )
}

export default HeroEar
