import React from 'react';
import CurvedText from 'react-curved-text';

const CircularText = ({ words }) => {
  const containerWidth = 300;
  const containerHeight = 300;
  const centerX = containerWidth / 2;
  const centerY = containerHeight / 2;
  const radius = 150;

  return (
    <div style={{ position: 'relative', width: `${containerWidth}px`, height: `${containerHeight}px` }}>
      {words.map((word, index) => {
        const angle = (index * (360 / words.length) * Math.PI) / 180;
        const x = centerX + radius * Math.cos(angle);
        const y = centerY + radius * Math.sin(angle);

        return (
          <CurvedText
            key={index}
            text={word}
            radius={radius}
            rx={radius}
            ry={radius}
            width={containerWidth}
            height={containerHeight}
            angle={0} // Set angle to 0 to avoid additional rotation
            cx={x}
            cy={y}
            style={{
              position: 'absolute',
              transform: 'translate(-50%, -50%)',
            }}
          />
        );
      })}
    </div>
  );
};

export default CircularText;
