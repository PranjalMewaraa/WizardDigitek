import React, { useState } from "react";
import "./login.css";
import ApiCall from "../../service/ApiCall";
import wizardLogo from "../../assets/Images/wzLogo.svg";
import Authentication from "../../service/Authentication";
import { useNavigate } from "react-router";
const Login = () => {
  const navigate = useNavigate();
  let apiCall = new ApiCall();
  let auth = new Authentication();
  const [msg, setMsg] = useState(null);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setMsg(null);
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const login = async (e) => {
    e.preventDefault();
    console.log("Logging in with username: ", formData.email);
    console.log("Password: ", formData.password);
    try {
      let loginResponse = await apiCall.login(formData);
      console.log(loginResponse);
      if (loginResponse.statusCode == "200") {
        console.log(loginResponse);
        setMsg(null);
        sessionStorage.setItem("AUTH_TOKEN", loginResponse.data);
        auth.setToken(loginResponse.data);
        navigate("/admin/dashboard");
      } else {
        setMsg("Facing issue at server, please try again");
      }
    } catch (error) {
      setMsg("Facing issue at server, please try again");
    }
  };

  return (
    <div className="parlogin">
      <div className="grid">
        <form className="form login" onSubmit={login}>
          <div className="logo">
            <img className="wzLogo logos" src={wizardLogo} alt="" />
          </div>
          <div className="form__field">
            <label htmlFor="login__username">
              <svg className="icon">
                <use xlinkHref="#user"></use>
              </svg>
              <span className="hidden">Email</span>
            </label>
            <input
              id="login__username"
              type="text"
              name="email"
              className="form__input"
              placeholder="Email"
              required=""
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>
          <div className="form__field">
            <label htmlFor="login__password">
              <svg className="icon">
                <use xlinkHref="#lock"></use>
              </svg>
              <span className="hidden">Password</span>
            </label>
            <input
              id="login__password"
              type="password"
              name="password"
              className="form__input"
              placeholder="Password"
              required=""
              value={formData.password}
              onChange={handleInputChange}
            />
          </div>
          <div className="form__field">
            {msg && <dis className="msg">{msg}</dis>}
          </div>
          <div className="form__field">
            <input type="submit" value="Sign In" />
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
