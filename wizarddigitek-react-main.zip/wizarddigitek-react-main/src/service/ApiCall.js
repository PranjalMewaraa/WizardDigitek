import axios from "axios";

class ApiCall {
  constructor() {
    this.apiUrl = `${process.env.REACT_APP_HOST}/api/wizard`;
  }
  async login(req) {
    try {
      let response = await axios.post(this.apiUrl + "/login", { ...req });
      return response.data;
    } catch (error) {
      throw error;
    }
  }
}
export default ApiCall;
