import { jwtDecode } from "jwt-decode";
class Authentication {
  user;
  constructor() {
    const token = sessionStorage.getItem("AUTH_TOKEN");
    if (token) this.user = jwtDecode(token);
    console.log("user---------->", this.user);
  }
  isAdmin = () => {
    return this.getRole();
  };
  getDecoded = () => {
    return jwtDecode(sessionStorage.getItem("AUTH_TOKEN"));
  };
  setToken = (token) => {
    sessionStorage.setItem("AUTH_TOKEN", token);
  };
  getRole = () => {
    return !!(
      (this.user?.user &&
        this.user?.user?.role &&
        this.user?.user?.role === "admin") ||
      this.user?.user?.role === "superadmin"
    );
  };
  getUserId = () => {
    return this.user?.userData?.id;
  };
}
export default Authentication;
