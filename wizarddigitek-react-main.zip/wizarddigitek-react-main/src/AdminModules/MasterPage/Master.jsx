import React, { useEffect, useState } from "react";
import AdminInputField from "../SubModules/AdminInputField";
import ItemTable from "./Submodules/ItemTable";
import axios from "axios";
import AdminSelectField from "../SubModules/AdminSelectField";
const API_ROUTE = "api/wizard";
const Master = () => {
  const [section, setSection] = useState("Cat");
  const [category, setCategory] = useState([]);
  const [loadedT, setLoadedT] = useState(false);
  const [items, setItems] = useState({
    name: "",
  });
  const [itemB, setItemB] = useState({
    name: "",
    category: [],
  });
  const [Brand, setBrand] = useState([]);
  const [isPost, setPost] = useState(false);
  const [allowP, setAllow] = useState(false);
  const [checkedItems, setCheckedItems] = useState([]);

  const [productBrands, setProductBrands] = useState([]);
  const [productTypes, setProductTypes] = useState([]);

  async function fetchSelectedCats(selectedBrandIds, allBrands) {
    setLoadedT(false);
    const selectedBrands = [];
    console.log("ALLBRANDS", allBrands);
    console.log("SELECTED", selectedBrandIds);
    try {
      for (const id of selectedBrandIds) {
        console.log("ID", id);
        const brand = allBrands.find((item) => item.id === id.id);

        if (brand) {
          selectedBrands.push({
            value: brand.id,
            label: brand.name,
          });
        }
      }

      console.log("Selected Brands: ", selectedBrands);
      console.log("--------->", selectedBrands);
      setNeeded(selectedBrands);
    } catch (error) {
      console.error("Error fetching selected brands: ", error);
      return [];
    } finally {
      setLoadedT(true);
    }
  }

  useEffect(() => {
    async function fetchTypesBrands() {
      try {
        const responseBrands = await axios.get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/productBrands`
        );
        const responseDataBrands = responseBrands.data?.data;

        responseDataBrands.forEach((element) => {
          productBrands.push({
            value: element.id,
            label: element.name,
          });
        });
        console.log("Brands: ", responseDataBrands);
      } catch (error) {
        console.log(error);
      } finally {
      }
    }
    fetchTypesBrands();
  }, []);

  const getCat = () => {
    try {
      axios
        .get(`${process.env.REACT_APP_HOST}/${API_ROUTE}/productTypes`)
        .then((response) => {
          setCategory(response.data.data);
        });
    } catch (err) {
      console.log(err);
    }
  };
  const getBrand = () => {
    try {
      axios
        .get(`${process.env.REACT_APP_HOST}/${API_ROUTE}/productBrands`)
        .then((response) => {
          setBrand(response.data.data);
        });
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(() => {
    getCat();
    getBrand();
  }, []);

  useEffect(() => {
    try {
      axios
        .get(`${process.env.REACT_APP_HOST}/${API_ROUTE}/productTypes`)
        .then((response) => {
          setCategory(response.data.data);
        });
    } catch (err) {
      console.log(err);
    }
  }, [isPost]);

  const handleInputChange = (name, value) => {
    setItems((prevData) => ({
      ...prevData,
      name: value,
    }));
    console.log(value);
  };

  const handleInputChange2 = (name, value) => {
    setItemB((prevData) => ({
      ...prevData,
      name: value,
    }));
    console.log(value);
  };

  const handleClick = () => {
    try {
      setAllow(false);
      axios
        .post(`${process.env.REACT_APP_HOST}/${API_ROUTE}/productType`, items)
        .then((response) => {
          console.log("Added");
          setPost(!isPost);
        });
      setAllow(true);
    } catch (err) {
      console.log(err);
    }
  };
  const handleClick2 = () => {
    try {
      setAllow(false);
      axios
        .post(`${process.env.REACT_APP_HOST}/${API_ROUTE}/productBrand`, itemB)
        .then((response) => {
          console.log("Added");
          setPost(!isPost);
          getBrand();
        });
      setAllow(true);
    } catch (err) {
      console.log(err);
    }
  };
  const [canShowType, setCST] = useState(false);
  const [needed, setNeeded] = useState([]);
  const handleBChange = (name, value) => {
    console.log(value);
    try {
      axios
        .get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/productBrand?id=${value}`
        )
        .then((response) => {
          //setProductBrands(response.data.data.category);

          setFinal((prevData) => ({
            ...prevData,
            productBrandId: response.data.data.id,
          }));
          console.log("asdsad", response.data.data);
          setProductTypes(response.data.data.productType);
          fetchSelectedCats(response.data.data.productType, category);
          console.log("After Brand", final);
        });
    } catch (err) {
    } finally {
      console.log("AfterBrand", productTypes);
      setCST(true);
      //fetchSelectedCats(productTypes, category);
    }
  };

  const [allowPAdd, setAllowPAdd] = useState(false);
  const handleTChange = (name, value) => {
    console.log(value);
    setFinal((prevData) => ({
      ...prevData,
      productTypeId: value,
    }));
    setAllowPAdd(true);
  };

  const handleCheckbox = (e) => {
    const { value, checked } = e.target;
    setCheckedItems((prevItems) => {
      const updatedItems = checked
        ? [...prevItems, { productTypeId: value }]
        : prevItems.filter((item) => item.productTypeId !== value);
      // Call updateAmmenity with updatedItems directly
      updateAmmenity(updatedItems);
      return updatedItems;
    });
  };

  const updateAmmenity = (dataList) => {
    console.log("updateAmmenity", dataList);
    setItemB((prevData) => ({
      ...prevData,
      categories: dataList,
    }));
    console.log(itemB);
  };

  const [final, setFinal] = useState({
    name: "",
    productBrandId: "",
    productTypeId: "",
  });
  const handleProductAdd = () => {
    console.log(final);
    try {
      axios
        .post(`${process.env.REACT_APP_HOST}/${API_ROUTE}/name`, final)
        .then((res) => {
          console.log("ADDED INTO NAME MASTER");
          console.log("MASTER ___ ", final);
          alert("Name Added to Master DataBase");
        });
    } catch (err) {
      console.log(err);
    }
  };
  const handleProductName = (name, value) => {
    setFinal((prevData) => ({
      ...prevData,
      name: value,
    }));
    console.log("final ", final);
  };

  return (
    <div className="w-full h-[100vh] bg-zinc-50">
      <div className="w-full h-[60px] flex my-3 text-lg font-normal">
        <p
          className="w-1/3 flex items-center justify-center border-r border-slate-500 bg-gray-300  hover:bg-slate-400"
          onClick={() => setSection("Cat")}
        >
          Manage Catergories
        </p>
        <p
          className="w-1/3 flex items-center justify-center border-r border-slate-500 bg-gray-300  hover:bg-slate-400"
          onClick={() => setSection("Bra")}
        >
          Manage Brands
        </p>
        <p
          className="w-1/3 flex items-center justify-center bg-gray-300 hover:bg-slate-400"
          onClick={() => setSection("Pro")}
        >
          Add Product Names
        </p>
      </div>
      <div className="w-full h-fit">
        {section === "Cat" && (
          <div className="w-full h-fit my-4 flex flex-col p-5 gap-4">
            <div className="w-1/3 flex gap-2">
              <AdminInputField
                name={"Category"}
                type={"text"}
                placeholder={"Smartphones"}
                label={"Add Category"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
              <button
                className="px-5 text-zinc-50 mt-8 rounded-md bg-blue-950"
                onClick={handleClick}
              >
                Add
              </button>
            </div>

            <ItemTable
              type="Type"
              item={category}
              setPost={setPost}
              isPost={isPost}
              getter={getCat}
            />
          </div>
        )}
        {section === "Bra" && (
          <div className="w-full h-fit flex gap-2 my-3 p-5">
            <div className="w-1/3 flex flex-col gap-2">
              <AdminInputField
                name={"name"}
                type={"text"}
                placeholder={"Apple.."}
                label={"Add a Brand"}
                onChange={(name, value) => handleInputChange2(name, value)}
              />
              <div className="w-full font-medium h-fit my-2 flex flex-col">
                Choose Categories
                {category.map((item, index) => {
                  return (
                    <div key={item.id} className="flex py-1 gap-1">
                      <input
                        type="checkbox"
                        key={item.id}
                        name={item.name}
                        id={item.name}
                        value={item.id}
                        onChange={handleCheckbox}
                      />
                      <label htmlFor={item.name}>{item.name}</label>
                    </div>
                  );
                })}
                {category.length === 0 && (
                  <div className=" font-normal text-red-400">
                    No categories available. Please Update Categories first
                  </div>
                )}
              </div>
              <button
                className="px-5 py-2 text-zinc-50 mt-8 rounded-md bg-blue-950"
                onClick={handleClick2}
                disabled={category.length === 0 ? true : false}
              >
                Add
              </button>
            </div>
            <div className="w-2/3 h-80vh p-5">
              <ItemTable
                item={Brand}
                type="Brand"
                setPost={setPost}
                isPost={isPost}
                getter={getBrand}
              />
            </div>
          </div>
        )}

        {section === "Pro" && (
          <div className="w-full h-fit flex flex-col gap-3 p-5">
            <div className="w-1/2 flex flex-col gap-2">
              <AdminSelectField
                name={"ProductBrandId"}
                options={productBrands}
                label={"Select Product Brand"}
                onChange={(name, value) => handleBChange(name, value)}
              />
              {canShowType && (
                <AdminSelectField
                  name={"productTypeId"}
                  options={needed}
                  label={"Select Product Type"}
                  onChange={(name, value) => handleTChange(name, value)}
                />
              )}
              {allowPAdd && (
                <AdminInputField
                  name={"name"}
                  type={"text"}
                  placeholder={"Apple IPhone 14 Pro | Dynamic Island"}
                  label={"Add Product Name"}
                  onChange={(name, value) => handleProductName(name, value)}
                />
              )}

              <button
                className="px-5 text-zinc-50 mt-8 py-2 rounded-md bg-blue-950"
                onClick={handleProductAdd}
                disabled={final.name.length === 0 ? true : false}
              >
                Add
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Master;
