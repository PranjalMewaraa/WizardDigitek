import React, { useState } from "react";
import deleteBtn from "../../../assets/Images/adminAssets/delete-outline.svg";
import edit from "../../../assets/Images/adminAssets/edit.png";
import axios from "axios";
const API_ROUTE = "api/wizard";

const RowTable = (props) => {
  function reload() {
    window.location.reload();
  }

  const handleProductDelete = () => {
    console.log(props.id);
    try {
      axios
        .delete(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/product${props.type}?id=${props.id}`
        )
        .then((response) => {
          console.log("Deleted Successfully");
          props.setPost(!props.isPost);
          props.getter();
        });
    } catch (err) {
      console.log(err);
    }
  };
  const [editable, setEditable] = useState(false);
  return (
    <div className="w-full min-h-16 flex items-center overflow-hidden border-[1 px] border-zinc-900 font-medium">
      <p className="w-[5%] h-full justify-center flex items-center">
        {props.idx}
      </p>
      {editable ? (
        <input
          className="w-[70%] h-full flex items-center px-10 outline outline-1 "
          type="text"
          placeholder="Edit Category Name"
          value={props.name}
        />
      ) : (
        <p className="w-[70%] h-full flex items-center px-10  ">
          {props.name}
        </p>
      )}
      <div className="flex max-w-1/4 min-w-fit w-1/4 h-full py-2.5 px-2 justify-evenly items-center gap-2">
        <div className="h-full mr-2 flex items-center justify-evenly cursor-pointer text-zinc-900 border-[1px] py-1 px-3 gap-2 border-zinc-900 rounded-full hover:text-zinc-800 hover:border-zinc-800">
          {" "}
          <span>
            <img
              className="h-6 cursor-pointer hover:"
              src={edit}
              alt="Edit"
              onClick={handleProductDelete}
            />
          </span>
          Edit
        </div>
        <div className="h-full mr-2 flex items-center justify-evenly cursor-pointer text-red-500 border-[1px] py-1 px-3 gap-2 border-red-500 rounded-full hover:text-red-700 hover:border-red-700">
          {" "}
          <span>
            <img
              className="h-6 cursor-pointer hover:"
              src={deleteBtn}
              alt="Delete"
              onClick={handleProductDelete}
            />
          </span>
          Delete
        </div>
      </div>
    </div>
  );
};

const ItemTable = ({ item, getter, type, setPost, isPost }) => {
  return (
    <div className="flex w-full max-h-[40vh] flex-col outline outline-2 overflow-y-scroll">
      <div className="w-full flex items-center justify-between h-12 rounded-sm overflow-hidden outline outline-2 border-zinc-900">
        <p className="w-[5%] h-16 justify-center text-zinc-950 font-medium flex items-center border-r border-b border-zinc-900">
          S.No
        </p>

        <p className="w-[70%] h-16 flex items-center px-10 font-medium">
          Categories
        </p>

        <div className="flex w-1/4 h-16 items-center justify-center font-medium text-zinc-950">
          Action
        </div>
      </div>
      <div className="w-full h-full overflow-y-scroll flex flex-col gap-0 ">
        {item.map((item, index) => {
          return (
            <RowTable
              key={index}
              idx={index}
              name={item.name}
              id={item.id}
              setPost={setPost}
              isPost={isPost}
              getter={getter}
              type={type}
            />
          );
        })}
      </div>
    </div>
  );
};

export default ItemTable;
