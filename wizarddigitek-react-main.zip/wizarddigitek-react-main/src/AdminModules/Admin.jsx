import React, { useEffect } from 'react';
import EditLanding from './EditLandingPAge/EditLanding';
import { Outlet, useNavigate } from 'react-router-dom'
import AdminNavbar from './AdminNavbar/AdminNavbar';

const Admin = () => {
    const navigate = useNavigate();

    // useEffect(() => {
    //     navigate("/admin/dashboard");
    // }, []);

    return (
        <>
            <AdminNavbar/>
            <Outlet />
        </>
    )
};

export default Admin;