import React from "react";
import { Link } from "react-router-dom";

const AdminNavbar = () => {
  return (
    <div className="flex items-center justify-between px-[6vmax] py-2 shadow-sm bg-white">
      <Link to={"/"} className="logoSection-AdminNav">
        <img
          src={require("./../../assets/Images/wzLogo.svg").default}
          alt="logo"
          className="logo-AdminNav h-10"
        />
      </Link>

      <div className="nvbarLinks-AdminNav flex gap-8">
        <Link to="/admin/dashboard" className="navLink-AdminNav">
          Dashboard
        </Link>
        <Link to="/admin/master" className="navLink-AdminNav">
          Master
        </Link>
        <Link to="/admin/addProduct" className="navLink-AdminNav">
          Add Product
        </Link>
        <Link to="/admin/oldProductReciept" className="navLink-AdminNav">
          Old Product Reciept
        </Link>
        <Link to="/admin/inventory" className="navLink-AdminNav">
          Inventory
        </Link>
      </div>
    </div>
  );
};

export default AdminNavbar;
