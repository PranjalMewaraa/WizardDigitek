import React, { useState } from "react";
import AdminInputField from "./SubModules/AdminInputField";
import AdminLargeInputField from "./SubModules/AdminLargeInputField";
import AdminSelectField from "./SubModules/AdminSelectField";
import AdminTopBar from "./SubModules/AdminTopBar";

const OldProductReciept = () => {
  const paymentOptions = [
    { value: "cash", label: "Cash" },
    { value: "upi", label: "UPI" },
    { value: "card", label: "Credit/Debit Card" },
  ];

  const warrantyStatus = [
    { value: "available", label: "Available" },
    { value: "expired", label: "Expired" },
  ];

  const productCondition = [
    { value: "excellent", label: "Excellent" },
    { value: "good", label: "Good" },
    { value: "fair", label: "Fair" },
  ];

  const [oldReciept, setOldReciept] = useState({
    SellerName: "",
    SellerContact: "",
    ProductName: "",
    ProductCode: "",
    ProductDesc: "",
    Quantity: 0,
    ProductSpecs: "",
    colorName: "",
    MRP: 0,
    DiscountPrice: 0,
    variant: [],
  });

  const handleInputChange = (name, value) => {
    setOldReciept((prevData) => ({
      ...prevData,
      [name]: value,
    }));

    console.log("Submit:", oldReciept);
  };

  return (
    <>
      <AdminTopBar />

      <div className="addProductContainer">
        <h1>Old Product Reciept</h1>

        <form className="addProductFormContainer">
          <div className="addProductCont1 ">
            <div className="AP-Cont-Row w-full flex justify-center gap-3">
              {/* Serial Number */}
              <AdminInputField
                label={"Serial Number"}
                placeholder={"Enter Sl No."}
                inputType={"number"}
                name={"SerialNumber"}
                onChange={(name, value) => handleInputChange(name, value)}
              />

              {/* Date of Purchase */}
              <AdminInputField
                label={"Date of Purchase"}
                placeholder={"Enter Date"}
                name={"PurchaseDate"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>
            <div className="AP-Cont-Row w-full">
              {/* Seller Name */}
              <AdminInputField
                label={"Seller Name"}
                placeholder={"John Doe"}
                name={"SellerName"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>
            <div className="AP-Cont-Row w-full">
              {/* Seller Contact Number */}
              <AdminInputField
                label={"Seller Contact Number"}
                placeholder={"Enter Number"}
                name={"SellerContact"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>
            <div className="AP-Cont-Row w-full flex justify-between gap-3">
              {/* Product Name */}
              <AdminInputField
                label={"Product Name"}
                placeholder={"Apple iPhone 15 Pro Max | 256GB | A16 Bionic..."}
                name={"ProductNameOldAdd"}
                onChange={(name, value) => handleInputChange(name, value)}
              />

              {/* Product Model */}
              <AdminInputField
                label={"Product Model"}
                placeholder={"Enter Model"}
                name={"ProductModelOldAdd"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            <div className="AP-Cont-Row w-full">
              {/*Product IMEI 1 */}
              <AdminInputField
                label={"IMEI 1"}
                placeholder={"Enter IMEI 1"}
                name={"ProductImei1"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            <div className="AP-Cont-Row w-full">
              {/* Product IMEI 2 */}
              <AdminInputField
                label={"IMEI 2"}
                placeholder={"Enter IMEI 2"}
                name={"ProductImei2"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>
          </div>

          <div className="addProductCont2">
            <div className="AP-Cont-Row w-full">
              {/* Seller ID */}
              <AdminInputField
                label={"Seller ID"}
                placeholder={"Enter ID"}
                name={"SellerID"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* Seller Address */}
            <div className="AP-Cont-Row w-full">
              <AdminLargeInputField
                inputSize={"medium"} //Input Size Medium For Half the Input Size
                label={"Seller Address"}
                placeholder={"Enter Address"}
                name={"SellerAddress"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* Purchased By */}
            <div className="AP-Cont-Row w-full">
              <AdminInputField
                label={"Purchased By"}
                placeholder={"Enter Name"}
                name={"PurchasedBy"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            <div className="AP-Cont-Row w-full flex justify-center gap-3">
              {/* Purchased Amount */}
              <AdminInputField
                label={"Purchase Amount"}
                inputType={"number"}
                placeholder={"Ex. 100000"}
                name={"PurchaseAmount"}
                onChange={(name, value) => handleInputChange(name, value)}
              />

              {/* Amount Adjustments */}
              <AdminInputField
                label={"Amount Adjustments"}
                placeholder={"Enter Adjustment Details"}
                inputType={"number"}
                name={"AmountAdjustments"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* Enter Payment Mode */}
            <div className="AP-Cont-Row w-full">
              <AdminSelectField
                label={"Enter Payment Mode"}
                name={"PaymentModeOldAdd"}
                options={paymentOptions}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* <div className="AP-Cont-Row w-full">
                            <p className='pb-2 text-md font-medium'>Product Images (0/5)</p>
                            <div className="additionalImagesCont flex justify-between flex-wrap mt-3">
                                {AdditionalImages.map((item, index) => {
                                    return (
                                        <div key={index} className="border-blue-600 border min-w-[3vmax] min-h-[3vmax] w-[4vmax] h-[4vmax] rounded antialiased overflow-hidden flex justify-center items-center cursor-pointer relative">
                                            <input type="file" className='absolute inset-0 opacity-0 cursor-pointer' />
                                            {!item.img && <img src={require('./../assets/Images/adminAssets/uploadIcon.png')} alt="product img placeholder" className=' w-1/3 h-1/3 cursor-pointer' />}

                                        </div>
                                    )
                                }
                                )}
                            </div>
                        </div> */}
          </div>

          <div className="addProductCont3">
            {/* Warranty Status */}
            <div className="AP-Cont-Row w-full flex justify-center gap-3">
              <AdminSelectField
                label={"Warranty Status"}
                name={"warrantyStatus"}
                options={warrantyStatus}
                onChange={(name, value) => handleInputChange(name, value)}
              />

              {/* Warranty Left */}
              <AdminInputField
                label={"Warranty Left"}
                placeholder={"Months/Years"}
                name={"WarrantyLeft"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            <div className="AP-Cont-Row w-full flex justify-center gap-3">
              {/* Product Condition */}
              <AdminSelectField
                label={"Product Condition"}
                name={"productCondition"}
                options={productCondition}
                onChange={(name, value) => handleInputChange(name, value)}
              />

              {/* Product Remarks */}
              <AdminInputField
                label={"Remarks"}
                placeholder={"Ex- Camera not working, etc"}
                name={"productRemarks"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            <button type="submit" className="titleBarAddProductButton mt-5">
              Generate Reciept
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default OldProductReciept;
