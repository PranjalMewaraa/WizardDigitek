import React, { useEffect, useState } from "react";
import "./adminStyles.css";
import AdminInputField from "./SubModules/AdminInputField";
import AdminLargeInputField from "./SubModules/AdminLargeInputField";
import TagInput from "./SubModules/TagInput";
import AdminSelectField from "./SubModules/AdminSelectField";
import axios from "axios";
import ThumbnailImgBox from "./SubModules/ThumbnailImgBox";
import AdminTopBar from "./SubModules/AdminTopBar";
import VariantInputComponent from "./SubModules/VariantInputComponent";
import AdditionalImagesContainer from "./SubModules/AdditionalImagesContainer";

const API_ROUTE = "api/wizard";

const AddProduct = () => {
  const [productBrands, setProductBrands] = useState([]);
  const [productNames, setProductNames] = useState([]);
  const [productTypes, setProductTypes] = useState([]);
  const [category, setCategory] = useState([]);
  useEffect(() => {
    async function fetchTypesBrands() {
      try {
        setIsLoading(true);
        const responseTypes = await axios.get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/productTypes`
        );
        const responseDataTypes = responseTypes.data?.data;
        setCategory(responseDataTypes);
        const responseBrands = await axios.get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/productBrands`
        );
        const responseDataBrands = responseBrands.data?.data;
        productTypes.splice(0, productTypes.length);
        responseDataTypes.forEach((element) => {
          productTypes.push({
            value: element.id,
            label: element.name,
          });
        });
        productBrands.splice(0, productBrands.length);
        responseDataBrands.forEach((element) => {
          productBrands.push({
            value: element.id,
            label: element.name,
          });
        });

        // console.log(responseData[0]?.id)
        setProductData({
          ...productData,
          productTypeId: responseDataTypes[0]?.id,
          productBrandId: responseDataBrands[0]?.id,
        });
        console.log("Types: ", responseDataTypes);
        console.log("Brands: ", responseDataBrands);
      } catch (error) {
        console.log(error);
      } finally {
        setIsLoading(false);
      }
    }
    fetchTypesBrands();
  }, []);

  const getNames = (nameMaster) => {
    productNames.splice(0, productNames.length);
    console.log(`Name Master ${nameMaster}`);

    nameMaster.forEach((element) => {
      productNames.push({
        value: element.id,
        label: element.name,
      });
      console.log("PNAME", productNames);
    });
  };
  const [loadedT, setLoadedT] = useState(false);
  const [needed, setNeeded] = useState([]);
  async function fetchSelectedCats(selectedBrandIds, allBrands) {
    setLoadedT(false);
    const selectedBrands = [];
    console.log("ALLBRANDS", allBrands);
    console.log("SELECTED", selectedBrandIds);
    try {
      for (const id of selectedBrandIds) {
        console.log("ID", id);
        const brand = allBrands.find((item) => item.id === id.id);

        if (brand) {
          selectedBrands.push({
            value: brand.id,
            label: brand.name,
          });
        }
      }

      console.log("Selected Brands: ", selectedBrands);
      console.log("--------->", selectedBrands);
      setNeeded(selectedBrands);
    } catch (error) {
      console.error("Error fetching selected brands: ", error);
      return [];
    } finally {
      setLoadedT(true);
    }
  }

  //console.log("Types: ", productTypes)
  // console.log("Brands: ", productBrands)

  const productCondition = [
    { value: "new", label: "New" },
    { value: "refurbished", label: "Refurbished" },
  ];

  const [variantsList, setVariantsList] = useState([]);
  const [specs, setSpecs] = useState([]);
  const [productImages, setProductImages] = useState([]);

  const [isLoading, setIsLoading] = useState(false);

  const [productData, setProductData] = useState({
    productCondition: "New",
    productTypeId: "",
    productBrandId: "",
    productNameId: "",
    productCode: "",
    productDesc: "",
    quantity: 0,
    productSpecs: [],
    thumbnail: [],
    productImage: [],
    variants: [],
  });

  const handleInputChange = (name, value) => {
    setProductData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    console.log(productData);
  };

  const handleTChange = (name, value) => {
    setProductData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    try {
      axios
        .get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/nameByBrandType?productTypeId=${value}&productBrandId=${selectedB}`
        )
        .then((res) => {
          console.log("DATADADA", res.data.data);
          setNameMaster(res.data);
          getNames(res.data.data);
        });
    } catch (error) {}
  };
  const [selectedB, setSelectedB] = useState("");
  const [nameMaster, setNameMaster] = useState("");
  const handleBChange = (name, value) => {
    setProductData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    setSelectedB(value);
    try {
      axios
        .get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/productBrand?id=${value}`
        )
        .then((response) => {
          fetchSelectedCats(response.data.data.productType, category);
        });
    } catch (error) {}
  };

  const handleAdditionalImgChange = (data) => {
    setProductImages([...productImages, data]);
    setProductData((prevData) => ({
      ...prevData,
      productImage: [...productImages, data],
    }));
  };

  const handleDelelteAdditionalImg = (data) => {
    setProductImages([...data]);

    setProductData((prevData) => ({
      ...prevData,
      productImage: [...data],
    }));
  };

  const handleThumbnailChage = (data) => {
    let imgData = [...data];
    // console.log("Thumbnail: ", imgData)
    setProductData((prevData) => ({
      ...prevData,
      thumbnail: imgData,
    }));
  };

  const handleSubmit = async (e) => {
    try {
      e.preventDefault();
      setIsLoading(true);

      let formData = new FormData();

      for (let [key, value] of Object.entries(productData)) {
        if (key !== "thumbnail" && key !== "productImage") {
          console.log("VALUE", { key }, typeof value);
          if (Array.isArray(value)) {
            if (value.length === 1) {
              console.log(key === "variants");
              formData.append(
                `${key}[]`,
                key === "variants" ? JSON.stringify(value[0]) : value[0]
              );
            } else {
              for (let val of value) {
                // typeof (val) === "object" ? console.log("++++++++", JSON.stringify(val)) : console.log("++++++++++++")
                formData.append(
                  key,
                  typeof val === "object" ? JSON.stringify(val) : val
                );
              }
            }
          } else {
            formData.append(key, value);
          }
        } else {
          if (Array.isArray(value)) {
            if (value.length === 1) {
              formData.append(`${key}`, value[0]);
            } else {
              for (let val of value) {
                formData.append(key, val);
              }
            }
          }
        }
      }

      console.log("Product Data:", productData);
      const response = await axios.post(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/product`,
        formData
      );
      console.log("Product Added", response);
      alert("Added");
    } catch (error) {
      console.log("Error in adding Product");
      console.log(error);
    } finally {
      setIsLoading(false);
    }
  };

  const printFormData = () => {
    console.log(productData);
  };

  if (isLoading) {
    return (
      <div className="flex w-screen h-screen justify-center items-center text-4xl font-bold">
        Loading...
      </div>
    );
  }

  return (
    <>
      <AdminTopBar />
      <div className="addProductContainer">
        <h1>Add Product</h1>

        <form className="addProductFormContainer" onSubmit={handleSubmit}>
          <div className="addProductCont1 ">
            <div className="AP-Cont-Row flex justify-between items-center gap-3 w-full">
              {/* Product Condition */}

              <AdminSelectField
                label={"Condition"}
                name={"productCondition"}
                options={productCondition}
                onChange={(name, value) => handleInputChange(name, value)}
              />

              {/* P Brand */}
              <AdminSelectField
                label={"Product Brand"}
                options={productBrands}
                name={"productBrandId"}
                onChange={(name, value) => handleBChange(name, value)}
              />

              {/* P Type */}
              {loadedT && (
                <AdminSelectField
                  label={"Product Type"}
                  options={needed}
                  name={"productTypeId"}
                  onChange={(name, value) => handleTChange(name, value)}
                />
              )}
            </div>

            {/* P Name */}
            <div className="AP-Cont-Row w-full">
              <AdminSelectField
                label={"Product Name"}
                placeholder={"Apple iPhone 15 Pro Max | 256GB | A16 Bionic..."}
                name={"productNameId"}
                options={productNames}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* P Code */}
            <div className="AP-Cont-Row w-full">
              <AdminInputField
                label={"Product Code"}
                placeholder={"Enter Product Code"}
                name={"productCode"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* P Description */}
            <div className="AP-Cont-Row w-full">
              <AdminLargeInputField
                label={"Product Description"}
                placeholder={"Enter Description"}
                name={"productDesc"}
                maxChar={2000}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* Quantity Available */}
            <div className="AP-Cont-Row w-full mb-0">
              <AdminInputField
                inputType={"number"}
                label={"Quantity Available"}
                placeholder={"Available Qty"}
                name={"quantity"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>
          </div>

          <div className="addProductCont2 ">
            {/* Product Spec */}
            <div className="AP-Cont-Row w-full">
              <TagInput
                tags={specs}
                label={"Product Specification"}
                name={"productSpecs"}
                setTags={setSpecs}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>

            {/* Variants */}
            <div className="AP-Cont-Row w-full">
              <VariantInputComponent
                variantsList={variantsList}
                setVariantsList={setVariantsList}
                label={"Variants"}
                name={"variants"}
                onChange={(name, value) => handleInputChange(name, value)}
              />
            </div>
          </div>

          <div className="addProductCont3 ">
            <h4 className="font-semibold mb-4">Product Thumbnail Image</h4>
            <ThumbnailImgBox
              onImageUpload={(e) => {
                handleThumbnailChage(e);
              }}
            />
            <p className="text-right text-sm font-medium text-gray-600">
              Attach Additional Images ({productImages.length}/10)
            </p>
            <div className="additionalImagesCont flex flex-wrap mt-3">
              <AdditionalImagesContainer
                productImages={productImages}
                setProductImages={setProductImages}
                onImageChange={(e) => {
                  handleAdditionalImgChange(e);
                }}
                handleDelelteAdditionalImg={(e) => {
                  handleDelelteAdditionalImg(e);
                }}
              />
            </div>

            <button type="submit" className="titleBarAddProductButton mt-5">
              Add Product
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default AddProduct;
