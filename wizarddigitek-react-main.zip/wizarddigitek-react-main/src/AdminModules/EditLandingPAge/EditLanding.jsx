import React, { useState, useRef, useEffect } from "react";
import HeroAdL from "./Components/HeroAdL";
import "./EditLanding.css";
import img from "../../assets/Images/image80.png";
import img2 from "../../assets/Images/image79.png";
import img3 from "../../assets/Images/image76.png";
import img4 from "../../assets/Images/image77.png";
import DisplayGridEdit from "./Components/DisplayGridEdit";
import DisplayNews from "../../modules/LandingPage/SubModules/DisplayNews";
import of1 from "../../assets/Images/of1.png";
import of2 from "../../assets/Images/of22.png";
import of3 from "../../assets/Images/of33.png";
import logistic from "../../assets/Images/logf.png";
import dollar from "../../assets/Images/dolf.png";
import money from "../../assets/Images/moneyf.png";
import transp from "../../assets/Images/tranf.png";
import Footer from "../../components/Footer/Footer";
import FinancialEdit from "./Components/FInancialEdit";
import delbtn from "../../assets/Images/adminAssets/delete-outline.svg";
import AdminNavbar from "../AdminNavbar/AdminNavbar";
import axios from "axios";
const EditLanding = () => {
  const [slides, setSlide] = useState([]);
  const [landingPageID, setLandingPageID] = useState("");
  const getSlides = () => {
    axios
      .get(`${process.env.REACT_APP_HOST}/api/wizard/adBanners`)
      .then(function (response) {
        setSlide(response.data.data);
        console.log("Sata:", response.data.data);
        setLandingPageID(
          response.data.length > 0 ? response.data[0].landingPageId : null
        );
      })
      .catch(function (error) {
        // Handle errors
        console.error("Error:", error);
      });
  };

  useEffect(() => {
    getSlides();
  }, []);
  useEffect(() => {
    getSlides();
  }, [slides]);

  const fileInputRef = useRef(null);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();
    if (file) {
      const formData = new FormData();
      formData.append("img", file);

      const url = `${process.env.REACT_APP_HOST}/api/wizard/adBanner?id=${landingPageID}`;
      axios
        .post(url, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          console.log("File uploaded successfully:", response.data);
          // Add any additional handling as needed
        })
        .catch((error) => {
          console.error("Error uploading file:", error);
          // Handle the error appropriately
        });
    }
  };

  const handleAddImage = () => {
    // Trigger the click event of the file input
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
    getSlides();
  };

  return (
    <>
      <AdminNavbar />
      <div className="AdminLanding">
        <HeroAdL img1={img} img2={img2} img3={img3} img4={img4} />
        <br />
        <DisplayNews slides={slides} />
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "start",
          }}
        >
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            ref={fileInputRef}
            style={{ display: "none" }}
          />
          <div className="btngrp">
            <button onClick={handleAddImage} id="btnaddbanner">
              Add Image to the display banner
            </button>
            {/*  */}
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default EditLanding;
