// DisplayGridEdit.js
import React, { useState } from 'react';
import CardD from '../Components/CardD';

const DisplayGridEdit = () => {
  const [cards, setCards] = useState([
    { id: 1, backgroundImage: '' },
    { id: 2, backgroundImage: '' },
    { id: 3, backgroundImage: '' },
    { id: 4, backgroundImage: '' },
    { id: 5, backgroundImage: '' },
    { id: 6, backgroundImage: '' }
  ]);

  const handleImageChange = (id, newImage) => {
    const updatedCards = cards.map(card =>
      card.id === id ? { ...card, backgroundImage: newImage } : card
    );

    setCards(updatedCards);
  };

  return (
    <div className='DisplayEditGrid'>
      <div className="display-container">
        {cards.map(card => (
          <CardD
            key={card.id}
            backgroundImage={card.backgroundImage}
            onImageChange={(newImage) => handleImageChange(card.id, newImage)}
          />
        ))}
      </div>
    </div>
  );
};

export default DisplayGridEdit;
