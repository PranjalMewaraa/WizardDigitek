import React, { useState } from 'react';

const CardD = ({ backgroundImage, onImageChange }) => {
  const handleImageInputChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onloadend = () => {
      onImageChange(reader.result); // Call the onImageChange function with the new image
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="cardD" style={{ backgroundImage: `url(${backgroundImage})` }}>
      {/* Only an input for uploading a new image */}
      <input type="file" accept="image/*" onChange={handleImageInputChange} />
    </div>
  );
};

export default CardD;
