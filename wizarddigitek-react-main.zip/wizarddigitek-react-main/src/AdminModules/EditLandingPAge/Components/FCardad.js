import React, { useState, useEffect } from 'react';

const FCardad = (props) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(props.title);
  const [editedImage, setEditedImage] = useState(props.img);
  const [imageFile, setImageFile] = useState(null);

  useEffect(() => {
    setEditedTitle(props.title);
    setEditedImage(props.img);
  }, [props.title, props.img]);

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleSaveClick = () => {
    setIsEditing(false);

    // Pass the edited data back to the parent component
    props.onSave({
      title: editedTitle,
      img: editedImage,
      para: props.para, // Assuming para doesn't change during editing
      linkt: props.linkt, // Assuming linkt doesn't change during editing
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onloadend = () => {
      setEditedImage(reader.result);
      setImageFile(file);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className={isEditing ? 'contff' : 'contf'}>
      {isEditing ? (
        <div>
          <label>Title:</label>
          <input
            type="text"
            className="inputff"
            value={editedTitle}
            onChange={(e) => setEditedTitle(e.target.value)}
          />
          <br />
          <label>Image:</label>
          <input
            style={{ marginBottom: '.5vmax' }}
            type="file"
            accept="image/*"
            onChange={handleImageChange}
          />
          <br />
          {editedImage && (
            <img
              src={editedImage}
              alt="Selected"
              style={{ maxWidth: '100px', maxHeight: '100px' }}
            />
          )}
          <br />
          <button onClick={handleSaveClick}>Save</button>
        </div>
      ) : (
        <div>
          <img src={props.img} id="fcimg" alt="" />
          <div id="titlefc">{props.title}</div>
          <div id="para">{props.para}</div>
          <div id="linkt" onClick={handleEditClick}>
            Click Here to start Editing
          </div>
        </div>
      )}
    </div>
  );
};

export default FCardad;
