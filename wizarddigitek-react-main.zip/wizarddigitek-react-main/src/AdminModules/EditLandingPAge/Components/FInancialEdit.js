// FinancialEdit.js
import React from 'react';
import bimg from '../../../assets/Images/btnimgplay.png';
import FCardad from './FCardad';
import '../../../modules/LandingPage/LandingPage.css';

const FinancialEdit = ({ cardsData }) => {
  const handleCardSave = (index, editedData) => {
    // Update the cardsData with the edited data
    const updatedCardsData = [...cardsData];
    updatedCardsData[index] = { ...updatedCardsData[index], ...editedData };
    // Handle the updated cardsData, e.g., send it to a server or update state
    // For now, just log the updated data
    console.log("Updated Card Data:", updatedCardsData);
  };

  return (
    <div className="FContainer">
      <div className="mainFDiv">
        <div className="FLeft">
          <div className="FtextContainer">
            <div id="headingF">We Keep Your Money Safe</div>
            <div id="SubheadingF">
              We are home to a variety of mobiles, tablets, and their accessories,
              all of the best quality with product guarantees and warranties.
            </div>
            <div id="btnGrpF">
              <button type="button" id="btn1F">
                About
              </button>
              <button type="button" id="btn2F">
                <img src={bimg} alt="" />
              </button>
            </div>
          </div>
        </div>
        <div className="FRight">
          <div className="gridF">
            {cardsData.map((card, index) => (
              <div className="gf" key={index}>
                <FCardad
                  img={card.img}
                  title={card.title}
                  para={card.para}
                  linkt={card.linkt}
                  onSave={(editedData) => handleCardSave(index, editedData)}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialEdit;
