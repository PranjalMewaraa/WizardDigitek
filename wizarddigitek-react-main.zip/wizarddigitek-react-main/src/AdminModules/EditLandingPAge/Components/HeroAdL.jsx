import React, { useState, useEffect } from 'react';
import axios from 'axios'
const ChildComponent = ({hdata}) => {
  const [text, setText] = useState(hdata.text);
  const ig = hdata.attachment[0];
  const [images, setImage] = useState(hdata.attachment[0].name);
  const [backgroundColor, setBackgroundColor] = useState(hdata.bg);
  const [cData , setCData] = useState(hdata);
  const [isAdding, setIsAdding] = useState(false);
  console.log("hdata" ,hdata);

  const handleTextChange = (event) => {
    setText(event.target.value);
    console.log("hdata" ,hdata);
    setCData(
      {
      ...cData,
      'text':event.target.value
      }
      )
    console.log(cData)
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();
  
    reader.onloadend = () => {
      setImage(file.name);
      
    };
  
    if (file) {
      const formData = new FormData();
      formData.append('img', file);
      reader.readAsDataURL(file);
      const url =`${process.env.REACT_APP_HOST}/api/wizard/landingHero?id=${hdata.id}`
      axios.put(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
        .then(response => {
          console.log('File uploaded successfully:', response.data);
          // Add any additional handling as needed
        })
        .catch(error => {
          console.error('Error uploading file:', error);
          // Handle the error appropriately
        });
    }
  };
  


  const handleSubmit = async (e) => {
    try {
      e.preventDefault();
      setIsAdding(true);
      const response = await axios.put(`http://20.157.85.28/api/wizard/landingHero?id=${cData.id}`, cData);
      console.log("Product updated", response);

    } catch (error) {
      console.log(error);
    } finally {
      setIsAdding(false);
    }
  };



  const handleColorChange = (event) => {
    setBackgroundColor(event.target.value);
    setCData(
      {
      ...cData,
      'bg':event.target.value
      }
      )
    console.log(cData)
  };

  return (
    <div className='LandingHeroAdmin' style={{ backgroundColor, padding: '20px', textAlign: 'center', color: 'white' ,width:'25%'}}>
      <img src={`${process.env.REACT_APP_HOST}/api/upload/${images}`} alt="placeholder" style={{ maxWidth: '100%', height: 'auto', marginBottom: '10px' , height:'40vh'}} />
      <div style={{height:'40vh', display:'flex',flexDirection:'column'}}>
      <p>{text}</p>
      <input type="text" className='input'  placeholder="Enter new text" value={text} onChange={handleTextChange} />
      <br />
      <input id='imginp'  className='input' type="file" accept="image/*" onChange={handleImageChange} />
      <br />
      <input type="text"  className='input' placeholder="Enter background color (hex code)" value={backgroundColor} onChange={handleColorChange} style={{color:'black'}} />
      <br />
      </div>
      <button id='upbtnhl' onClick={handleSubmit}>Save Changes</button>
    </div>
  );
};

const HeroAdL = (props) => {

  


  const [heroData, setHeroData] = useState([]);

  const getHeroData = () => {
    axios.get(`${process.env.REACT_APP_HOST}/api/wizard/landingHeros`)
      .then(function (response) {
        setHeroData(response.data.data);
        console.log('Data:', response.data.data);
      })
      .catch(function (error) {
        // Handle errors
        console.error('Error:', error);
      });
  }
  useEffect(() => {
    getHeroData();
  }, []);


  return (
    <div className="parLH" style={{display:"flex", flexDirection:"column",alignItems:"center"}}>
    <div style={{ display: 'flex', height: '85vh', width: '100%' }}>
      {heroData.map((hdata, index) => (

        <ChildComponent key={index} hdata={hdata} />
      ))}
    </div>
    </div>


  );
};

export default HeroAdL;
