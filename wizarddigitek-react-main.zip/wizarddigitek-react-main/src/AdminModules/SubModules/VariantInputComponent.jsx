import React, { useEffect, useState } from "react";
import addIcon from "../../assets/Images/adminAssets/add-icon.svg";
import deleteBin from "../../assets/Images/adminAssets/delete-outline.svg";
import cross from "../../assets/Images/adminAssets/cross.svg";

// Variant Accordion
const VariantBox = ({
  item,
  index,
  setVariantsList,
  variantsList,
  getColorArray,
  getVariantArray,
}) => {
  const [colorName, setColorName] = useState("");
  const [mrp, setMRP] = useState(0);
  const [discountMRP, setDiscountMRP] = useState(0);

  const [colorsArray, setColorsArray] = useState([]);

  const colorObj = {
    colorName: colorName.trim(),
    price: Number(mrp),
    discountPrice: Number(discountMRP),
  };

  const deleteVariant = (index) => {
    return () => {
      let temp = [...variantsList];
      temp.splice(index, 1);
      setVariantsList(temp);
    };
  };

  const handleColorAdd = (e) => {
    e.preventDefault();

    if (colorName.trim() === "" || mrp === 0 || discountMRP === 0) {
      return;
    }
    setColorsArray([...colorsArray, colorObj]);
    setColorName("");
    setMRP(0);
    setDiscountMRP(0);

    getColorArray(index, [...colorsArray, colorObj]);
  };

  const deleteColor = (index) => {
    return () => {
      let temp = [...colorsArray];
      temp.splice(index, 1);
      setColorsArray(temp);

      getColorArray(index, temp);
    };
  };

  return (
    <div className="w-full first:border first:rounded-t-md last:rounded-b-md border-x border-b p-3  ">
      <div className="flex justify-between mb-3">
        <h2 className="font-medium text-lg text-gray-600">
          {item.variant}
          <span className="text-sm text-gray-400">
            {" "}
            &nbsp;•&nbsp; {colorsArray.length} Colors
          </span>
        </h2>
        <div
          className="bg-red-500 hover:bg-red-600 flex justify-center items-center px-1.5 rounded-sm cursor-pointer"
          onClick={deleteVariant(index)}
        >
          <img className="w-4" src={cross} alt="deleteVariant" />
        </div>
      </div>

      {colorsArray.map((item, index) => {
        return (
          <div
            key={index}
            className="flex font-medium items-center gap-3 my-2 rounded py-2.5 px-2 bg-white border  justify-between"
          >
            <p className="text-gray-600 text-sm">Color: {item.colorName}</p>
            <p className="text-gray-600 text-sm">MRP: {item.price}</p>
            <p className="text-gray-600 text-sm">
              Display Price: {item.discountPrice}
            </p>
            <img
              className="w-6 cursor-pointer"
              src={deleteBin}
              alt="deleteColor"
              onClick={deleteColor(index)}
            />
          </div>
        );
      })}

      {/* Input Fields */}
      <div className="mt-4 w-full">
        <div className="flex gap-2 items-end w-full justify-evenly">
          <div>
            <label
              htmlFor="color"
              className="pb-2 text-sm text-gray-400 font-medium"
            >
              Color Name
            </label>
            <input
              type="text"
              name="color"
              placeholder="Color Name"
              id="color"
              autoComplete="off"
              value={colorName}
              onChange={(e) => setColorName(e.target.value)}
              className="w-full border-gray-900 border rounded-md p-2 placeholder:text-sm focus:outline-slate-500"
            />
          </div>
          <div>
            <label
              htmlFor="mrp"
              className="pb-2 text-sm text-gray-400 font-medium"
            >
              MRP
            </label>
            <input
              type="number"
              min={0}
              name="mrp"
              placeholder="Enter MRP"
              id="mrp"
              autoComplete="off"
              value={mrp}
              onChange={(e) => setMRP(e.target.value)}
              className="w-full border-gray-900 border rounded-md  p-2 placeholder:text-sm focus:outline-slate-500"
            />
          </div>
          <div>
            <label
              htmlFor="discountMRP"
              className="pb-2 text-sm text-gray-400 font-medium"
            >
              Display Price
            </label>
            <input
              type="number"
              min={0}
              name="discountMRP"
              placeholder="Display Price"
              id="discountMRP"
              autoComplete="off"
              value={discountMRP}
              onChange={(e) => setDiscountMRP(e.target.value)}
              className="w-full border-gray-900 border rounded-md  p-2 placeholder:text-sm focus:outline-slate-500"
            />
          </div>
          <button
            className="rounded bg-gray-600 hover:bg-gray-800 p-1.5  flex items-center justify-center"
            onClick={(e) => handleColorAdd(e)}
          >
            <img className="w-20" src={addIcon} alt="add" />
          </button>
        </div>
      </div>
    </div>
  );
};

const VariantInputComponent = ({
  label,
  name,
  variantsList,
  setVariantsList,
  onChange,
}) => {
  const [value, setValue] = useState("");

  // const [variantsList, setVariantsList] = useState([]);

  const [variant, setVariant] = useState({
    variant: "",
    colors: [],
  });

  const handleInputChange = (e) => {
    setValue(e.target.value);
    // console.log(value)
    setVariant({
      variant: e.target.value,
      colors: [],
    });
  };

  useEffect(() => {
    onChange(name, [...variantsList]);
    console.log("UPDATED");
  }, [variantsList]);

  const handleAddVariant = (e) => {
    e.preventDefault();
    if (value.trim() === "" || variantsList.includes(value.trim())) {
      return;
    }
    setVariantsList([...variantsList, variant]);
    setValue("");
  };

  const getColorArray = (index, updatedColorsArray) => {
    // console.log("INDEX: ", index)
    // console.log("COLORS: ", updatedColorsArray)

    // Update the specific variant's color array
    setVariantsList((prevVariantsList) => {
      const updatedVariantsList = [...prevVariantsList];
      if (updatedVariantsList[index]) {
        updatedVariantsList[index] = {
          ...updatedVariantsList[index],
          colors: updatedColorsArray,
        };

        onChange(name, [...updatedVariantsList]);
        // Log the updated state for debugging
        console.log("Updated VARIANT LIST:", updatedVariantsList);
      } else {
        console.error("Variant at index", index, "does not exist.");
      }

      // Return the updated state
      return updatedVariantsList;
    });
  };

  return (
    <>
      <div>
        <label htmlFor="variantInput" className="pb-2 text-md font-medium">
          {label}
        </label>
        <div className="flex">
          <input
            type="text"
            name="variantInput"
            placeholder="Enter Variant Name"
            id="variantInput"
            autoComplete="off"
            value={value}
            onChange={handleInputChange}
            className="w-full border-gray-900 border rounded-md  p-2 placeholder:text-sm focus:outline-slate-500"
          />
          <button
            onClick={handleAddVariant}
            className="ml-2 bg-blue-500 text-white px-4 py-2 rounded"
          >
            Add
          </button>
        </div>
      </div>
      <div className="mt-3">
        {variantsList.map((item, index) => {
          return (
            <VariantBox
              key={index}
              item={item}
              index={index}
              setVariantsList={setVariantsList}
              variantsList={variantsList}
              getColorArray={(index, e) => getColorArray(index, e)}
              // getVariantArray={(index, e) => getVariantArray(index, e)}
            />
          );
        })}
      </div>
    </>
  );
};

export default VariantInputComponent;
