import React, { useState } from 'react';

const TagInput = ({ tags, setTags, label, name, onChange }) => {
  const [tagInput, setTagInput] = useState('');

  const handleInputChange = (e) => {
    const newTagInput = e.target.value;
    setTagInput(newTagInput);
    onChange(name, [...tags, newTagInput.trim()]);
  };


  const handleAddTag = (e) => {
    e.preventDefault();
    if (tagInput.trim() !== '' && !tags.includes(tagInput)) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleDeleteTag = (tagToDelete) => {
    const updatedTags = tags.filter((tag) => tag !== tagToDelete);
    setTags(updatedTags);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag(e);
    }
  };

  return (
    <div>
      <label htmlFor="tagInput" className="pb-2 text-md font-medium">
        {label}
      </label>
      <div className="flex">
        <input
          type="text"
          name="tagInput"
          placeholder="Type tag and press Enter"
          value={tagInput}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          className="w-full border-gray-900 border rounded-md p-2 placeholder:text-sm focus:outline-slate-500"
        />
        <button
          onClick={handleAddTag}
          className="ml-2 bg-blue-500 text-white px-4 py-2 rounded"
        >
          Add
        </button>
      </div>
      <div className="tags-container flex flex-wrap gap-1 mt-3">
        {tags.map((tag, index) => (
          <div
            key={index}
            className="tag bg-transparent border-black border text-gray-800 px-2 py-1 rounded mr-2 mb-2 flex items-center m-0"
          >
            <span className="mr-2">{tag}</span>
            <button
              onClick={() => handleDeleteTag(tag)}
              className="text-red-500"
              type="button" // Add type="button" to prevent form submission
            >
              x
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TagInput;
