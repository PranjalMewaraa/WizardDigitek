import React, { useState } from 'react';



const AdminLargeInputField = (props) => {

    const { label, placeholder, name, maxChar, inputSize, onChange } = props;
    const [value, setValue] = useState('');

    const handleInputChange = (e) => {
        setValue(e.target.value);
        onChange(e.target.name, e.target.value);
    };

    return (
        <div>
            <label htmlFor={name}
                className='pb-2 text-md font-medium'>{label}</label>
            <textarea type="text"
                name={name}
                placeholder={placeholder}
                id={name}
                autoComplete='off'
                value={value}
                onChange={handleInputChange}
                required
                className={`w-full border-gray-900 border rounded-md p-2 resize-none placeholder:text-sm focus:outline-slate-500 ${inputSize === "medium" ? "h-32" : "h-56"}`} />
            {maxChar && <p className='text-right text-xs text-gray-500'>Max. {maxChar} characters</p>}
        </div>
    );
};

export default AdminLargeInputField;