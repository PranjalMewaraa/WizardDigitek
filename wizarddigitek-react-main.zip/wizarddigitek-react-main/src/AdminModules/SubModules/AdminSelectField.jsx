import React, { useState } from "react";

const AdminSelectField = (props) => {
  const { label, options, name, onChange, disable } = props;
  const [selectedValue, setSelectedValue] = useState("");

  const handleSelectChange = (e) => {
    setSelectedValue(e.target.value);
    onChange(name, e.target.value);
  };

  return (
    <div>
      <label htmlFor={name} className="pb-2 text-md font-medium">
        {label}
      </label>
      <select
        name={name}
        defaultValue={selectedValue}
        id={name}
        disabled={disable}
        placeholder="Select from dropdown"
        onChange={handleSelectChange}
        className="w-full border-gray-900 border rounded-md p-2 focus:outline-slate-500"
      >
        <option disabled selected>
          Select an option... ...
        </option>
        {options?.map((option, index) => (
          <option key={index} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default AdminSelectField;
