import React, { useState } from 'react';



const AdminInputField = (props) => {

    const { label, placeholder, name, onChange, inputType, disabled  } = props;
    const [value, setValue] = useState('');

  const handleInputChange = (e) => {
    setValue(e.target.value);
    // console.log(value)
    onChange(e.target.name, e.target.value);
  };

    return (
        <div>
            <label htmlFor={name}
                className='pb-2 text-md font-medium'>
                {label}
            </label>
            <input type={inputType ? inputType : 'text'}
                min={0}
                name={name}
                placeholder={placeholder}
                id={name}
                autoComplete='off'
                value={value}
                onChange={handleInputChange}
                required
                className='w-full border-gray-900 border rounded-md  p-2 placeholder:text-sm focus:outline-slate-500' />
        </div>
    );
};

export default AdminInputField;