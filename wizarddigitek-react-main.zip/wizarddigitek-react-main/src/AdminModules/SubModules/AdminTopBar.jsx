import React from 'react';

const AdminTopBar = () => {

    const adminUser = {
        profile: require('../../assets/Images/adminAssets/profile.png'),
        username: "Admin"
      }


    return (
        <div className="titleBar-admin">
            <div className="titleBar-admin-profile">
                <img src={adminUser.profile} alt="adminProfileImg" className="admin-img" />
                <h3 className='admin-name'>Hey! {adminUser.username}</h3>
            </div>
        </div>
    );
};

export default AdminTopBar;