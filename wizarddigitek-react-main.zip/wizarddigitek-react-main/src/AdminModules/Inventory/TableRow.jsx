import React, { useState } from "react";

import deleteBtn from "../../assets/Images/adminAssets/delete-outline.svg";
import redoBtn from "../../assets/Images/adminAssets/redo.svg";
import axios from "axios";
import { Link } from "react-router-dom";
import inv from "../../assets/Images/inv.png";
import externalLink from "./externalLink.svg";

const API_ROUTE = "api/wizard";

function ProcessImage(imageObject) {
  if (imageObject !== null) {
    const folder = imageObject?.path.split("\\")[0];
    const fileName = imageObject.name;

    const path = `${process.env.REACT_APP_HOST}/api/${folder}`;
    return path;
  } else {
    return " ";
  }
}

const TableRow = (props) => {
  const { product } = props;

  const [deleted, setDeleted] = useState(false);

  const handleProductDelete = async () => {
    try {
      const response = await axios.delete(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/product?id=${product.id}`
      );

      console.log(response);
      setDeleted(true);
      window.location.reload();
    } catch (error) {
      console.log(error);
    }
  };

  const handleProductRedo = async () => {
    try {
      setDeleted(false);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="w-full py-3 px-2 border-slate-200 border-b grid grid-cols-12 gap-8 font-[inter] text-gray-600 odd:bg-gray-100 items-center text-sm">
      <div className="col-span-1 px-3">
        <img
          className="h-8 truncate"
          src={
            ProcessImage(product.thumbnail) === ""
              ? inv
              : ProcessImage(product.thumbnail)
          }
          alt={product.productName}
        />
      </div>
      <div className="col-span-2">{product.productCode}</div>
      <div className="col-span-1">{product.productType?.productType}</div>
      <div className="col-span-4 truncate">{product.productName.name}</div>
      <div className="col-span-2 flex justify-center items-center text-white text-xs">
        <Link
          to={`/product/${product.id}`}
          target="_blank"
          className="bg-slate-500 hover:bg-slate-600 py-2 px-2.5 rounded cursor-pointer flex justify-center items-center gap-1.5"
        >
          <p>Visit</p>
          <img className="w-3.5" src={externalLink} />
        </Link>
      </div>
      <div className="col-span-1 place-self-center">{product.quantity}</div>
      <div className="col-span-1 place-self-center">
        {deleted === false ? (
          <img
            className="h-6 cursor-pointer hover:"
            src={deleteBtn}
            alt="Delete"
            onClick={handleProductDelete}
          />
        ) : (
          <img
            className="h-5 cursor-pointer hover:"
            src={redoBtn}
            alt="Delete"
            onClick={handleProductRedo}
          />
        )}
      </div>
    </div>
  );
};

export default TableRow;
