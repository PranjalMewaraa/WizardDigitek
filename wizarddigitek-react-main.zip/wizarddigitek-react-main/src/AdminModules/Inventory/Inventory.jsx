import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Inventory.css'
import TableRow from './TableRow';
import { Link } from 'react-router-dom';

import redo_gray from '../../assets/Images/adminAssets/redo_gray.svg'

const API_ROUTE = 'api/wizard'

const Inventory = () => {
    const [products, setProducts] = useState([]);
    const [filteredProducts, setFilteredProducts] = useState([])
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');


    useEffect(() => {
        handleDataRefresh();
    }, [])


    const handleDataRefresh = () => {
        // console.log(`${process.env.REACT_APP_HOST}/${API_ROUTE}/products`)
        try {
            axios.get(`${process.env.REACT_APP_HOST}/${API_ROUTE}/products`).then((response) => {
                setProducts(response.data.data?.rows);
                setFilteredProducts(response.data.data?.rows);
                setLoading(false);
                console.log(response.data.data.rows)
            }
            )
        } catch (error) {
            console.log(error);
        }
    }



    const handleSearch = (e) => {
        const searchTerm = e.target.value;
        setSearch(searchTerm);
        console.log(searchTerm)

        const filteredItems = products.filter(item =>
            item.productName.toLowerCase().includes(searchTerm.toLowerCase()) || item.productCode.toLowerCase().includes(searchTerm.toLowerCase()) || item.productType?.productType.toLowerCase().includes(searchTerm.toLowerCase())
        );
        console.log(filteredItems)

        setFilteredProducts(filteredItems)
    }



    if (loading) {
        return <div>Loading...</div>; // Render a loader if data is still being fetched
    }

    return (
        <div className='inventoryContainer mt-10 mx-[6vmax]'>
            <div className='flex justify-between items-center'>
                <h1 className='font-bold text-[1.5vmax] m-0'>Inventory</h1>
                <div className='flex gap-6'>
                    {/* Refresh Data Button */}
                    <button
                        onClick={handleDataRefresh}
                        className='flex gap-2 items-center justify-center bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium cursor-pointer px-4 py-2 rounded-md'>
                        Refresh Data <img src={redo_gray} alt="redo" className='w-3' />
                    </button>
                    {/* Search Bar */}
                    <div>
                        <input type='text'
                            placeholder='Search Product Name, Category, Code'
                            value={search}
                            onChange={handleSearch}
                            className='border border-gray-300 rounded-md px-4 py-2 lg:w-96 sm: 40' />
                    </div>

                    <Link to={'/admin/addproduct'} className='flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2 rounded-md'>Add Product</Link>
                </div>
            </div>
            <div className='tableContainer py-8'>
                <div className='w-full py-3 px-2 grid grid-cols-12 gap-8 font-medium border-slate-200 border-b bg-gray-200 uppercase text-gray-700 font-[inter]'>
                    <div className='col-span-1'>Product</div>
                    <div className='col-span-2'>Product Code</div>
                    <div className='col-span-1'>Category</div>
                    <div className='col-span-4'>Product Name</div>
                    <div className='col-span-2 text-center'>VISIT PRODUCT</div>
                    <div className='col-span-1 place-self-center'>Quantity</div>
                    <div className='col-span-1 place-self-center'>Delete</div>
                </div>
                {filteredProducts?.length === 0
                    ? <div className='text-center text-xl py-8'>No Products Found</div>
                    : filteredProducts?.map((item) => {
                        return <TableRow key={item.id} product={item} />
                    })}

            </div>
        </div>
    );
};

export default Inventory;