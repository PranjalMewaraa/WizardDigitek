import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import Authentication from "./service/Authentication";
export const ProtectedRoute = () => {
  const auth = new Authentication().isAdmin();
  return auth ? <Outlet /> : <Navigate to="/home" />;
};
