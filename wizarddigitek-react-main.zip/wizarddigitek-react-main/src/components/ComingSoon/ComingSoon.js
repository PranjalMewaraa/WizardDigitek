import React from 'react'
import './ComingSoon.css'
import ComingSoonImg from '../../assets/Images/comingsoon.jpg'
import NavBar from '../NavBar/NavBar'
import Footer from '../Footer/Footer'
const ComingSoon = () => {
  return (
    <div>
      <NavBar/>
      <img className='comingSoonImg' src={ComingSoonImg} alt="Coming Soon" />
      <Footer/>
    </div>
  )
}
export default ComingSoon