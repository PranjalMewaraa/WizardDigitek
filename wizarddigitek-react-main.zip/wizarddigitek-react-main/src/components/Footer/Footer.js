import React, { useState } from "react";
import "./footer.css";
import Map from "./Map";
import { Link } from "react-router-dom";
const Footer = () => {
  const [h, setH] = useState(false);
  const expand = () => {
    setH((prevState) => !prevState);
  };
  return (
    <div className="Footer">
      <div className="footer-left">
        <div className="footer-leftTop">
          <div id="leftTitle">Wizard.Digitek</div>
          <div id="leftSub">
            We are home to verity of mobile, tablets and its accessories that
            are all of best quality with products guarantee and warrantee.
          </div>
          <div className={h ? "exp" : "nexp"}>
            Our shop, Mobile Factory, situated at Bhoiwada-Parel, Mumbai,
            Maharashtra is a home to a variety of mobiles, tablets and its
            accessories that are all of best quality with product guarantee and
            warranty.
          </div>
          <div className="endbox" onClick={expand}>
            <div id="endText">More about us</div>
            <div className="dot"></div>
          </div>
        </div>
        <div className="footer-leftBottom">
          <p id="langTitle">Languages</p>
          <div className="lang-group">
            <p className="lang-choice-selected">En</p>
            {/* <p className="lang-choice-unselected">Ru</p>
            <p className="lang-choice-unselected">Fr</p>
            <p className="lang-choice-unselected">Es</p>
            <p className="lang-choice-unselected">De</p> */}
          </div>
        </div>
      </div>
      <div className="footer-right">
        <div className="footer-Rtop">
          <div className="navlinks">
            <p id="navlink">About.</p>
            <p id="navlink">
              <Link href={"#Testimonial"}>Testimonials.</Link>
            </p>
            <p id="navlink">
              <Link to={"/"}>Contact.</Link>
            </p>
            <p id="navlink">
              <Link to="/login">Login as Admin.</Link>
            </p>
          </div>
          <div className="navlinks">
            <p id="navlink">Order Query</p>
            <p id="navlink">Privacy Policy</p>
            <p id="navlink">Category.</p>
            <p id="navlink">Trending Items.</p>
          </div>
        </div>
        <div className="footer-Rbottom">
          <div className="bottomLeft">
            <div className="topB">
              <div id="ContactTitle">Contact Us</div>
              <div id="contactInfo">+91-7827999788</div>
              <div id="contactInfo">wizard1.digitek@gmail.com</div>
            </div>
            <div className="downB">
              <div id="LocationTitle">Location</div>
              <div id="LocationInfo">
                C-6/232, Yamuna Vihar,New Delhi, 100101
              </div>
            </div>
          </div>

          <div className="bottomRight">
            <Map />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
