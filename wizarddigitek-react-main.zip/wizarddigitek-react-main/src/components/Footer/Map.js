// src/components/Map.js
import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

const Map = () => {
  const position = [28.699966928720936, 77.2792780445347]; // Replace with the desired latitude and longitude.

  return (
    // <div className="map-container">
    //   <MapContainer center={position} zoom={13} style={{ width: "300px", height: "300px" }}>
    //     <TileLayer
    //       url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
    //       attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    //     />
    //     <Marker position={position}>
    //       <Popup>Shop Location</Popup>
    //     </Marker>
    //   </MapContainer>
    // </div>


    <div className="map-container">
      <MyMap/>
    </div>
  );
};



const MyMap = () => {
  return (
    <div style={{ width: '100%' }}>
      <iframe
        title="My Location"
        width="100%"
        height="300"
        frameBorder="0"
        scrolling="no"
        marginHeight="0"
        marginWidth="0"
        src="https://maps.google.com/maps?width=100%25&amp;height=300&amp;hl=en&amp;q=Wizard Digitek,%20B-232,%20Block%20C,%20Yamuna%20Vihar,%20Shahdara,%20Delhi,%20110053+(Wizard%20Digitek%20Computers%20Pvt%20Ltd)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"
        allowFullScreen
      >
      </iframe>
    </div>
  );
};

export default Map;


