import React from "react";
import { Link } from "react-router-dom";
import heartFilled from "../../assets/Images/favoritefilled.png";
import quickViewIcon from "../../assets/Images/quickView.png";
import "./MergedProductCard.css";
import inv from "../../assets/Images/inv.png";
const ColorOpt = () => {
  return (
    <div>
      <div className="colorOpt"></div>
    </div>
  );
};

const MergedProductCard = ({
  productId,
  productImage,
  productName,
  productDiscountPrice,
  productPrice,
  productCondition,
  colors,
  pid,
}) => {
  var path;

  if (productImage === null) {
    path = "";
  } else {
    const folder = productImage?.path.split("\\")[0];
    const fileName = productImage?.name;
    path = `${process.env.REACT_APP_HOST}/api/${folder}`;
  }

  const name = productName.name || "";
  const displayName = name.length < 20 ? name : `${name.slice(0, 20)}...`;
  return (
    <div className="MergedProductCard">
      <div className="card">
        <Link
          to={{
            pathname: `/product/${productId}`,
            state: { data: { type: pid } },
          }}
          className="cardLink"
        >
          <div className="cardHead">
            <div className="leftHead">
              <div className="tag">
                <p id="tag">{productCondition}</p>
              </div>
            </div>
            <div className="rightHead"></div>
          </div>
          <div className="cardBody">
            <div className="bodyMid">
              <img src={path === "" ? inv : path} alt="pd_img" />
            </div>
            <div className="bodyBottom">
              <div className="colorOptGroup">
                <p>{colors}+ colors</p>
              </div>
            </div>
          </div>
        </Link>
        <div className="cardFooter">
          <Link to={`/product/${productId}`} className="ShowMoreBtn">
            Show More
          </Link>
        </div>
      </div>
      <div className="cardInfo">
        <p className="productName">{displayName}</p>
        <p className="ProductPrice">
          ₹{productDiscountPrice} <span> </span>
          <span id="ogp"> ₹{productPrice}</span>
          {/* ₹{productDiscountPrice}{" "}
          <span id="line">₹{productPrice}</span> */}
        </p>
      </div>
    </div>
  );
};

export default MergedProductCard;
