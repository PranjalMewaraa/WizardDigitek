import React from "react";
import { Link } from "react-router-dom";
import "./pcard.css";
function ProcessImage(imageObject) {
  const folder = imageObject?.path.split("\\")[0];
  const fileName = imageObject?.name;
  const path = `${process.env.REACT_APP_HOST}/api/${folder}/${fileName}`;
  return path;
}

const ProductCard = ({
  productId,
  productImage,
  productName,
  productDiscountPrice,
  productPrice,
  productCondition,
  colors,
}) => {
  return (
    <div className="fullcard">
      <div className="product-card">
        <Link to={{pathname:`/product/${productId}`}} className="product-image">
          <div>
            <img src={ProcessImage(productImage)} alt="productIMG" />
          </div>
          <span
            className={`condition-badge ${
              productCondition?.toLowerCase() === "new" ? "new" : "used"
            }`}
          >
            {productCondition}
          </span>
        </Link>
        <div className="product-details">
          <h5 className="product-name">{productName}</h5>
          <div className="price-section">
            <span className="starting-from-text">starting from</span>
            <p className="price">
              <span className="discounted-price">₹{productDiscountPrice}</span>
              <span className="original-price">₹{productPrice}</span>
            </p>
            <p>{colors}+ colors</p>
          </div>
        </div>
      </div>
      <Link to={`/product/${productId}`} className="check-product-btn">
        <svg
          id="svgpp"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth="1.5"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
          />
        </svg>
        Check Product
      </Link>
    </div>
  );
};

export default ProductCard;
