
import './Filter.css'
import Form from "react-bootstrap/Form";
import React from 'react'
import Button from "react-bootstrap/Button";
import search from '../../assets/Images/MagnifyingGlass.png'
import img from '../../../src/assets/Images/smallProd.png'
const BrandChoice = (props) => {
  return (
    <div id="check">
        <input type="checkbox" name={props.name} id={props.id} />
        <div id='brandChoicename'>{props.name}</div>
    </div>
  )
}


const SmallProd = (props) => {
  return (
    <div className="prodsmallcard">
          <img src={img} alt="img" id='smallProdImage'/>
          <div id='info'>
            <div id="spname">{props.spname}</div>
            <div id="sprate">{props.sprate}</div>
            <div id="spprice">{props.spprice}</div>
          </div>
    </div>
  )
}


const Filter = () => {
  return (
    <div className='Filters'>
      <div className='SearchBar'>
      <Form className="d-flex">
       <Form.Control
        type="search"
        placeholder="Search"
        className="wd-search"
        aria-label="Search"
       />
       <Button className="search-btn"><img src={search} alt="" /></Button>
      </Form>
      </div>
      <div id="BrCat">
        <p id="filterHeading">Get Products by</p>
        <BrandChoice
            name="Sony"
            id="Sony"
        />
        <BrandChoice
            name="Apple"
            id="Apple"
        />
        <BrandChoice
            name="Samsung"
            id="Samsung"
        />
        <BrandChoice
            name="Boat"
            id="Boat"
        />
        <BrandChoice
            name="pTron"
            id="pTron"
        />
        <BrandChoice
            name="Noise"
            id="Noise"
        />
      </div>
      <div id="priceFil">
        <p id="filterHeading">Filter by Price</p>
        <div className='rangeComp'></div>
      </div>
      <div id="latProd">
        <p id="filterHeading">Latest Products</p>
        <SmallProd
          spname="Boat Rockers"
          sprate="5 Stars"
          spprice="Rs:999"
        />
        <SmallProd
          spname="Boat Rockers"
          sprate="5 Stars"
          spprice="Rs:999"
        />
        <SmallProd
          spname="Boat Rockers"
          sprate="5 Stars"
          spprice="Rs:999"
        />
        <SmallProd
          spname="Boat Rockers"
          sprate="5 Stars"
          spprice="Rs:999"
        />
        <SmallProd
          spname="Boat Rockers"
          sprate="5 Stars"
          spprice="Rs:999"
        />
      </div>
      <div id="Prodtag">
        <p id="filterHeading">Product Tags</p>
        <div className='PTtags'>
          <p id='tagsProduct'>Tag1</p>
          <p id='tagsProduct-clicked'>Tag1</p>
          <p id='tagsProduct'>Tag1</p>
          <p id='tagsProduct'>Tag1</p>
          <p id='tagsProduct'>Tag1</p>
          <p id='tagsProduct'>Tag1</p>
          <p id='tagsProduct'>Tag1</p>
          <p id='tagsProduct'>Tag1</p>
        </div>
      </div>
    </div>
  )
}

export default Filter
