import Button from "react-bootstrap/Button";
import search from "../../assets/Images/MagnifyingGlass.png";
import img from "../../../src/assets/Images/smallProd.png";
import "./Filter.css";
import "./MainSec.css";
import Form from "react-bootstrap/Form";
import React, { useEffect, useState } from "react";
import ProductCard from "../ProductCard/ProductCard";
import axios from "axios";
import pimg from "../../assets/Images/productimage.png";
import MergedProductCard from "../ProductCard/MergedProductCard";
import { Link } from "react-router-dom";
import inv from "../../assets/Images/inv.png";
import "../../modules/Categories/Apple/Apple.css";
const API_ROUTE = "api/wizard";

const ListingRow = ({ heading, products }) => {
  return (
    <div className="">
      <p className="w-full py-10 text-3xl font-medium mb-3">{heading}</p>
      <div id="listrr" className="flex gap-y-4 gap-x-3">
        <div className="rrl flex gap-y-4 gap-x-3 ">
          {products?.map((item, index) => {
            return (
              <MergedProductCard
                key={item.id}
                productCondition={item.productCondition}
                productId={item.id}
                productImage={item.thumbnail}
                productName={item.productName}
                productPrice={item.variant[0].color[0].price}
                productDiscountPrice={item.variant[0].color[0].discountPrice}
                colors={item.variant[0].color.length}
                pid={item.productTypeId}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};

const ListR = ({ allProducts }) => {
  const products =
    allProducts.length > 5 ? allProducts?.slice(0, 5) : allProducts;
  console.log("ppp", products);
  return (
    <>
      {products.slice(0, 5)?.map((item) => {
        // <SmallProd
        //    key={item.id}
        //    img={item.thumbnail}

        //    spname={item.productName}
        //    sprate={item.variant[0].color[0].price}
        //    spprice={item.variant[0].color[0].discountPrice}
        // />
        return (
          <SmallProd
            key={item.id}
            spid={item.id}
            img={item.thumbnail}
            spname={item.productName.slice(0, 15)}
            sprate={item.variant[0].color[0].price}
            spprice={item.variant[0].color[0].discountPrice}
          />
        );
      })}
    </>
  );
};

const BrandChoice = (props) => {
  return (
    <div id="check">
      <input
        type="checkbox"
        name={props.name}
        id={props.id}
        value={props.value}
        onChange={props.handleCheckboxChange}
      />
      <div id="brandChoicename">{props.name}</div>
    </div>
  );
};

function ProcessImage(imageObject) {
  if (imageObject !== null) {
    const folder = imageObject?.path.split("\\")[0];
    const fileName = imageObject.name;

    const path = `${process.env.REACT_APP_HOST}/api/${folder}`;
    return path;
  } else {
    return " ";
  }
}
const SmallProd = (props) => {
  console.log("SmallProd");
  const name = props.name;
  return (
    <Link to={`/product/${props.spid}`}>
      <div className="prodsmallcard">
        <img
          src={ProcessImage(props.img) === "" ? inv : ProcessImage(props.img)}
          alt="img"
          id="smallProdImage"
        />
        <div id="info">
          <div id="spname">{props.spname}</div>
          <div
            id="sprate"
            style={{ textDecorationLine: "line-through", color: "red" }}
          >
            {`MRP. ${props.sprate}`}
          </div>
          <div id="spprice" style={{ fontWeight: "bold" }}>
            {`Rs.${props.spprice}`}
          </div>
        </div>
      </div>
    </Link>
  );
};

const Filter = ({ filterData }) => {
  const fData = filterData;
  const [checkedItems, setCheckedItems] = useState([]);
  const [apiUrl, setApiUrl] = useState(
    "${process.env.REACT_APP_HOST}/${API_ROUTE}products?"
  );

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;

    setCheckedItems((prevCheckedItems) => {
      const updatedItems = checked
        ? [...prevCheckedItems, value]
        : prevCheckedItems.filter((item) => item !== value);

      setApiUrl(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}products?${updatedItems
          .map((val) => `productTypeId=${val}`)
          .join("&")}`
      );
      console.log(apiUrl);
      return updatedItems;
    });
  };

  return (
    <div className="Filters">
      <div className="SearchBar">
        <Form className="d-flex">
          <Form.Control
            type="search"
            placeholder="Search"
            className="wd-search"
            aria-label="Search"
          />
          <Button className="search-btn">
            <img src={search} alt="" />
          </Button>
        </Form>
      </div>
      <div id="BrCat">
        <p id="filterHeading">Get Products by</p>
        {fData.map((data) => {
          return (
            <BrandChoice
              key={data.id}
              name={data.name}
              id={data.name}
              value={data.id}
              checked={checkedItems.includes(data.id)}
              handleCheckboxChange={handleCheckboxChange}
            />
          );
        })}
      </div>
      <div id="priceFil">
        <p id="filterHeading">Filter by Price</p>
        <div className="rangeComp"></div>
      </div>
      <div id="latProd">
        <p id="filterHeading">Latest Products</p>
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
      </div>
      <div id="Prodtag">
        <p id="filterHeading">Product Tags</p>
        <div className="PTtags">
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct-clicked">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
        </div>
      </div>
    </div>
  );
};

const AppleMainSection = ({
  products,
  categoryName,
  pageType,
  Aid,
  searchTerm,
}) => {
  const [allProducts, setProducts] = useState([]);
  const [filterData, setFilterData] = useState([]);
  const [checkedItems, setCheckedItems] = useState([]);
  const [master, setMaster] = useState([]);
  const [pageID, setID] = useState("");
  const [apiUrl, setApiUrl] = useState(
    `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}`
  );
  const [keyword, setKeyword] = useState("");
  const [minp, setMinP] = useState(0);
  const [maxp, setMaxP] = useState(150000);
  const [pdata, setPData] = useState([]);

  let filterProduct = [];
  allProducts.forEach((item) => filterProduct.push(item));
  console.log("sdsd", filterProduct);

  // const handleminChange = (e) => {
  //   const { value } = e.target;
  //   setMinP(value > 0 ? value : 0);
  // };
  // const handlemaxChange = (e) => {
  //   const { value } = e.target;
  //   setMaxP(value > 0 ? value : 0);
  // };

  // const handleCheckboxChange = (event) => {
  //   const { value, checked } = event.target;
  //   console.log("CBCB", pageID);
  //   setCheckedItems((prevCheckedItems) => {
  //     const filter = pageType === "Type" ? "Brand" : "Type";
  //     const updatedItems = checked
  //       ? [...prevCheckedItems, value]
  //       : prevCheckedItems.filter((item) => item !== value);

  //     const updatedApiUrl = `${
  //       process.env.REACT_APP_HOST
  //     }/${API_ROUTE}/products?product${pageType}Id=${pageID}&${updatedItems
  //       .map((val) => `product${filter}Id=${val}`)
  //       .join("&")}`; //product${filter}Id=${Aid}&
  //     setApiUrl(updatedApiUrl);

  //     // Now use the updatedApiUrl instead of apiUrl
  //     console.log(updatedApiUrl);

  //     // Also, fetch data using the updatedApiUrl
  //     getProductData(updatedApiUrl);

  //     return updatedItems;
  //   });
  // };

  const fetchDataID = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/product${pageType}s`
      );
      setMaster(response.data.data);
      console.log("Master", response.data.data);

      const foundb = response.data.data.find(
        (brand) => brand.name === categoryName
      );

      if (!foundb) {
        throw new Error("No such product type exists.");
      } else {
        setID(foundb.id);
        console.log("ID", foundb.id);
      }
    } catch (error) {
      console.error(error.message);
    }
  };

  const getFilterData = (pageType, categoryName) => {
    try {
      const filter = pageType === "Type" ? "Brand" : "Type";
      axios
        .get(`${process.env.REACT_APP_HOST}/${API_ROUTE}/product${filter}s`)
        .then((response) => {
          setFilterData(response.data.data);
          console.log("filter", response.data.data);
        });
      fetchDataID();
    } catch (error) {
      console.log(error);
    }
  };
  const onSearch = (event) => {
    setKeyword(event.target.value);
  };
  const [selectID, setSelectID] = useState([]);

  const updatePage = () => {
    // console.log(apiUrl);
  };

  const getProductData = (apiUrl) => {
    try {
      axios.get(apiUrl).then((response) => {
        console.log("passed", apiUrl);
        setProducts(response.data.data?.rows);
        console.log("passed", allProducts);
      });
    } catch (error) {
      console.log(error);
      console.log("fail");
    }
  };
  useEffect(() => {
    getProductData(apiUrl);
  }, [apiUrl]);
  useEffect(() => {
    console.log("ms", searchTerm);
    getFilterData();
    fetchDataID();
    getProductData(
      `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}`
    );

    // try {
    //   axios.get(apiUrl).then((response) => {
    //     console.log("passed", apiUrl);
    //     setPData(response.data.data?.rows);
    //     console.log("passed", pdata);
    //   });
    // } catch (error) {
    //   console.log(error);
    //   console.log("fail");
    // }
  }, []);

  useEffect(() => {
    fetchDataID();
  }, [categoryName]); // Add categoryName as a dependency since it's being used in fetchDataID

  useEffect(() => {
    // Use the updated apiUrl whenever pageID changes
    setApiUrl(
      `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}`
    );
    getFilterData(pageType);
  }, [pageID]);

  const AppleProductsList = [
    {
      img: require("../../assets/Images/Apple/macbook.png"),
      name: "MacBook",
      title: "Laptop",
    },
    {
      img: require("../../assets/Images/Apple/ipad.png"),
      name: "iPad",
      title: "Laptop",
    },
    {
      img: require("../../assets/Images/Apple/iphone.png"),
      name: "iPhone",
      title: "Mobile",
    },
    {
      img: require("../../assets/Images/Apple/iwatch.png"),
      name: "iWatch",
      title: "Smartwatches",
    },
    {
      img: require("../../assets/Images/Apple/airpods.png"),
      name: "Airpods",
      title: "Earphone",
    },
  ];
  const [active, setActive] = useState(2);
  const handleTabClick = (title, index) => {
    setActive(index);

    const objID = filterData.find(
      (filter) => filter.name.toLowerCase() === title.toLowerCase()
    );
    console.log(objID);
    const ids = objID.id;
    setApiUrl(
      `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?productBrandId=${pageID}&productTypeId=${ids}`
    );

    console.log("ONCLICK", apiUrl);
    getProductData(apiUrl);
  };

  return (
    <div className="flex w-full flex-col gap-y-4">
      <div className="products-apple-cat">
        <h2 className="product-apple-title">Apple Products</h2>
        <div className="product-apple-items">
          {AppleProductsList.map((item, index) => {
            return (
              <div
                key={item.id}
                className={index === active ? "Xactive" : "Xinactive"}
                onClick={() => {
                  handleTabClick(item.title, index);
                }}
              >
                <img src={item.img} alt="img" className="product-apple-img" />
                <h3 className="product-apple-name">{item.name}</h3>
              </div>
            );
          })}
        </div>
      </div>
      <div className="msec my-[3.5vmax] w-[90vw] min-h-screen h-fit flex mx-auto gap-8">
        <div className="w-[90%] flex flex-wrap ">
          <ListingRow
            heading={`Check our Range of ${categoryName} - ${AppleProductsList[active].name}`}
            products={allProducts}
          />
        </div>
      </div>
    </div>
  );
};

export default AppleMainSection;
