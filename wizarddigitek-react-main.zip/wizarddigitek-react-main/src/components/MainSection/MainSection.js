import Button from "react-bootstrap/Button";
import search from "../../assets/Images/MagnifyingGlass.png";
import img from "../../../src/assets/Images/smallProd.png";
import "./Filter.css";
import "./MainSec.css";
import Form from "react-bootstrap/Form";
import React, { useEffect, useState } from "react";
import ProductCard from "../ProductCard/ProductCard";
import axios from "axios";
import pimg from "../../assets/Images/productimage.png";
import MergedProductCard from "../ProductCard/MergedProductCard";
import { Link } from "react-router-dom";
import inv from "../../assets/Images/inv.png";
import Pagination from "../Pagination/Pagination";
const API_ROUTE = "api/wizard";

const ListingRow = ({ heading, products, count }) => {
  return (
    <div className="">
      <div className="flex justify-between items-center">
        <p className="text-2xl font-medium mb-3">{heading}</p>
        <p>Total Items : {count}</p>
      </div>
      <div id="listrr" className="flex gap-y-4 gap-x-3">
        <div className="rrl flex gap-y-4 gap-x-3 ">
          {products?.map((item, index) => {
            return (
              <MergedProductCard
                key={item.id}
                productCondition={item.productCondition}
                productId={item.id}
                productImage={item.thumbnail}
                productName={item.productName}
                productPrice={item.variant[0].color[0].price}
                productDiscountPrice={item.variant[0].color[0].discountPrice}
                colors={item.variant[0].color.length}
                pid={item.productTypeId}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};

const ListR = ({ allProducts }) => {
  const products =
    allProducts.length > 5 ? allProducts?.slice(0, 4) : allProducts;
  // console.log("ppp", products);
  return (
    <>
      {products.slice(0, 4)?.map((item) => {
        // <SmallProd
        //    key={item.id}
        //    img={item.thumbnail}

        //    spname={item.productName}
        //    sprate={item.variant[0].color[0].price}
        //    spprice={item.variant[0].color[0].discountPrice}
        // />
        return (
          <SmallProd
            key={item.id}
            spid={item.id}
            img={item.thumbnail}
            spname={item.productName.name?.slice(0, 15)}
            sprate={item.variant[0].color[0].price}
            spprice={item.variant[0].color[0].discountPrice}
          />
        );
      })}
    </>
  );
};

const BrandChoice = (props) => {
  return (
    <div id="check">
      <input
        type="checkbox"
        name={props.name}
        id={props.id}
        value={props.value}
        onChange={props.handleCheckboxChange}
      />
      <div id="brandChoicename">{props.name}</div>
    </div>
  );
};

function ProcessImage(imageObject) {
  if (imageObject !== null) {
    const folder = imageObject?.path.split("\\")[0];
    const fileName = imageObject.name;

    const path = `${process.env.REACT_APP_HOST}/api/${folder}`;
    return path;
  } else {
    return " ";
  }
}
const SmallProd = (props) => {
  console.log("SmallProd");
  const name = props.name;
  return (
    <Link to={`/product/${props.spid}`}>
      <div className="prodsmallcard">
        <img
          src={ProcessImage(props.img) === "" ? inv : ProcessImage(props.img)}
          alt="img"
          id="smallProdImage"
        />
        <div id="info">
          <div id="spname">{props.spname}</div>
          <div
            id="sprate"
            style={{ textDecorationLine: "line-through", color: "red" }}
          >
            {`MRP. ${props.sprate}`}
          </div>
          <div id="spprice" style={{ fontWeight: "bold" }}>
            {`Rs.${props.spprice}`}
          </div>
        </div>
      </div>
    </Link>
  );
};

const Filter = ({ filterData }) => {
  const fData = filterData;
  const [checkedItems, setCheckedItems] = useState([]);
  const [apiUrl, setApiUrl] = useState(
    "${process.env.REACT_APP_HOST}/${API_ROUTE}products?"
  );

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;

    setCheckedItems((prevCheckedItems) => {
      const updatedItems = checked
        ? [...prevCheckedItems, value]
        : prevCheckedItems.filter((item) => item !== value);

      setApiUrl(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}products?${updatedItems
          .map((val) => `productTypeId=${val}`)
          .join("&")}`
      );
      console.log(apiUrl);
      return updatedItems;
    });
  };

  return (
    <div className="Filters">
      <div className="SearchBar">
        <Form className="d-flex">
          <Form.Control
            type="search"
            placeholder="Search"
            className="wd-search"
            aria-label="Search"
          />
          <Button className="search-btn">
            <img src={search} alt="" />
          </Button>
        </Form>
      </div>
      <div id="BrCat">
        <p id="filterHeading">Get Products by</p>
        {fData.map((data) => {
          return (
            <BrandChoice
              key={data.id}
              name={data.name}
              id={data.name}
              value={data.id}
              checked={checkedItems.includes(data.id)}
              handleCheckboxChange={handleCheckboxChange}
            />
          );
        })}
      </div>
      <div id="priceFil">
        <p id="filterHeading">Filter by Price</p>
        <div className="rangeComp"></div>
      </div>
      <div id="latProd">
        <p id="filterHeading">Latest Products</p>
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
        <SmallProd spname="Boat Rockers" sprate="5 Stars" spprice="Rs:999" />
      </div>
      <div id="Prodtag">
        <p id="filterHeading">Product Tags</p>
        <div className="PTtags">
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct-clicked">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
          <p id="tagsProduct">Tag1</p>
        </div>
      </div>
    </div>
  );
};

const MainSection = ({ products, categoryName, pageType, Aid, searchTerm }) => {
  const [count, setCount] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  const [maxPage, setMaxPage] = useState(5);
  let items = [];
  let leftSide = currentPage - 2;
  const searchTermx = searchTerm || "";
  const [allProducts, setProducts] = useState([]);
  const [allFProducts, setFProducts] = useState([]);
  const [filterData, setFilterData] = useState([]);
  const [checkedItems, setCheckedItems] = useState([]);
  const [master, setMaster] = useState([]);
  const [pageID, setID] = useState("");
  const [apiUrl, setApiUrl] = useState(
    `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}`
  );
  const [keyword, setKeyword] = useState("");
  const [minp, setMinP] = useState(0);
  const [maxp, setMaxP] = useState(150000);
  const [pdata, setPData] = useState([]);
  const [pCount, setPCount] = useState(0);
  let filterProduct = [];
  allProducts.forEach((item) => filterProduct.push(item));
  //console.log("sdsd", filterProduct);

  const handleminChange = (e) => {
    const { value } = e.target;
    setMinP(value > 0 ? value : 0);
  };
  const handlemaxChange = (e) => {
    const { value } = e.target;
    setMaxP(value > 0 ? value : 0);
  };

  const handleCheckboxChange = (event) => {
    const { value, checked } = event.target;
    console.log("CBCB", pageID);
    setCheckedItems((prevCheckedItems) => {
      const filter = pageType === "Type" ? "Brand" : "Type";
      const updatedItems = checked
        ? [...prevCheckedItems, value]
        : prevCheckedItems.filter((item) => item !== value);

      const updatedApiUrl = `${
        process.env.REACT_APP_HOST
      }/${API_ROUTE}/products?product${pageType}Id=${pageID}&${updatedItems
        .map((val) => `product${filter}Id=${val}`)
        .join("&")}`; //product${filter}Id=${Aid}&
      setApiUrl(updatedApiUrl);

      // Now use the updatedApiUrl instead of apiUrl
      console.log(updatedApiUrl);

      // Also, fetch data using the updatedApiUrl
      getProductData(updatedApiUrl);

      return updatedItems;
    });
  };

  const fetchDataID = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/product${pageType}s`
      );
      setMaster(response.data.data);

      const foundb = response.data.data.find(
        (brand) => brand.name === categoryName
      );

      if (!foundb) {
        throw new Error("No such product type exists.");
      } else {
        setID(foundb.id);

        getNewFilterData(pageType, foundb.id);
      }
    } catch (error) {
      console.error(error.message);
    }
  };

  const getFilterData = (pageType, categoryName) => {
    try {
      axios
        .get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}`
        )
        .then((response) => {
          setFProducts(response.data.data.rows);
          console.log("filter", response.data.data.rows);
        });
      fetchDataID();
    } catch (error) {
      console.log(error);
    }
  };
  const getNewFilterData = (pageType, pageID) => {
    try {
      const filter = pageType === "Type" ? "Type" : "Brand";
      const filters = pageType === "Type" ? "Brand" : "Type";
      axios
        .get(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/product${filter}?id=${pageID}`
        )
        .then((res) => {
          if (filter === "Type") {
            //console.log("New Filter", res.data.data.productBrand);
            setFilterData(res.data.data.productBrand);
          } else {
            //console.log("New Filter", res.data.data.productType);
            setFilterData(res.data.data.productType);
          }
        });
    } catch (error) {}
  };
  const onSearch = (event) => {
    setKeyword(event.target.value);
  };
  const updatePage = () => {
    setApiUrl(
      `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}&searchKeyword=${keyword}`
    );
    //console.log(apiUrl);
  };

  const getPageCOunt = () => {
    try {
      axios.get(apiUrl).then((res) => {
        setCount(res.data.count);
        console.log("pagecount", Math.ceil(res.data.data.count / 8));
        setMaxPage(Math.ceil(res.data.data.count / 8));
      });
    } catch (error) {}
  };

  const getProductData = (apiUrl) => {
    try {
      getPageCOunt(apiUrl);
      axios.get(`${apiUrl}&page=${currentPage}`).then((response) => {
        // console.log("passed", apiUrl);
        setProducts(response.data.data?.rows);
        setPCount(response.data.data?.count);
        //  console.log("passed", allProducts);
      });
    } catch (error) {
      console.log(error);
      console.log("fail");
    }
  };
  useEffect(() => {
    getFilterData();
    getProductData(apiUrl);
  }, [apiUrl]);
  useEffect(() => {
    getFilterData();
    getProductData(apiUrl);
  }, [currentPage]);
  useEffect(() => {
    getFilterData();
    //  console.log("ms", searchTerm);
    getPageCOunt(apiUrl);
    searchTerm
      ? getProductData(
          `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?searchKeyword=${searchTerm}`
        )
      : fetchDataID();

    // getProductData(
    //   `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}`
    // );

    // try {
    //   axios.get(apiUrl).then((response) => {
    //     console.log("passed", apiUrl);
    //     setPData(response.data.data?.rows);
    //     console.log("passed", pdata);
    //   });
    // } catch (error) {
    //   console.log(error);
    //   console.log("fail");
    // }
  }, []);
  useEffect(() => {
    //console.log("pricefilter", `${apiUrl}&minPrice=${minp}&maxPrice=${maxp}`);
    getProductData(`${apiUrl}&minPrice=${minp}&maxPrice=${maxp}`);
  }, [minp, maxp]);
  useEffect(() => {
    fetchDataID();
  }, [categoryName]); // Add categoryName as a dependency since it's being used in fetchDataID

  useEffect(() => {
    // Use the updated apiUrl whenever pageID changes
    setApiUrl(
      `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?product${pageType}Id=${pageID}`
    );
  }, [pageID]);

  useEffect(() => {
    if (searchTermx.length > 0) {
      getProductData(
        `${process.env.REACT_APP_HOST}/${API_ROUTE}/products?searchKeyword=${searchTerm}`
      );
    }
  }, [searchTermx]);

  if (leftSide <= 0) leftSide = 1;
  let rightSide = currentPage + 2;
  if (rightSide > maxPage) rightSide = maxPage;
  for (let number = leftSide; number <= rightSide; number++) {
    items.push(
      <div
        key={number}
        className={
          number === currentPage ? "round-effect active" : "round-effect"
        }
        onClick={() => {
          setCurrentPage(number);
        }}
      >
        {number}
      </div>
    );
  }

  const nextPage = () => {
    if (currentPage < maxPage) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <div className="w-full flex-col items-center">
      <div className="msec my-[3.5vmax] w-[90vw] min-h-screen h-fit min-h-[900px] flex mx-auto gap-8">
        <div className="sss w-1/4 ">
          <div className="Filters w-full">
            <div className="SearchBar">
              <Form className="d-flex">
                <Form.Control
                  type="search"
                  placeholder="Search"
                  className="wd-search"
                  aria-label="Search"
                  onChange={onSearch}
                />
                <Button className="search-btn">
                  <img src={search} alt="" onClick={updatePage} />
                </Button>
              </Form>
            </div>
            <div id="BrCat">
              <p id="filterHeading">Get Products by</p>
              <div id="xxx">
                {filterData.map((data) => {
                  return (
                    <BrandChoice
                      key={data.id}
                      name={data.name}
                      id={data.name}
                      value={data.id}
                      checked={checkedItems.includes(data.id)}
                      handleCheckboxChange={handleCheckboxChange}
                    />
                  );
                })}
                {filterData.length === 0 ? <div>Loading...</div> : null}
              </div>
            </div>
            <div id="priceFil">
              <p id="filterHeading">Filter by Price</p>
              <div className="rangeComp">
                <input
                  id="minPrice"
                  type="number"
                  name="MinPrice"
                  width={"50%"}
                  placeholder="Min Price"
                  value={minp}
                  min={0}
                  minLength={0}
                  onChange={handleminChange}
                />
                <input
                  id="maxPrice"
                  type="number"
                  name="MaxPrice"
                  width={"50%"}
                  placeholder="Max Price"
                  value={maxp}
                  min={0}
                  minLength={0}
                  onChange={handlemaxChange}
                />
              </div>
            </div>
            <div id="latProd">
              <p id="filterHeading">Latest Products</p>
              <ListR allProducts={allFProducts} />
            </div>
          </div>
        </div>
        <div className="smsm">
          <ListingRow
            heading={categoryName}
            count={pCount}
            products={allProducts}
          />
        </div>
      </div>
      <div className="flex-container my-4">
        <div>
          {" "}
          Showing Page : {currentPage} out of {maxPage}
        </div>

        <div className="paginate-ctn">
          <div className="round-effect" onClick={prevPage}>
            {" "}
            &lsaquo;{" "}
          </div>
          {items}
          <div className="round-effect" onClick={nextPage}>
            {" "}
            &rsaquo;{" "}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainSection;
