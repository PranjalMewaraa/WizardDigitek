import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Link } from "react-router-dom";

import Offcanvas from "react-bootstrap/Offcanvas";
import wizardLogo from "../../assets/Images/wzLogo.svg";
import { NavItem } from "react-bootstrap";
import "./NavBar.css";
import { useState } from "react";

const NavBar = () => {
  const [keyW, getKey] = useState("");

  return (
    <>
      <Navbar expand="sm" className="bg-body-tertiary shadow-sm ">
        <Container fluid>
          <Navbar.Brand href="/" className="navbar-left">
            <NavItem className="wd-brand">
              <img className="wzLogo" src={wizardLogo} alt="" />
            </NavItem>
          </Navbar.Brand>
          <div className="navbar-center">
            <Form className="d-flex">
              <Form.Control
                type="search"
                placeholder="Search"
                className="schbr wd-search"
                aria-label="Search"
                value={keyW}
                onChange={(e) => getKey(e.target.value)}
              />
              <Button className="search-btn">
                {" "}
                <Link to={`/search/${keyW ? keyW : "1"}`}>Search</Link>{" "}
              </Button>
            </Form>
          </div>

          <Navbar.Toggle aria-controls="offcanvasNavbar-expand-lg" />
          <Navbar.Offcanvas
            id="offcanvasNavbar-expand-lg"
            aria-labelledby="offcanvasNavbarLabel-expand-md"
            placement="end"
            className="flex-grow-0"
          >
            <Offcanvas.Header closeButton>
              <Offcanvas.Title id="offcanvasNavbarLabel-expand-lg">
                Offcanvas
              </Offcanvas.Title>
            </Offcanvas.Header>
            <Offcanvas.Body>
              <Nav
                className="navbar-right justify-content-end "
                style={{ fontWeight: "600", fontSize: "large" }}
              >
                <Nav.Link href="/">Home</Nav.Link>
                <Nav.Link href="/category">Category</Nav.Link>
                {/* <Nav.Link href="/sellproduct">Sell Products</Nav.Link> */}
                <Nav.Link href="/brands">Brands</Nav.Link>
                <Nav.Link href="/about">About us</Nav.Link>
              </Nav>
            </Offcanvas.Body>
          </Navbar.Offcanvas>
        </Container>
      </Navbar>
    </>
  );
};

export default NavBar;
