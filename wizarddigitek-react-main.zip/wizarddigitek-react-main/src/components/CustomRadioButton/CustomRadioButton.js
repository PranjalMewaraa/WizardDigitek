
import React, { useState } from 'react';
import './CustomRadioButton.css';

const CustomRadioButton = ({ label, value, name, onRadioChange }) => {
  const [isChecked, setChecked] = useState(false);

  const handleRadioChange = () => {
    setChecked(!isChecked);
    onRadioChange(value); // Notify the parent component about the change
  };

  return (
    <></>
  );
};

export default CustomRadioButton;
