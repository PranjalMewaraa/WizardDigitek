import React from "react";
import "./App.css";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import Home from "./modules/Home/Home";
import LandingPage from "./modules/LandingPage/LandingPage";
import Category from "./modules/Category/Category";
import SellProduct from "./modules/LandingPage/SellProduct";
import Brands from "./modules/Brands/Brands";
import AboutUs from "./modules/About/AboutUs";
import Smartphone from "./modules/Categories/Smartphones_Cat/Smartphone";
import Apple from "./modules/Categories/Apple/Apple";
import CategoryPage from "./modules/Category/CategoryPage";
import Speakers from "./modules/Categories/Speakers/Speakers";
import Smartwatches from "./modules/Categories/Smartwatches/Smartwatches";
import LaptopTV from "./modules/Categories/LaptopTV/LaptopTV";
import About from "./modules/About/About";
import Earphone from "./modules/Earphone/Earphone";
import ComingSoon from "./components/ComingSoon/ComingSoon";
import ScrollToTop from "./components/ScrollToTop";
import AddProduct from "./AdminModules/AddProduct";
import EditLanding from "./AdminModules/EditLandingPAge/EditLanding";
import OldProductReciept from "./AdminModules/OldProductReciept";
import Samsung from "./modules/Brands/BrandPages/Samsung/Samsung";
import SOny from "./modules/Brands/BrandPages/Sony/SOny";
import Headphone from "./modules/Categories/Headphone/Headphone";
import ProductDetail from "./modules/ProductDetail/ProductDetail";
import ErrorPage from "./404Page/404Page";
import Admin from "./AdminModules/Admin";
import Inventory from "./AdminModules/Inventory/Inventory";
import GBrand from "./modules/Brands/GenericBrandHero/GBrand";
import { ProtectedRoute } from "./protected.route";
import Login from "./modules/Login/Login";
import Master from "./AdminModules/MasterPage/Master";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/home" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/sellproduct" element={<SellProduct />} />
          <Route path="/brands" element={<Brands />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/home" element={<LandingPage />} />
          <Route path="/category" element={<CategoryPage />} />
          <Route path="/smartphones" element={<Smartphone />} />
          <Route path="/apple" element={<Apple />} />
          <Route path="/speakers" element={<Speakers />} />
          <Route path="/smartwatches" element={<Smartwatches />} />
          <Route path="/laptop-tv" element={<LaptopTV />} />
          <Route path="/about" element={<About />} />
          <Route path="/earphone" element={<Earphone />} />
          <Route path="/samsung" element={<Samsung />} />
          <Route path="/sony" element={<SOny />} />
          <Route path="/headphone" element={<Headphone />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/comingsoon" element={<ComingSoon />} />
          <Route path="/search/:id" element={<GBrand />}></Route>

          {/* Admin Routes */}
          <Route path="/admin/" element={<ProtectedRoute />}>
            <Route path="dashboard" element={<EditLanding />}></Route>
            <Route path="" element={<Admin />}>
              <Route path="inventory" element={<Inventory />} />
              <Route path="addProduct" element={<AddProduct />} />
              <Route path="oldProductReciept" element={<OldProductReciept />} />
              <Route path="inventory" element={<Inventory />} />
              <Route path="Master" element={<Master />} />
              <Route
                path="*"
                element={
                  <ErrorPage text="Return to Admin Dashboard" route="/admin" />
                }
              />
            </Route>
          </Route>
          <Route
            path="*"
            element={<ErrorPage text="Return Home" route="/" />}
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
