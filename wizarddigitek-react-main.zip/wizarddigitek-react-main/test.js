const axios = require("axios");

const productData = {
  type: "mobile",
  Brand: "xiomi",
  name: "hehehehehe",
  Model: "16GB",
  Description: "sdsdsdafdsafasdfafas",
  Quantity: 20,
  specification: "PATA NHI KAISA CHINESE PHONE HAI",
  MRP: 34657346,
  Price: 453234235354,
  Thumbnail: "hjjsdfwefsfsfsfsfbzkncjksd",
};

const SendData = async () => {
  try {
    const response = await axios.post(
      "http://20.157.85.28/api/wizard/product",
      productData
    );
    console.log(response.data);
  } catch (error) {
    console.log(error);
  }
};

SendData();
