const { generateUUID } = require("../utils/generateUniqueId");

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert("users", [
      {
        id: "ec9f2769-c4c5-4a36-8c88-cffc05646ea3",
        name: "Varun Ahuja",
        email: "varunahuja@gmail.com",
        password: "vahuja@321!@##@!",
        role: "admin",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete("users", null, {});
  },
};
