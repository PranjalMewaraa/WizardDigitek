let dotenv = require("dotenv").config();
let config = dotenv.parsed;
const express = require("express");
const cors = require("cors");
const multer = require("multer");

const app = express();
const path = require("path");
const routers = require("./routes");

let whitelist = ["http://localhost:7001"];
let corsOptions = {
  origin: function (origin, callback) {
    console.log(whitelist.indexOf(origin));
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
};
app.use(cors({ origin: "*" }));
app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "uploads")));
app.use("/api/upload/", express.static(path.join(__dirname, "upload")));
app.use("/api/wizard", routers.user);
app.use("/api/wizard", routers.landingPage);
app.use("/api/wizard", routers.landingHero);
app.use("/api/wizard", routers.adBanner);
app.use("/api/wizard", routers.product);
app.use("/api/wizard", routers.colors);
app.use("/api/wizard", routers.variant);

app.use("/api/wizard", routers.productBrand);
app.use("/api/wizard", routers.productType);
app.use("/api/wizard", routers.productName);

app.use(express.static(path.join(__dirname, "build")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "build/index.html"));
});
const PORT = process.env.PORT || config.PORT;
const HOST_NAME = process.env.HOST || config.HOST;

app.listen(PORT, HOST_NAME, async () => {
  console.log(`server is running on ${HOST_NAME}:${PORT}`);
});
