let routes = require('express').Router();
let landingHero = require('../controllers/landingHero.controller');
const upload = require('../controllers/multerStorage.controller');
const verifyToken  = require('../utils/verifyToken');
routes.post("/landingHero",upload.array('img',10),  landingHero.createLandingHero);
routes.get("/landingHeros", landingHero.getAllLandingHeros);
routes.get("/landingHero", landingHero.getLandingHerobyId);
routes.put("/landingHero", upload.array('img',10), landingHero.updateLandingHeroById);
routes.put("/landingHero", landingHero.updateLandingHeroById);
routes.delete("/landingHero", landingHero.deleteLandingHeroById);


module.exports = routes