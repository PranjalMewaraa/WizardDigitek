let routes = require('express').Router();
let adBanner = require('../controllers/adBanner.controller');
const upload = require('../controllers/multerStorage.controller');
const  verifyToken  = require('../utils/verifyToken');

routes.post("/adBanner",upload.array('img',10), adBanner.createAdBanner);
routes.get("/adBanners", adBanner.getAllAdBanners);
routes.get("/adBanner", adBanner.getAdBannerbyId);
routes.put("/adBanner", upload.array('img', 10),adBanner.updateAdBannerById);
routes.delete("/adBanner", adBanner.deleteAdBannerById);

module.exports = routes