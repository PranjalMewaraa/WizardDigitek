let routes = require('express').Router();
let productType = require('../controllers/productType.controller');

routes.post("/productType", productType.createProductType);
routes.get("/productTypes", productType.getAllProductTypes);
routes.get("/category", productType.getProductTypeByBrandId);
routes.get("/productType", productType.getProductTypebyId);
routes.put("/productType", productType.updateProductTypeById);
routes.delete("/productType", productType.deleteProductTypeById);

module.exports = routes