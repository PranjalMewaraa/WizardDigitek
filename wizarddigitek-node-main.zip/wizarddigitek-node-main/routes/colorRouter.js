let routes = require('express').Router();
let color = require('../controllers/color.controller');

routes.post("/color", color.createcolor);
routes.get("/colors", color.getAllcolors);
routes.get("/color", color.getcolorbyId);
routes.put("/color", color.updatecolorById);
routes.delete("/color", color.deletecolorById);

module.exports = routes