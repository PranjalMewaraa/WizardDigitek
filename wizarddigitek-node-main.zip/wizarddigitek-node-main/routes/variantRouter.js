let routes = require('express').Router();
let variant = require('../controllers/variant.controller');

routes.post("/variant", variant.createvariant);
routes.get("/variants", variant.getAllvariants);
routes.get("/variant", variant.getvariantbyId);
routes.put("/variant", variant.updatevariantById);
routes.delete("/variant", variant.deletevariantById);

module.exports = routes