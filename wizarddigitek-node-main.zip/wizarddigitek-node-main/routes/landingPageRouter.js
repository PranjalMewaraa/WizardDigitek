let routes = require('express').Router();
let landingPage = require('../controllers/landingPage.controller');
// const upload = require('../controllers/multerStorage.controller');
// const cpUpload = upload.fields([{ name: 'adBanner', maxCount: 1 }, { name: 'heroImage', maxCount: 10 }])
routes.post("/landingPage", landingPage.createLandingPage);
routes.get("/landingPages", landingPage.getAllLandingPages);
routes.get("/landingPage", landingPage.getLandingPagebyId);
routes.put("/landingPage", landingPage.updateLandingPageById);
routes.delete("/landingPage", landingPage.deleteLandingPageById);

module.exports = routes