let routes = require('express').Router();
let user = require('../controllers/user.controller');
let validate = require("../services/validation")


routes.post("/login", user.loginUser);
routes.get("/users", user.getAllUsers);
routes.get("/user", user.getUserbyId);
routes.put("/user", user.updateUserById);
routes.delete("/user", user.deleteUserById);

module.exports = routes