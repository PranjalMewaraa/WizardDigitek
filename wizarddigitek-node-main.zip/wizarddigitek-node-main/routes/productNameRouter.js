let routes = require('express').Router();

const productNameController = require("../controllers/productName.controller");

routes.post('/name', productNameController.createProductName)
routes.get("/names", productNameController.getAllProductName)
routes.get("/name", productNameController.getProductNameId)
routes.get("/nameByBrandType", productNameController.getProductNameByBrandAndCateoryId)
routes.put("/name", productNameController.updateProductNameById);
routes.delete("/name", productNameController.deleteProductNameById)

module.exports = routes