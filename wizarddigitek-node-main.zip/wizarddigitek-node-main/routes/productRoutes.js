let routes = require('express').Router();
let product = require('../controllers/product.controller');
let verifyToken = require("../utils/verifyToken");
const upload = require('../controllers/multerStorage.controller');
const cpUpload = upload.fields([{ name: 'thumbnail', maxCount: 1 }, { name: 'productImage', maxCount: 10 }])
routes.post("/product", cpUpload, product.createproduct);
routes.get("/products", product.getAllproduct);
routes.get("/product", product.getproductById);
routes.put("/product", product.updateproduct);
routes.delete("/product", product.deleteproduct);

module.exports = routes