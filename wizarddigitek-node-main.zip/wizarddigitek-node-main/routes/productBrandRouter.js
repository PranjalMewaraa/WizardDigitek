let routes = require('express').Router();
let productBrand = require('../controllers/productBrand.controller');

routes.post("/productBrand", productBrand.createProductBrand);
routes.get("/productBrands", productBrand.getAllProductBrands);
routes.get("/productBrand", productBrand.getProductBrandbyId);
routes.put("/productBrand", productBrand.updateProductBrandById);
routes.delete("/productBrand", productBrand.deleteProductBrandById);

module.exports = routes