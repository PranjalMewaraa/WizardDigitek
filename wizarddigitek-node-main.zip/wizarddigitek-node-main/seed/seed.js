const { user } = require('../models');
const bcrypt = require('bcrypt'); 
const { generateUniqueId } = require('../utils/generateUniqueId'); 


const users = [
    {
      id: generateUniqueId(), 
      name: 'John Doe',
      email: 'john@example.com',
      password: bcrypt.hashSync('password123', 10),
      role: 'admin', 
      createdAt: new Date(),
      updatedAt: new Date()
    },
  ];
  
  async function seedUsers() {
    try {
      await user.bulkCreate(users); 
      console.log('Users seeded successfully.');
    } catch (error) {
      console.error('Error seeding users:', error);
    }
  }
  
  seedUsers();