let validateEmail = (req, res, next) => {
    const email = req.body.email;
  
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.match(emailRegex)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }
  
    next();
  };

 let validatePassword = (req, res, next) => {
    const password = req.body.password;
  
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
  
    next();
  };

  module.exports = {validateEmail,validatePassword }