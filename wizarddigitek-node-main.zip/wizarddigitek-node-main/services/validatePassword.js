exports.validatePasswordMiddleware = (req, res, next) => {
    const password = req.body.password;
  
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
  
    next();
  };