module.exports = (obj) => {
    try {
        if (!obj) return null;
        let {
            id,
            name,
            displayName,
            description,
            activeFlag
        } = obj;
        return { 
            id,
            name,
            displayName,
            description,
            activeFlag
        };
    } catch (error) {
        throw error;
    }
};