let modelHelper = {}
modelHelper.brand = require("./brandModel");
modelHelper.category = require("./categoryModel")
modelHelper.product = require("./product")
module.exports = modelHelper