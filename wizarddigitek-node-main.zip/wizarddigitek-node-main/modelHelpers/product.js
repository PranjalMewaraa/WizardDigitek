module.exports = (data) => {
    let { productCondition,
        productTypeId,
        productBrandId,
        productNameId,
        productCode,
        productDesc,
        quantity,
        productSpecs,
        DiscountPrice,
        colorOptions,
        price } = data;
    productSpecs = (typeof productSpecs === 'string') ? JSON.parse(productSpecs) : productSpecs;

    return {
        productCondition,
        productTypeId,
        productBrandId,
        productNameId,
        productCode,
        productDesc,
        quantity,
        productSpecs,
        DiscountPrice,
        colorOptions,
        price
    }
}