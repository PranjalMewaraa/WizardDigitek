module.exports = (obj) => {
    try {
        if (!obj) return null;
        let {
            id,
            name,
            description,
            logo_url,
            website_url,
            country,
            contact_email,
            contact_phone,
            social_media_links,
            activeFlag
        } = obj;
        return { 
            id,
            name,
            description,
            logo_url,
            website_url,
            country,
            contact_email,
            contact_phone,
            social_media_links,
            activeFlag
        };
    } catch (error) {
        throw error;
    }
};