const jwt = require("jsonwebtoken");
const parsedEnv = require("../config/parsedEnv");

const generateAdminToken = async (admin) => {
  return jwt.sign({ user: admin }, parsedEnv.adminSecretKey, {
    expiresIn: "50h",
  });
};

module.exports = { generateAdminToken };
