const jwt = require("jsonwebtoken");
const parsedEnv = require("../config/parsedEnv");


const verifyAdminToken = async (req, res, next) => {
  const token = req.header("token");

  if (!token) {
    return res.status(401).json({ error: "Access denied" });
  }

  try {
    const decoded = jwt.verify(token, parsedEnv.adminSecretKey);
    if (decoded) {
      req.admin = decoded.admin;
    } else {
      return res.status(403).json({ error: "Invalid user" });
    }
    next();
  } catch (error) {
    console.error(error);
    return res.status(403).json({ error: "Invalid token of admin" });
  }
};


module.exports = {
  verifyAdminToken,
};
