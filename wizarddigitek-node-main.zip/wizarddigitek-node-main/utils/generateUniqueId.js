const { customAlphabet } = require("nanoid");
const nanoid = customAlphabet("1234567890abcdefghijklmnopqrstuvwxyz", 15);
function generateUUID() {
  return nanoid();
}

module.exports = { generateUUID };
