"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class color extends Model{
        static associate(models) { }
    }

    color.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            variantId: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                allowNull: false,
            },
            colorOptions: {
                type: DataTypes.STRING(200),
                allowNull: false,
            },
            price:{
                type: DataTypes.BIGINT,
                allowNull: false
            },
            discountPrice: {
                type: DataTypes.BIGINT,
                allowNull: false,
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "color",
            tableName: "colors",
        }
    );
    return color;
}