"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class LandingHero extends Model {
        static associate(models) {}
    }

    LandingHero.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            landingPageId: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                allowNull: false,
            },
            bg: {
                type: DataTypes.STRING(100),
                allowNull: false,
            },

            text: {
                type: DataTypes.STRING(100),
                allowNull: false,
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "landingHero",
            tableName: "landingHeros",
        }
    );

    return LandingHero;
};
