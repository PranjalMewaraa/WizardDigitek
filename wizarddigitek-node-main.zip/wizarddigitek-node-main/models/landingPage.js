"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class landingPage extends Model {
        static associate(models) { }
    }

    landingPage.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            name: {
                type: DataTypes.STRING(100),
                allowNull: true,
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "landingPage",
            tableName: "landingPages",
        }
    );

    return landingPage;
};
