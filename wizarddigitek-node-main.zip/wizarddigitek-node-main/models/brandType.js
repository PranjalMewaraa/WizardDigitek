"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class brandType extends Model {
        static associate(models) { }
    }

    brandType.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            productBrandId: {
                type: DataTypes.UUID    
            },
            productTypeId: {
                type: DataTypes.UUID
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "brandType",
            tableName: "j_brandType",
        }
    );

    return brandType;
};
