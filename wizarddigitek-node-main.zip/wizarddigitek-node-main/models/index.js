"use strict";
let dotenv = require("dotenv").config();
let conf = dotenv.parsed;
const fs = require("fs");

const process = require("process");
const path = require("path");

const { Sequelize, DataTypes } = require("sequelize");

const basename = path.basename(__filename);
const db = {};

const env = process.env.NODE_ENV || "development";

const config = require(path.join(__dirname + "../../config/config.js"))[env];
let sequelize;

if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(
    config.database,
    config.username,
    config.password,
    config
  );
}

fs.readdirSync(__dirname).filter((file) => {
  return (
    file.indexOf(".") !== 0 &&
    file !== basename &&
    file.slice(-3) === ".js" &&
    file.indexOf(".test.js") === -1
  );
});


Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});
sequelize
  .authenticate()
  .then(() => {
    console.log("Connected to database......");
  })
  .catch((err) => {
    console.log("Error" + err);
  });

db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.user = require("./user")(sequelize, DataTypes);
db.landingPage = require("./landingPage")(sequelize, DataTypes);
db.landingHero = require("./landingHero")(sequelize, DataTypes);
db.adBanner = require("./adBanner")(sequelize, DataTypes);
db.product = require("./product")(sequelize, DataTypes);
db.color = require("./color")(sequelize, DataTypes);
db.variant = require("./variant")(sequelize, DataTypes);
db.brandType = require("./brandType")(sequelize, DataTypes);
db.productName = require("./productName")(sequelize, DataTypes)
db.adBanner = require("./adBanner")(sequelize, DataTypes);
db.attachments = require("./attachments")(sequelize, DataTypes);

db.productBrand = require("./productBrand")(sequelize, DataTypes);
db.productType = require("./productType")(sequelize, DataTypes);
db.productName = require("./productName")(sequelize, DataTypes);
db.landingHero.hasMany(db.attachments, {
  foreignKey: "identifierId",
  as: "attachment",
});

// db.productBrand.hasMany(db.productType, {
//   foreignKey: "brandId",
//   as: "category",
// });


db.landingPage.hasMany(db.landingHero, {
  foreignKey: "landingPageId",
  as: "landingHero",
});
db.landingHero.belongsTo(db.landingPage, { as: "landingPage" });

db.landingPage.hasOne(db.adBanner, {
  foreignKey: "landingPageId",
  as: "adBanner",
});
db.adBanner.belongsTo(db.landingPage, { as: "landingPage" });



db.variant.hasMany(db.color, { foreignKey: "variantId", as: "color" });
db.color.belongsTo(db.product, { foreignKey: "variantId" });


db.product.hasMany(db.variant, { foreignKey: "productId", as: "variant" });
db.variant.belongsTo(db.product, { foreignKey: "productId" });

db.product.hasOne(db.attachments, {
  foreignKey: "identifierId",
  as: "thumbnail",
});
db.product.hasMany(db.attachments, {
  foreignKey: "identifierId",
  as: "productImages",
});
db.adBanner.hasMany(db.attachments, {
  foreignKey: "identifierId",
  as: "adBannerAttachment",
});

// master table product brand is associated with product
db.product.belongsTo(db.productBrand, {
  foreignKey: "productBrandId",
  as: "productBrand",
});

// // master table productName Associated with product
db.product.belongsTo(db.productName, {
  foreignKey: "productNameId",
  as: "productName",
})

// // master table productType Associated with product
db.product.belongsTo(db.productType,{
    foreignKey: "productTypeId",
    as: "productType",
})

//many to many relationship between productBreand and productType

db.productBrand.belongsToMany(db.productType, {
  through: db.brandType,
  as: "productType",
});
db.productType.belongsToMany(db.productBrand, {
  through: db.brandType,
  as: "productBrand",
});




// db.productType.hasMany(db.product, { foreignKey: "productTypeId", as: "productTypes" });

db.productName.belongsTo(db.productBrand, { foreignKey: "productBrandId", as: "productBrand11"})
db.productName.belongsTo(db.productType, { foreignKey: "productTypeId", as: "productType11"})


module.exports = db;
