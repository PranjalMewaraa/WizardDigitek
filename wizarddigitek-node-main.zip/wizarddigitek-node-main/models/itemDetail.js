"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
 class itemDetail extends Model {
  static associate(models) {}
 }

 itemDetail.init(
  {
   id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
   },
   content: {
    type: DataTypes.TEXT,
    allowNull: false,
   },
   seoTitle: {
    type: DataTypes.STRING(255),
    allowNull: true,
   },
   seoDescription: {
    type: DataTypes.STRING(500),
    allowNull: true,
   },
   seoKeywords: {
    type: DataTypes.STRING(500),
    allowNull: true,
   },
   activeFlag: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: false,
   },
   createdAt: {
    allowNull: false,
    type: DataTypes.DATE,
   },
   updatedAt: {
    allowNull: false,
    type: DataTypes.DATE,
   },
  },
  {
   sequelize,
   modelName: "itemDetail",
   tableName: "wd_itemDetails",
  }
 );

 return itemDetail;
};
