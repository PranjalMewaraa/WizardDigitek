"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class variant extends Model{
        static associate(models) { }
    }

    variant.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            productId: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                allowNull: false,
            },
            variantTags: {
                type: DataTypes.STRING(10),
                allowNull: false,
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "variant",
            tableName: "variant",
        }
    );
    return variant;
}