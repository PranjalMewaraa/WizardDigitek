"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
 class attachment extends Model {
  static associate(models) {}
 }
 attachment.init(
  {
   id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
   },
   identifierId: { type: DataTypes.UUID, allowNull: false },
   name: {
    type: DataTypes.STRING(150),
    allowNull: false,
   },
   path: {
    type: DataTypes.STRING(150),
    allowNull: false,
   },
   documentType: {
    type: DataTypes.STRING(100),
    allowNull: true,
   },
   size: {
    type: DataTypes.INTEGER,
    allowNull: true,
   },
   mimeType: {
    type: DataTypes.STRING(50),
    allowNull: false,
   },
   activeFlag: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
   },
   createdAt: {
    allowNull: false,
    type: DataTypes.DATE,
   },
   updatedAt: {
    allowNull: false,
    type: DataTypes.DATE,
   },
  },
  {
   sequelize,
   modelName: "attachment",
   tableName: "attachments",
  }
 );

 return attachment;
};
