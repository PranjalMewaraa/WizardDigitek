"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class productType extends Model {
        static associate(models) { }
    }

    productType.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            name: {
                type: DataTypes.STRING(100),
                allowNull:false,
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "productType",
            tableName: "m_productTypes",
        }
    );

    return productType;
};