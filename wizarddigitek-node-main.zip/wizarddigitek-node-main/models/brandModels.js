"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class brandModel extends Model {
        static associate(models) { }
    }

    brandModel.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            productNameId: {
                type: DataTypes.UUID
            },
            productBrandId: {
                type: DataTypes.UUID    
            },
            productTypeId: {
                type: DataTypes.UUID
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "brandModel",
            tableName: "m_brandModel",
        }
    );

    return brandModel;
};
