    "use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class Product extends Model{
        static associate(models) { }
    }

    Product.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            productCondition: {
                type: DataTypes.STRING(100),
                allowNull: false,
            },
            productTypeId: {
                type: DataTypes.UUID,
                allowNull:false,
            },
            productBrandId: {
                type: DataTypes.UUID,
                allowNull:false,
            },
            productNameId: {
                type: DataTypes.UUID,
                allowNull: false,
            },
            productCode: {
                type: DataTypes.STRING(100),
                allowNull: false,
            },
            productDesc: {
                type: DataTypes.STRING(5000),
                allowNull: false,
            },
            quantity: {
                type: DataTypes.BIGINT,
                allowNull: false,
            },
            productSpecs: {
                type: DataTypes.ARRAY(DataTypes.STRING(300)),
                allowNull: false,
            },
            
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "product",
            tableName: "products",
        }
    );
    return Product;
}