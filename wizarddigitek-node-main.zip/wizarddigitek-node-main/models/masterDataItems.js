"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
 class masterDataItem extends Model {
  static associate(models) {}
 }
 masterDataItem.init(
  {
   id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
   },
   heading: { type: DataTypes.STRING(500), allowNull: true },
   type: { type: DataTypes.STRING(150), allowNull: true },
   link: { type: DataTypes.STRING(255), allowNull: true },
   redirectUrl: { type: DataTypes.STRING(250), allowNull: true },
   description: { type: DataTypes.STRING(2500), allowNull: true },
   shortDesc: { type: DataTypes.STRING(1500), allowNull: true },
   sequence: { type: DataTypes.INTEGER, allowNull: true },
   activeFlag: { type: DataTypes.BOOLEAN, defaultValue: false },
   createdAt: { allowNull: false, type: DataTypes.DATE },
   updatedAt: { allowNull: false, type: DataTypes.DATE },
  },
  {
   sequelize,
   tableName: "wd_masterDataItems",
   modelName: "masterDataItem",
  }
 );
 return masterDataItem;
};
