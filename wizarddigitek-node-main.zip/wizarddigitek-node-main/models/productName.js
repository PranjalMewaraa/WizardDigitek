"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class productName extends Model {
        static associate(models) { }
    }

    productName.init(
        {
            id: {
                type: DataTypes.UUID,
                defaultValue: DataTypes.UUIDV4,
                primaryKey: true,
            },
            name: {
                type: DataTypes.STRING(5000),
                allowNull:false,
            },
            productBrandId: {
                type: DataTypes.UUID,
                allowNull: false,
            },
            productTypeId: {
                type: DataTypes.UUID,
                allowNull: false,
            },
            createdAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
            updatedAt: {
                allowNull: false,
                type: DataTypes.DATE,
            },
        },
        {
            sequelize,
            modelName: "productName",
            tableName: "m_productName",
        }
    );

    return productName;
};
