"use strict";
const { Model } = require("sequelize");
const utils = require("../utils/generateUniqueId");

module.exports = (sequelize, DataTypes) => {
  class user extends Model {
    static associate(models) {}
  }

  user.init(
    {
      id: {
        type: DataTypes.UUID,
        allowNull: false,
        primaryKey: true,
        defaultValue: DataTypes.UUIDV4,
      },
      name: {
        type: DataTypes.STRING(50),
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING(30),
        allowNull: false,
      },
      password: {
        type: DataTypes.STRING(30),
        allowNull: false,
      },
      role: {
        type: DataTypes.STRING(30),
        allowNull: true,
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE,
      },
    },
    {
      sequelize,
      modelName: "user",
      tableName: "users",
    }
  );

  return user;
};
