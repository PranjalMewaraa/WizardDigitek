'use strict';
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('attachments',
            {
                id: {
                    type: Sequelize.UUID,
                    defaultValue: Sequelize.UUIDV4,
                    primaryKey: true,
                   },
                   identifierId: { type: Sequelize.UUID, allowNull: false },
                   name: {
                    type: Sequelize.STRING(150),
                    allowNull: false,
                   },
                   path: {
                    type: Sequelize.STRING(150),
                    allowNull: false,
                   },
                   documentType: {
                    type: Sequelize.STRING(100),
                    allowNull: true,
                   },
                   size: {
                    type: Sequelize.INTEGER,
                    allowNull: true,
                   },
                   mimeType: {
                    type: Sequelize.STRING(50),
                    allowNull: false,
                   },
                   activeFlag: {
                    type: Sequelize.BOOLEAN,
                    allowNull: false,
                    defaultValue: true,
                   },
                   createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                   },
                   updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                   },

            });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('attachments');
    }
};