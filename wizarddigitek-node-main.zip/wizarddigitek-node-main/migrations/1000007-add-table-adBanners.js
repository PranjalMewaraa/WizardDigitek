'use strict';
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('adBanners',
            {
                id: {
                    type: Sequelize.UUID,
                    allowNull: false,
                    primaryKey: true,
                    defaultValue: Sequelize.UUIDV4,
                },
                landingPageId: {
                    type: Sequelize.UUID,
                    allowNull: false,
                    defaultValue: Sequelize.UUIDV4,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },

            });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('adBanners');
    }
};