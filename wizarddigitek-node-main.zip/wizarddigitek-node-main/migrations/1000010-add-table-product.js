'use strict';
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('products',
            {
                id: {
                    type: Sequelize.UUID,
                    allowNull: false,
                    primaryKey: true,
                    defaultValue: Sequelize.UUIDV4,
                },
                productCondition: {
                    type: Sequelize.STRING(100),
                    allowNull: true,
                },
                productTypeId: {
                    type: Sequelize.UUID,
                    allowNull: false,
                },
                productBrandId: {
                    type: Sequelize.UUID,
                    allowNull: false,
                },
                productNameId: {
                    type: Sequelize.UUID,
                    allowNull: false,
                },
                productCode: {
                    type: Sequelize.STRING(100),
                    allowNull: false,
                },
                productDesc: {
                    type: Sequelize.STRING(5000),
                    allowNull: false,
                },
                quantity: {
                    type: Sequelize.BIGINT,
                    allowNull: false,
                },
                productSpecs:{
                    type: Sequelize.ARRAY(Sequelize.STRING(300)),
                    allowNull: false,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },

            });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('products');
    }
};