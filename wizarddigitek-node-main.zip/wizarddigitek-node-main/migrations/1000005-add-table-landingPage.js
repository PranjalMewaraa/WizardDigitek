'use strict';
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('landingPages',
            {
                id: {
                    type: Sequelize.UUID,
                    allowNull: false,
                    primaryKey: true,
                    defaultValue: Sequelize.UUIDV4,
                },
                name: {
                    type: Sequelize.STRING(100),
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },

            });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('landingPages');
    }
};