"use strict";
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.addColumn("products", "productNameId", {
            type: Sequelize.UUID,
            allowNull: true,
        });
    },
};
