'use strict';
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.createTable('colors',
            {
                id: {
                    type: Sequelize.UUID,
                    allowNull: false,
                    primaryKey: true,
                    defaultValue: Sequelize.UUIDV4,
                },
                variantId:{
                    type: Sequelize.UUID,
                    allowNull: false,
                },
                colorOptions: {
                    type: Sequelize.STRING(200),
                    allowNull: false,
                },
                price:{
                    type: Sequelize.BIGINT
                },
                discountPrice:{
                    type: Sequelize.BIGINT,
                    allowNull: true,
                },
                createdAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },
                updatedAt: {
                    allowNull: false,
                    type: Sequelize.DATE,
                },

            });
    },
    async down(queryInterface, Sequelize) {
        await queryInterface.dropTable('colors');
    }
};