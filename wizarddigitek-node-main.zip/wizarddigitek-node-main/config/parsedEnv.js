let path = require("path");
const fs = require("fs");

let fixture = path.join(__dirname, "../.env");
let dotenv = require("dotenv").config({ path: fixture });
let config = dotenv.parsed;

module.exports = {
    adminSecretKey: process.env.ADMIN_SECRET_KEY
        ? process.env.ADMIN_SECRET_KEY
        : config.ADMIN_SECRET_KEY,

};
