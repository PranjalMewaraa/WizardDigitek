let db = require("../models")
let model = require("../modelHelpers");
const { resDocCreated, resServerError, resValidationError, resFound, resNotFound, resDocUpdated, resDocDeleted, resAlreadyExists } = require("../utils/response");

const createCategory = async(req,res) =>{
    try {
        let requestBody = model.category(req.body)
        if(!requestBody.name){
            return resValidationError(res,"Name Should be There")
        }
        let existingRecord = await db.category.findOne({
            where: {name:{
                [db.Sequelize.Op.iLike]: requestBody.name}}
        })
        if(existingRecord){
            return resAlreadyExists(res,"Category with this name Already Exists")
        }
        let category = await db.category.create(requestBody);
        return resDocCreated(res,category)
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}

const getAllCategories = async(req,res)=>{
    try {
        let categories = await db.category.findAll()
        return resFound(res,categories)
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


const  getCategoryByName = async(req,res)=>{
    try {
        let name = req.query.name
        if(!name){
            return resValidationError(res,"Name of Category is required")
        }
        let category = await db.category.findOne({
            where:{name:{
                [db.Sequelize.Op.iLike]: name}}
        })
        return resFound(res,category)
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


const updateCategory = async(req,res) =>{
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.category.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No Category exists with this Id")
        }
        let obj = req.body
        let requestBody = model.category(obj);
        if (
            obj.name === existingRecord.name ||
            obj.displayName === existingRecord.displayName ||
            obj.description === existingRecord.description
        ) {
            return resValidationError(res, {message:"Please give the new value",existingRecord});
        }
        let category = await db.category.update(requestBody,{
            where:{id:id}
        });
        return resDocUpdated(res,{category, existingRecord})
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


const deleteCategory = async(req,res) =>{
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.category.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No Category exists with this Id")
        }
        let deleteCategory = await db.category.destroy({
            where:{id:id}
        });
        return resDocDeleted(res,{message : "Successfully Deleted the Brand", deleteCategory})
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


module.exports = {createCategory, getAllCategories, getCategoryByName, updateCategory, deleteCategory}