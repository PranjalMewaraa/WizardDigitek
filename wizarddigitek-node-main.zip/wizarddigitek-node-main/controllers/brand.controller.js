const db = require("../models");
let model = require("../modelHelpers");
const { resDocCreated, resServerError, resValidationError, resFound, resNotFound, resDocUpdated, resDocDeleted } = require("../utils/response");

const createBrand = async(req,res) =>{
    try {
        let requestBody = model.brand(req.body)
        if(!requestBody.name){
            return resValidationError(res,"Name Should be There")
        }
        let brand = await db.brand.create(requestBody);
        return resDocCreated(res,brand)
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}

const getAllBrands = async(req,res)=>{
    try {
        let brands = await db.brand.findAll()
        return resFound(res,brands)
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


const  getBrandByName = async(req,res)=>{
    try {
        let name = req.query.name
        if(!name){
            return resValidationError(res,"Name of Brand is required")
        }
        let brand = await db.brand.findOne({
            where:{name:{
                [db.Sequelize.Op.iLike]: name}}
        })
        return resFound(res,brand)
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


const updateBrand = async(req,res) =>{
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.brand.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No Brand exists with this Id")
        }
        let obj = req.body
        let requestBody = model.brand(obj);
        if (
            obj.name === existingRecord.name ||
            obj.description === existingRecord.description ||
            obj.logo_url === existingRecord.logo_url ||
            obj.website_url === existingRecord.website_url ||
            obj.country === existingRecord.country ||
            obj.contact_email === existingRecord.contact_email ||
            obj.social_media_links === existingRecord.social_media_links 
        ) {
            return resValidationError(res, "No changes were made");
        }
        let brand = await db.brand.update(requestBody,{
            where:{id:id}
        });
        return resDocUpdated(res,brand)
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


const deleteBrand = async(req,res) =>{
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.brand.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No Brand exists with this Id")
        }
        await db.brand.destroy({
            where:{id:id}
        });
        return resDocDeleted(res,"Successfully Deleted the Brand")
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
}


module.exports = {createBrand, getAllBrands, getBrandByName, updateBrand, deleteBrand}