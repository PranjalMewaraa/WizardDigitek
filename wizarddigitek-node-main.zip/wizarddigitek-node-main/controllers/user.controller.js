const { validationResult } = require("express-validator");
const { generateAdminToken } = require("../utils/generateToken");
const db = require("../models");
const {
  resServerError,
  resFound,
  resDocCreated,
  resDocUpdated,
  resDocDeleted,
  resNotFound,
} = require("../utils/response");

//method for creating the user Part
// const signUpUser = async (req, res) => {
//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       return resPasswordMismatch(res, "please enter a valid password");
//     }
//     const requestBody = req.body;
//     const doc = await db.user.create(requestBody);

//     return resDocCreated(res, doc);
//   } catch (error) {
//     console.error(error);
//     return resServerError(res, error);
//   }
// };
// method for logging user
let loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const doc = await db.user.findOne({ where: { email, password } });
    if (!doc) {
      return resNotFound(res, "Invalid username or password");
    }
    const token = await generateAdminToken(doc);
    return resFound(res, token);
  } catch (error) {
    console.error(error);
    return resServerError(res, error);
  }
};

const getUserbyId = async (req, res) => {
  try {
    let docs = await db.user.findOne({
      where: { id: req.query.id },
    });
    return resFound(res, docs);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};

const getAllUsers = async (req, res) => {
  try {
    let docs = await db.user.findAll({});
    return resFound(res, docs);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};

const updateUserById = async (req, res) => {
  try {
    const userId = req.query.id;
    let user = await db.user.findOne({
      where: { id: userId },
    });
    if (!user) {
      return resNotFound(res, "user not found");
    }
    user = await user.update(req.body);
    return resDocUpdated(res, user);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};

const deleteUserById = async (req, res) => {
  try {
    const userId = req.query.id;
    let user = await db.user.findOne({
      where: { id: userId },
    });
    if (!user) {
      return resNotFound(res, "user not found");
    }
    user = await user.destroy(req.body);

    return resDocDeleted(res, user);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};
module.exports = {
  //   signUpUser,
  loginUser,
  getUserbyId,
  getAllUsers,
  updateUserById,
  deleteUserById,
};
