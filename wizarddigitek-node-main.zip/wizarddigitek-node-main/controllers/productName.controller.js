const db = require("../models");
const { Op } = require("sequelize");

const { resDocCreated, resServerError, resFound,resNotFound } = require("../utils/response");

const createProductName = async (req, res) => {
    try{
        const requestbody = req.body;
        const createdData = await db.productName.create(requestbody);
        return resDocCreated(res, createdData);
    } catch(error){
        return resServerError(res, error);
    }
}

const getAllProductName = async (req, res) => {
    try {
      let docs = await db.productName.findAll({
        include: [{
          model: db.productType,
          as: 'productType11',
        },
        {
            model: db.productBrand,
            as: 'productBrand11'
        }
    ]
      });
      return resFound(res, docs);
    } catch (error) {
      console.log(error);
      return resServerError(res, error);
    }
  };

const getProductNameByBrandAndCateoryId = async(req,res)=>{
    try{
        const docs = await db.productName.findAll({

            include: [{
                model: db.productType,
                as: 'productType11',
              },
              {
                  model: db.productBrand,
                  as: 'productBrand11'
              }
            ],
            where:{
                productBrandId:req.query.productBrandId,
                productTypeId:req.query.productTypeId
                // [Op.and]:[
                //     {productBrandId:req.query.productBrandId},
                //     {productNameId:req.query.productNameId}
                // ]
            }
        })
        return resFound(res,docs)
    }catch(err){
        console.log(console.log(err))
        return resServerError(res,err)
    }
}

const getProductNameId = async (req, res) => {
    try{
    const docs = await db.productName.findOne({
        where: { id: req.query.id },
        include: [{
            model: db.productType,
            as: 'productType11',
          },
          {
              model: db.productBrand,
              as: 'productBrand11'
          }
      ],
    });
    return resFound(res, docs);
} catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};
const updateProductNameById = async (req, res) => {
    try {
        const productNameId = req.query.id;
        let productName = await db.productName.findOne({
            where: { id: productNameId },
        });
        if (!productName) {
            return resNotFound(res, "productName with this id not found");
        }
        productName = await productName.update(req.body);
        return resDocUpdated(res, productName);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};

const deleteProductNameById = async (req, res) => {
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.productName.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No productType exists with this Id")
        }
        let deleteproductName = await db.productName.destroy({
            where:{id:id}
        });
        return res.json({ message: "productType deleted", deleteproductName: deleteproductName});
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};

module.exports = {
    createProductName,
    getAllProductName,
    getProductNameId,
    updateProductNameById,
    deleteProductNameById,
    getProductNameByBrandAndCateoryId
}