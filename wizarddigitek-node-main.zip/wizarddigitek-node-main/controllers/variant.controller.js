const db = require("../models");
const {
    resServerError,
    resFound,
    resDocCreated,
    resDocUpdated,
    resDocDeleted,
    resNotFound,
} = require("../utils/response");

const createvariant = async (req, res) => {
    try {
        const requestBody = req.body;
        const doc = await db.variant.create(requestBody);

        return resDocCreated(res, doc);
    }
    catch (error) {
        console.error(error);
        return resServerError(res, error);
    }
};


const getvariantbyId = async(req, res) => {
    try {
        let docs = await db.variant.findOne({
            include: [{
                model: db.color,
                as: "color"
            }],
            where: { id: req.query.id },
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};


const getAllvariants = async (req, res) => {
    try {
        let docs = await db.variant.findAll({
            include: [{
                model: db.color,
                as: "color"
            }],
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};

const updatevariantById = async (req, res) => {
    try {
        const variantId = req.query.id;
        let variant = await db.variant.findOne({
            where: { id: variantId },
        });
        if (!variant) {
            return resNotFound(res, "variant with this id not found");
        }
        variant = await variant.update(req.body);
        return resDocUpdated(res, variant);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};

const deletevariantById = async (req, res) => {
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.variant.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No variant exists with this Id")
        }
        let deletevariant = await db.variant.destroy({
            where:{id:id}
        });
        return res.json({ message: "variant deleted", deletedvariant: deletevariant});
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};
module.exports = {
    createvariant,
    getvariantbyId,
    getAllvariants,
    updatevariantById,
    deletevariantById,
};
