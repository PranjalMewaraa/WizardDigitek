const db = require("../models");
const {
    resServerError,
    resFound,
    resDocCreated,
    resDocUpdated,
    resDocDeleted,
    resNotFound,
} = require("../utils/response");

const createAdBanner = async (req, res) => {
    try {
        const requestBody = req.body;
    if(!requestBody){
        
    }
        const doc = await db.adBanner.create(requestBody);
        if(doc && req.files && req.files.length > 0) {
            for(let file of req.files) {
            let attBody={
                identifierId:doc.id,
                name:file.filename,
                size:file.size,
                mimeType:file.mimetype,
                path:file.path,
                documentType:'adBanner'
            };
            console.log('------------------->',req.files)
            await db.attachments.create(attBody);
        }
    }
        return resDocCreated(res, doc);
    } catch (error) {
        console.error(error);
        return resServerError(res, error);
    }
};


const getAdBannerbyId = async (req, res) => {
    try {
        let docs = await db.adBanner.findOne({
            include:[{
                model:db.attachments,
                as:'adBannerAttachment'
            }],
            where: { id: req.query.id },
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};


const getAllAdBanners = async (req, res) => {
    try {
        let docs = await db.adBanner.findAll({
            include:{
                model:db.attachments,
                as:'adBannerAttachment'
            },
        });
        return resFound(res, docs);
    }catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};

const updateAdBannerById = async (req, res) => {
    try {
        const adBannerId = req.query.id;
        let adBanner = await db.adBanner.findOne({
            include: [{
                model: db.attachments,
                as: 'adBannerAttachment'
            }],
            where: { id: adBannerId },
        });

        if (!adBanner) {
            return resNotFound(res, "the provided adBannerId is not found");
        }

        await adBanner.update(req.body);
        if (req.files && req.files.length > 0) {
            await db.attachments.destroy({
                where: {
                    identifierId: adBanner.id,
                    documentType: 'adBanner'
                }
            });
            for (let file of req.files) {
                let attBody = {
                    identifierId: adBanner.id,
                    name: file.filename,
                    size: file.size,
                    mimeType: file.mimetype,
                    path: file.path,
                    documentType: 'adBanner'
                };
                await db.attachments.create(attBody);
            }
        }
        adBanner = await db.adBanner.findOne({
            include: [{
                model: db.attachments,
                as: 'adBannerAttachment'
            }],
            where: { id: adBannerId },
        });

        return resDocUpdated(res, adBanner);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};

const deleteAdBannerById = async (req, res) => {
    try {
        const adBannerId = req.query.id;
        let adBanner = await db.adBanner.findOne({
            where: { id: adBannerId },
        });
        if (!adBanner) {
            return resNotFound(res, "adBanner not found");
        }
        adBanner = await adBanner.destroy(req.body);

        return resDocDeleted(res, adBanner);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};
module.exports = {
    createAdBanner,
    getAdBannerbyId,
    getAllAdBanners,
    updateAdBannerById,
    deleteAdBannerById,
};
