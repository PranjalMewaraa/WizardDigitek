const db = require("../models");
const {
  resServerError,
  resFound,
  resDocCreated,
  resDocUpdated,
  resDocDeleted,
  resNotFound,
} = require("../utils/response");

const createProductBrand = async (req, res) => {
  try {
    const { categories } = req.body;

    const { name } = req.body;
    const productType = await db.productType.findAll({})
    // console.log(productType)

    const matchingProductTypes = productType.filter(productType =>
      categories.some(category => category.productTypeId === productType.id)
    );

    // console.log(matchingProductTypes)

    if (!categories || categories.length === 0) {
      console.log("brand should have at least 1 category");
      return res.status(400).json({ error: "Brand should have at least 1 category" });
    }

    const doc = await db.productBrand.create({ name });

    if (
      doc &&
      matchingProductTypes &&
      Array.isArray(matchingProductTypes) &&
      matchingProductTypes.length > 0
    ) {
      const categoriesData = matchingProductTypes.map((x) => {

        return db.brandType.create({
          productBrandId: doc.id,
          productTypeId: x.id,
        });
      },
      )
      await Promise.all(categoriesData)
    }
    else {
      return res.json({ error: "Provided category does not exist" });
    }


    return resDocCreated(res, doc);
  } catch (error) {
    console.error(error);
    return resServerError(res, error);
  }
};


const getProductBrandbyId = async (req, res) => {
  try {
    let docs = await db.productBrand.findOne({
      where: { id: req.query.id },
      include: [{
        model: db.productType,
        as: 'productType',
        attributes: ['id','name']
      }]
    });
    return resFound(res, docs);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};

const getAllProductBrands = async (req, res) => {
  try {
    let docs = await db.productBrand.findAll({
      include: [{
        model: db.productType,
        as: 'productType',
        attributes: ['id']
      }]
    });
    return resFound(res, docs);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};

const updateProductBrandById = async (req, res) => {
  try {
    const productBrandId = req.query.id;
    let productBrand = await db.productBrand.findOne({
      where: { id: productBrandId },
    });
    if (!productBrand) {
      return resNotFound(res, "productBrand with this id not found");
    }
    productBrand = await productBrand.update(req.body);
    return resDocUpdated(res, productBrand);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};

const deleteProductBrandById = async (req, res) => {
  try {
    let id = req.query.id;
    if (!id) {
      return resValidationError(res, "Please choose the id");
    }
    let existingRecord = await db.productBrand.findOne({ where: { id } });
    if (!existingRecord) {
      return resNotFound(res, "No productBrand exists with this Id");
    }
    let deleteproductBrand = await db.productBrand.destroy({
      where: { id: id },
    });
    return res.json({
      message: "productBrand deleted",
      deletedproductBrand: deleteproductBrand,
    });
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};
module.exports = {
  createProductBrand,
  getProductBrandbyId,
  getAllProductBrands,
  updateProductBrandById,
  deleteProductBrandById,
};
