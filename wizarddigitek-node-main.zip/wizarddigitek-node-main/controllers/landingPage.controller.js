const db = require("../models");
const {
    resServerError,
    resFound,
    resDocCreated,
    resDocUpdated,
    resDocDeleted,
    resNotFound,
} = require("../utils/response");

const createLandingPage = async (req, res) => {
    try {
        const requestBody = req.body;
        const doc = await db.landingPage.create(requestBody);

        return resDocCreated(res, doc);
    }
    catch (error) {
        console.error(error);
        return resServerError(res, error);
    }
};


const getLandingPagebyId = async (req, res) => {
    try {
        let docs = await db.landingPage.findOne({
            include:[{
                model:db.landingHero,
                as:'landingHero',
                include:{
                    model:db.attachments,
                    as:'attachment',
                }
            },
            {
                model:db.adBanner,
                as:'adBanner',
                include:{
                    model:db.attachments,
                    as:'adBannerAttachment',
                }
            },
        ],
            where: { id: req.query.id },
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};


const getAllLandingPages = async (req, res) => {
    try {
        let docs = await db.landingPage.findAll({
            include:[{
                model:db.landingHero,
                as:'landingHero',
                include:{
                    model:db.attachments,
                    as:'attachment',
                }
            },
            {
                model:db.adBanner,
                as:'adBanner',
                include:{
                    model:db.attachments,
                    as:'adBannerAttachment'
                }
            },
        ]
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};

const updateLandingPageById = async (req, res) => {
    try {
        const landingPageId = req.query.id;
        let landingPage = await db.landingPage.findOne({
            include:[{
                model:db.landingHero,
                as:'landingHero'
            },
            {
                model:db.adBanner,
                as:'adBanner'
            },
        ],
            where: { id: landingPageId },
        });
        if (!landingPage) {
            return resNotFound(res, "landingPage not found");
        }
        landingPage = await landingPage.update(req.body);
        return resDocUpdated(res, landingPage);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};

const deleteLandingPageById = async (req, res) => {
    try {
        const landingPageId = req.query.id;
        let landingPage = await db.landingPage.findOne({
            where: { id: landingPageId },
        });
        if (!landingPage) {
            return resNotFound(res, "landingPage not found");
        }
        landingPage = await landingPage.destroy(req.body);

        return resDocDeleted(res, landingPage);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};
module.exports = {
    createLandingPage,
    getLandingPagebyId,
    getAllLandingPages,
    updateLandingPageById,
    deleteLandingPageById,
};
