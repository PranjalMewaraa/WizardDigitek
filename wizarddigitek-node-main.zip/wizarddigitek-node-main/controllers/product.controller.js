let db = require("../models");
let model = require("../modelHelpers");
const {
  resDocCreated,
  resServerError,
  resValidationError,
  resFound,
  resNotFound,
  resDocUpdated,
  resDocDeleted,
  resAlreadyExists,
} = require("../utils/response");
const { Op, where, json } = require("sequelize");
const modelHelper = require("../modelHelpers");
const ITEMS_PER_PAGE = 8;

const createproduct = async (req, res) => {
  try {
    let attachment = [];
    const requestBody = req.body;
    let finalBody = modelHelper.product(requestBody);
    console.log(finalBody);
    const doc = await db.product.create(finalBody);
    if (!requestBody.variants || requestBody.variants.length === 0) {
      return resValidationError(
        res,
        "Variants and colors are required to create a product."
      );
    }
    // console.log(requestBody.variants.variantTags)
    if (doc && requestBody.variants && requestBody.variants.length > 0) {
      for (const variantData of requestBody.variants) {
        let variant = JSON.parse(variantData);
        // console.log("variant-------------------->", variant);
        const variantDoc = await db.variant.create({
          productId: doc?.id,
          variantTags: variant.variant,
        });
        if (variant.colors) {
          for (const colorData of variant.colors) {
            console.log("--------------------------->", colorData)
            await db.color.create({
              variantId: variantDoc.id,
              colorOptions: colorData.colorName,
              price: colorData.price,
              discountPrice: colorData.discountPrice,
            });
          }
        } else {
          return resValidationError(
            res,
            "Colors are required to create a product."
          );
        }
      }
    }
    console.log(req.files);
    if (
      doc &&
      req.files &&
      req.files.thumbnail &&
      req.files.thumbnail.length > 0
    ) {
      for (let file of req.files.thumbnail) {
        attachment.push(
          db.attachments.create({
            identifierId: doc.id,
            name: file.filename,
            size: file.size,
            mimeType: file.mimetype,
            path: file.path,
            documentType: "thumbnail",
          })
        );
      }
    } else {
      return resValidationError(
        res,
        "thumbnail is required to create a product."
      );
    }
    if (
      doc &&
      req.files &&
      req.files.productImage &&
      req.files.productImage.length > 0
    ) {
      for (let file of req.files.productImage) {
        attachment.push(
          db.attachments.create({
            identifierId: doc.id,
            name: file.filename,
            size: file.size,
            mimeType: file.mimetype,
            path: file.path,
            documentType: "productImage",
          })
        );
      }
    } else {
      return resValidationError(
        res,
        "product images is required to create a product."
      );
    }
    if (attachment.length > 0) await Promise.all(attachment);
    console.log("--------------------------->", req.files.thumbnail);
    console.log("--------------------------->", req.files.productImage);
    return resDocCreated(res, doc);
  } catch (error) {
    console.error(error);
    return resServerError(res, error);
  }
};

const getAllproduct = async (req, res) => {
  try {
    const page = +req.query.page || 1;
    const { searchKeyword } = req.query || {};
    const { productBrandId } = req.query || {};
    const { productTypeId } = req.query || {};
    const { maxPrice } = req.query || {};
    const { minPrice } = req.query || {};

    let whereCondition = {};
    let whereCondition1 = {};
    if (productTypeId) {
      whereCondition.productTypeId = productTypeId;
    }
    if (productBrandId) {
      whereCondition.productBrandId = productBrandId;
    }

    if (searchKeyword) {
      whereCondition = { productName: { [Op.iLike]: `%${searchKeyword}%` } };
    }
    if (minPrice && maxPrice) {
      whereCondition1 = {
        price: {
          [Op.between]: [minPrice, maxPrice],
        },
      };
    }

    let { rows, count } = await db.product.findAndCountAll({
      where: whereCondition,
      offset: (page - 1) * ITEMS_PER_PAGE,
      limit: ITEMS_PER_PAGE,
      order: [["createdAt", "DESC"]],
      distinct: true,
      include: [
        {
          model: db.productBrand,
          as: "productBrand",
        },
        {
          model: db.productType,
          as: "productType",
        },
        {
          model: db.productName,
          as: "productName",
        },
        {
          model: db.variant,
          required: false,
          as: "variant",
          include: [
            {
              model: db.color,
              required: false,
              as: "color",
              where: whereCondition1,
              required: true,
            },
          ],
        },
        {
          model: db.attachments,
          required: false,
          as: "thumbnail",
          where: { documentType: "thumbnail" },
        },
        {
          model: db.attachments,
          required: false,
          as: "productImages",
          where: { documentType: "productImage" },
        },
      ],
    });

    return resFound(res, { rows, count });
  } catch (error) {
    console.log(error);
    return resServerError(error);
  }
};

const getproductById = async (req, res) => {
  try {
    let docs = await db.product.findOne({
      include: [
        {
          model: db.productBrand,
          as: "productBrand",
        },
        {
          model: db.productType,
          as: "productType",
        },
        {
          model: db.productName,
          as: "productName",
        },
        {
          model: db.variant,
          as: "variant",
          include: [
            {
              model: db.color,
              as: "color",
            },
          ],
        },
        {
          model: db.attachments,
          as: "thumbnail",
          where: { documentType: "thumbnail" },
        },
        {
          model: db.attachments,
          as: "productImages",
          where: { documentType: "productImage" },
        },
      ],
      where: { id: req.query.id },
    });
    if (!docs) {
      return resNotFound(res, "product with this Id not found");
    }
    console.log("------------------------>", docs);
    return resFound(res, docs);
  } catch (error) {
    console.error(error);
    return resServerError(res, error);
  }
};

const updateproduct = async (req, res) => {
  try {
    const productId = req.query.id;
    let product = await db.product.findOne({
      where: { id: productId },
    });
    if (!product) {
      return resNotFound(res, "product not found");
    }
    product = await product.update(req.body);
    return resDocUpdated(res, product);
  } catch (error) {
    console.log(error);
    return resServerError(res, error);
  }
};

const deleteproduct = async (req, res) => {
  try {
    let id = req.query.id;
    if (!id) {
      return resValidationError(res, "Please choose the id");
    }
    let existingRecord = await db.product.findOne({ where: { id } });
    if (!existingRecord) {
      return resNotFound(res, "No product exists with this Id");
    }
    let deleteproduct = await db.product.destroy({
      where: { id: id },
    });
    return resDocDeleted(res, {
      message: "Successfully Deleted the Brand",
      deleteproduct,
    });
  } catch (error) {
    console.log(error);
    return resServerError(error);
  }
};

module.exports = {
  createproduct,
  getAllproduct,
  getproductById,
  updateproduct,
  deleteproduct,
};
