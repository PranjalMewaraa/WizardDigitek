const db = require("../models");
const {
    resServerError,
    resFound,
    resDocCreated,
    resDocUpdated,
    resDocDeleted,
    resNotFound,
} = require("../utils/response");

const createLandingHero = async (req, res) => {
    try {
        const requestBody = req.body; 
        // console.log(req.file); 

        const doc = await db.landingHero.create(requestBody);
        if(doc && req.files && req.files.length>0){
            for(let file of req.files){
            let attBody={
                identifierId:doc.id,
                name:file.filename,
                size:file.size,
                mimeType:file.mimetype,
                path:file.path,
                documentType:'heroImage'
            };
            await db.attachments.create(attBody);
        }
    }
        return resDocCreated(res, doc);
    }
    catch (error) {
        console.error(error);
        return resServerError(res, error);
    }
};


const getLandingHerobyId = async (req, res) => {
    try {
        let docs = await db.landingHero.findOne({
            include:{
                model:db.attachments,
                as:'attachment'
            },
            where: { id: req.query.id },
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};


const getAllLandingHeros = async (req, res) => {
    try {
        let docs = await db.landingHero.findAll({
            include: [{
                model: db.attachments,
                as: 'attachment'
            }]
        });
        return resFound(res, docs);
    }catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};

const updateLandingHeroById = async (req, res) => {
    try {
        const landingHeroId = req.query.id;
        let landingHero = await db.landingHero.findOne({
            include: [{
                model: db.attachments,
                as: 'attachment'
            }],
            where: { id: landingHeroId },
        });

        if (!landingHero) {
            return resNotFound(res, "landingHero not found");
        }


        await landingHero.update(req.body);


        if (req.files && req.files.length > 0) {

            await db.attachments.destroy({
                where: {
                    identifierId: landingHero.id,
                    documentType: 'heroImage'
                }
            });

            for (let file of req.files) {
                let attBody = {
                    identifierId: landingHero.id,
                    name: file.filename,
                    size: file.size,
                    mimeType: file.mimetype,
                    path: file.path,
                    documentType: 'heroImage'
                };
                await db.attachments.create(attBody);
            }
        }

        landingHero = await db.landingHero.findOne({
            include: [{
                model: db.attachments,
                as: 'attachment'
            }],
            where: { id: landingHeroId },
        });

        return resDocUpdated(res, landingHero);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};


const deleteLandingHeroById = async (req, res) => {
    try {
        const landingHeroId = req.query.id;
        let landingHero = await db.landingHero.findOne({
            where: { id: landingHeroId },
        });
        if (!landingHero) {
            return resNotFound(res, "landingHero not found");
        }
        landingHero = await landingHero.destroy(req.body);

        return resDocDeleted(res, landingHero);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};
module.exports = {
    createLandingHero,
    getLandingHerobyId,
    getAllLandingHeros,
    updateLandingHeroById,
    deleteLandingHeroById,
};
