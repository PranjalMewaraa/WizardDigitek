const db = require("../models");
const {
    resServerError,
    resFound,
    resDocCreated,
    resDocUpdated,
    resDocDeleted,
    resNotFound,
} = require("../utils/response");

const createcolor = async (req, res) => {
    try {
        let attachment = [];
        const requestBody = req.body;
        const doc = await db.color.create(requestBody);
        if (doc && req.files && req.files.length > 0) {
            for (let file of req.files) {
                attachment.push(db.attachments.create({
                    identifierId: doc.id,
                    name: file.filename,
                    size: file.size,
                    mimeType: file.mimetype,
                    path: file.path
                }))
            }
        }
        if (attachment.length > 0) await Promise.all(attachment);
        return resDocCreated(res, doc);
    }
    catch (error) {
        console.error(error);
        return resServerError(res, error);
    }
}


const getcolorbyId = async(req, res) => {
    try {
        let docs = await db.color.findOne({
            where: { id: req.query.id },
        });
        return resFound(res, docs);
    } catch(error) {
        throw error;
    }
};


const getAllcolors = async (req, res) => {
    try {
        let docs = await db.color.findAll({});
        return resFound(res, docs);
    } catch (error) {
        return error;
    }
};

const updatecolorById = async (req, res) => {
    try {
        const colorId = req.query.id;
        let color = await db.color.findOne({
            where: { id: colorId },
        });
        if (!color) {
            return resNotFound(res, "color with this id not found");
        }
        color = await color.update(req.body);
        return resDocUpdated(res, color);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};

const deletecolorById = async (req, res) => {
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.color.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No color exists with this Id")
        }
        let deletecolor = await db.color.destroy({
            where:{id:id}
        });
        return resDocDeleted(res,{message : "Successfully Deleted the color", deletecolor})
    } catch (error) {
        console.log(error);
        return resServerError(error)
    }
};
module.exports = {
    createcolor,
    getcolorbyId,
    getAllcolors,
    updatecolorById,
    deletecolorById,
};
