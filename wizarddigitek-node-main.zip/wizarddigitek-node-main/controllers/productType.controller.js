const db = require("../models");
const {
    resServerError,
    resFound,
    resDocCreated,
    resDocUpdated,
    resDocDeleted,
    resNotFound,
} = require("../utils/response");

const createProductType = async (req, res) => {
    try {
        const requestBody = req.body;
        const doc = await db.productType.create(requestBody);
        return resDocCreated(res, doc);
    }
    catch (error) {
        console.error(error);
        return resServerError(res, error);
    }
};


const getProductTypebyId = async(req, res) => {
    try {
        let docs = await db.productType.findOne({
            where: { id: req.query.id },
                include:[
                    {
                        model: db.productBrand,
                        as: "productBrand"
                    }
                ]
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};


const getAllProductTypes = async (req, res) => {
    try {
        let docs = await db.productType.findAll({
            include:[
                {
                    model: db.productBrand,
                    as: "productBrand"
                }
            ]
        });
        return resFound(res, docs);
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};


const getProductTypeByBrandId = async (req, res) => {
    try{
    const docs = await db.productType.findAll({
        where: {
            id: productBrandId
        },
    });
    return resFound(res, docs)
} catch (error) {
    return resServerError( res, error)
}
}

const updateProductTypeById = async (req, res) => {
    try {
        const productTypeId = req.query.id;
        let productType = await db.productType.findOne({
            where: { id: productTypeId },
        });
        if (!productType) {
            return resNotFound(res, "productType with this id not found");
        }
        productType = await productType.update(req.body);
        return resDocUpdated(res, productType);
    } catch (error) {
        console.log(error);
        return resServerError(res, error);
    }
};

const deleteProductTypeById = async (req, res) => {
    try {
        let id = req.query.id;
        if(!id){
            return resValidationError(res,"Please choose the id")
        }
        let existingRecord = await db.productType.findOne({where: {id}})
        if(!existingRecord){
            return resNotFound(res, "No productType exists with this Id")
        }
        let deleteproductType = await db.productType.destroy({
            where:{id:id}
        });
        return res.json({ message: "productType deleted", deletedproductType: deleteproductType});
    } catch (error) {
        console.log(error);
        return resServerError(res,error)
    }
};
module.exports = {
    createProductType,
    getProductTypebyId,
    getAllProductTypes,
    updateProductTypeById,
    deleteProductTypeById,
    getProductTypeByBrandId
};
